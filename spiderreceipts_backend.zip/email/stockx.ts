export const stockxSalesTaxEmail = (form: any) => {
  return `<!DOCTYPE html>
  <html lang="en">
  
  <head>
  <title></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/style.css" rel="stylesheet">
  </head>
  
  <body>
  <div class="">
  <div class="aHl"></div>
  <div id=":pg" tabindex="-1"></div>
  <div id=":qf" class="ii gt"
  jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzNTU5OTE2OTQxMDkzMCIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzNTU5OTE2OTQxMDkzMCIsbnVsbCxbXV0.">
  <div id=":qe" class="a3s aiL ">
  <div>
  <div class="adM"> </div>
  <div>
  <div class="adM"> </div>
  <div>
  <div class="adM"> </div><u></u>
  <div
  style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-bottom:0px;width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;min-width:100%;background-color:#eae8e3;color:#000000">
  <table
  style="border-collapse:collapse;margin:0px auto;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="100%" cellspacing="0" cellpadding="0" align="center"
  bgcolor="#eae8e3">
  <tbody style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center" valign="top" bgcolor="#eae8e3" width="640">
  <table
  style="border-collapse:collapse;margin:0px auto;table-layout:fixed;max-width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640" cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center" valign="top" width="640">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640" cellspacing="0"
  cellpadding="0" align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640"
  cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:0px;margin:0px;line-height:0px;color:#a0a0a0"
  align="center"
  width="640">Your StockX
  order has been
  delivered!
  <br>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122wrapper"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  width="100%">
  <table
  style="border-collapse:collapse;min-width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="100%"
  cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  bgcolor="#D4D1C7"
  width="100%">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="line-height:0;font-size:0px;display:block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="min-height:250px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  valign="top"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;min-height:250px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122bgimageGreen"
  style="background-image:url('');background-repeat:no-repeat;background-size:cover;height:320px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;background-color:#006340"
  align="center"
  valign="top"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;height:250px;padding:45px 15px 0px 105px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D5cQu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttVrtWVeR1CEYE-2BKz-2F0MwQA0MjTs0-2BXTxVVk2c-2FJtBJ-2FWacQPD7WM6EqS1Qvik5vMosHZQ8nh9BGk2JodvTkhWThd9PF1JEKOEkBCpyuOvveWFPVli8eY25ohnzS8QvsvgsEDtIz-2B78RL2C3cn8IFtzA-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D5cQu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttVrtWVeR1CEYE-2BKz-2F0MwQA0MjTs0-2BXTxVVk2c-2FJtBJ-2FWacQPD7WM6EqS1Qvik5vMosHZQ8nh9BGk2JodvTkhWThd9PF1JEKOEkBCpyuOvveWFPVli8eY25ohnzS8QvsvgsEDtIz-2B78RL2C3cn8IFtzA-3D&amp;source=gmail&amp;ust=1692892263918000&amp;usg=AOvVaw361-hO8RTdRgAOuSrRC-uT">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#d4d1c7"
  src="https://ci3.googleusercontent.com/proxy/muCmpQqhW-d2-M5t28iRxF7R0GOzUvg41IYR3mN4Xi6s_4E8VyzW4vxQ2S78N7fXpK5FdZUBL9jvWk3n4a_WPYm1dlFw34WCTFw9eQg3-u503-9D-txNSVUbepMq-1w1cbaXWopGplXQUh7jXTOH=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/StockX_Vertical_Gray_Digital_RGB.png?w=26&amp;dpr=2"
  alt="StockX"
  width="25"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="padding:40px 55px 40px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  width="50%">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnzbM_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTHjbNz-2FwWHGFZ-2BZl-2F8t3W7T82sDUYPnQR48Nss-2FuiFm5e4oABjcjo0KPsxfUncciWgNi0vEmvgvZ5iUavYz5wZYcdeE9rAQ-2FK9c3A912gWTyYNH2U91Bh8CTgH6EfcQj2y3u9ibj3OX8n3U9urupmA-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnzbM_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTHjbNz-2FwWHGFZ-2BZl-2F8t3W7T82sDUYPnQR48Nss-2FuiFm5e4oABjcjo0KPsxfUncciWgNi0vEmvgvZ5iUavYz5wZYcdeE9rAQ-2FK9c3A912gWTyYNH2U91Bh8CTgH6EfcQj2y3u9ibj3OX8n3U9urupmA-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw2gGpR8EDKoZcsHHHxZVP_G">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci4.googleusercontent.com/proxy/wGin-PZspav7xTd9PfPJAjTyj-AUtQ7yXRM2T7lBXXpsg9jPnlY2pInePlkOf9bLTEymfLCbxU263MvwpkHHKgsy-SFy_jR0Aqwz_lOwZGOFlt_5piw54ResVBiuZb4AXAhBXXzJMW_VRqPiqLxnouTC1yLPv3iutpgNI0qYVdVlp9jCbbbu_S8vY-3KTQuaNeU-8u6v_V5goWqh7y0Q3VKXxY35LWIWuDjafethtJrRsBNDA4Y_K_Dq1RBhVVrDXFclsH79xbdBRkaf2Ol205Zgs5DlDBT6SI9CzyhVvNUxHnEjftIQbWL1gbawzDHiAevljQ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b051ordered-icon2.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="left">
  Ordered
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnOOf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttd7-2BFu8BciJcbFIEKEaYqJdCmwHBr3bXSlVsqhkZsQks2n9QRRtnp-2FwwSCyUV5DSZsyDVDesvey8Zo7XDh96t9yEmxk0nS54EQJXezUZC-2FnT-2Fiab41-2FX9-2Fgr2Se0Ym1jmKstazCnRN3HpMOrANw3UZg-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnOOf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttd7-2BFu8BciJcbFIEKEaYqJdCmwHBr3bXSlVsqhkZsQks2n9QRRtnp-2FwwSCyUV5DSZsyDVDesvey8Zo7XDh96t9yEmxk0nS54EQJXezUZC-2FnT-2Fiab41-2FX9-2Fgr2Se0Ym1jmKstazCnRN3HpMOrANw3UZg-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw1a9jh-wnUwyfAEbobzE9lS">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#d4d1c7"
  src="https://ci4.googleusercontent.com/proxy/O33NNBC3yUiMvQKhC9IIxFy05ekUvaTrsZU-9Rxcj2qq1fKPv8tduELBqXDE8mO1FvZZhxAappYbPmI9Gcyawe1njm1Ds-8KUFqZq7wkFfPIDaIXXaxvsS3K41zfFeMn2eUpPGRydVZGJB5wRSDTCL-H6izWHtGfz6GBjq4aB5poTUF0GNcgFArdwp2MJbpCgR1biVZJx-iwD3qKQ5gUzEri2i_attMpypEpSvIXgZeH7W4xNsBaM7pJ_Y9euHbj0mAMMiaOBTvH7qDL_soj3v6tB68n5leYZ-gsfrxOwwQKDFVHtQDraXw1JTT-eNcYRPcwM8kLx0mRw-CJ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b052shippedToStockX-icon2.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="right">
  Shipped
  to
  StockX
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3De-zK_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfXhH-2FMI7v2Cgvukh8oVq3EZI1sKEUrBNyXCfM-2BAdojXuXEFB-2Bp9GQgXYLd-2B95Remm3g1AlSTJJ8GOFttK-2FCLqWzRANWYqvAgmdg36wEbP5v-2Ba9X8jYQtSBAYDS3lxLo67CM98gqSFjM3p9a3cUjydY-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3De-zK_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfXhH-2FMI7v2Cgvukh8oVq3EZI1sKEUrBNyXCfM-2BAdojXuXEFB-2Bp9GQgXYLd-2B95Remm3g1AlSTJJ8GOFttK-2FCLqWzRANWYqvAgmdg36wEbP5v-2Ba9X8jYQtSBAYDS3lxLo67CM98gqSFjM3p9a3cUjydY-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw3G1mT4-t5HGsEzmShpdNrO">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci6.googleusercontent.com/proxy/E-5Nrbb8x2O73YH6te4RGNca0ZKp3XsZcRR0dPy6DNPV3_lDPNUCU7W2h76IGH7zC3x10g6gpiZQW82YsmHFkd-PCNOHs-Fh2Sez4QqeD8rr-B_PwSozbO7xnp0uB1z-GN-YA31b9cSoldtGQJJ7T8IRnTRat_Zpo-zA786cb4XuOtwjYOJI4_0r1Nn8EGB1C09oPtTDy-FFwoZQElM25w8noidhlWWaIhTuGIHh31a9JXLEXIv1z6S3GRpMneJsZmSbH-kDN1WOkQxuUJ5c1GSu5cCPq0_w6zs8BC9mztt0ICQB8bbnmda0002xSHRoVI7ErbDy=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/ArrivedAtStockX_bid.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="left">
  Arrived
  at
  StockX
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DZ7k1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttUpox7NLhOeK1h930V7US7y6zltMR-2FmiPJ3wATox425m8L4Q-2BgH65Ep-2B-2FIPFgv3NeJR0u9Xa9ffJ9JPDjbFrlFsWeWEO3ptTx0zSjCpfoJ6UHtP-2F9ekf6VogMdUMuQFX5-2BkBXbAdsCFlBdaAn1sAyh4-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DZ7k1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttUpox7NLhOeK1h930V7US7y6zltMR-2FmiPJ3wATox425m8L4Q-2BgH65Ep-2B-2FIPFgv3NeJR0u9Xa9ffJ9JPDjbFrlFsWeWEO3ptTx0zSjCpfoJ6UHtP-2F9ekf6VogMdUMuQFX5-2BkBXbAdsCFlBdaAn1sAyh4-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw339hsS3ZkJ2Z2nRCJZ2W-r">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci4.googleusercontent.com/proxy/iNQJ6pvYuTFfeZ354GdEgbajAngl5zNYIrAkf1x05iD_mWd2dth1paf9Vta6Jb6WDmiZYwY-rJsnboOUGTK8vfFa5ovcuEJ4ICiXEOpb-6JDXnUz2uEMkrUnaVzLg5s40IQt-xF5QTJ4w-GpBsxDnY-v1xAlYjuZH1983irc0Yf0DFLKJ8TULrWd9O4msR3mlwjisqOLALOaJ7TH9vif-7z8KcwNZadtrPIHdWEbqY_QtVVpfEOgBGTn-47qHPeyTECS6msQakSnN8cPLGg3ta7dKwGzA035N7VJXMVD0yHZ6Pt2-L7rCQmojCCwxm9eDFGk-_kH=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b053shippedToBuyer3.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;vertical-align:middle;padding-bottom:10px;color:#000000"
  align="left">
  Verified
  +
  Shipped
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3D_GdG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfM-2ByR08Sq8lnrD-2BgZgiDD1dxUzOoMuFu7NMdRoKGB5DuXJqShBK-2BZG9eyGy-2BlaEfA0KFHXgBe5lXFwyHIehM4Zr1gCg9PZGNP4KGLWfrqrUoY2oZhv0aJi-2BLB7pG0qb8qbY-2B4j7w5bEk5yXgPrn6y4-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3D_GdG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfM-2ByR08Sq8lnrD-2BgZgiDD1dxUzOoMuFu7NMdRoKGB5DuXJqShBK-2BZG9eyGy-2BlaEfA0KFHXgBe5lXFwyHIehM4Zr1gCg9PZGNP4KGLWfrqrUoY2oZhv0aJi-2BLB7pG0qb8qbY-2B4j7w5bEk5yXgPrn6y4-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw2URHY3B3-lbMCVQCT4XOJZ">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci5.googleusercontent.com/proxy/tjUNdPU5iBMSvZXjEs1MJMg4N1a2oKWeRBKzGCCQgidBUOhheiwBtdMCruzNzKSRgd62iW5iu2EVd7Z70Hc1hcCc_osO1UlHYAu-yHWpyDaYT5zXB1ZU_nnZGD84cFyKk89VAodVXlhw6FP3ePhPu7GzK7R_l7VNs2xdeR42fmlgQMP9yXkKGUNHenyr7nVlXAagCkP5YjBmUD4u58OL-KUJVjfAOwJBiFw9pW3yY4V8jipSFeO01oEPmmhY0bI0gfv2nUglSD3cXF6NrVOljQkaL0NXTdrs5M_geJCYgKUPqQ4vb6Ne--xDCNACFmH8dF4LdXJmANQ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b054delivered-icon_v3.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=D4D1C7&amp;fit=fill&amp;border=1%2CD4D1C7&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;vertical-align:middle;padding-bottom:10px;color:#d4d1c7"
  align="left">
  Delivered
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="320"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:45px 175px 45px 45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  height="100%">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3DduC-_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc23g65RVWC1lM-2BK-2F9pYv7ntbYraPLLrnZN8cykczq9cTAxVRoLrqDa0wqNdnilUCTYN4wY7UyRr1Lh4uyx4lprRkBzBIEamWn83j-2F9Uh0ZrSGuj2FbUMnFYwD1-2Bb1yZnkGBfnAu5mB1DvpYYHgY4Eo-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3DduC-_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc23g65RVWC1lM-2BK-2F9pYv7ntbYraPLLrnZN8cykczq9cTAxVRoLrqDa0wqNdnilUCTYN4wY7UyRr1Lh4uyx4lprRkBzBIEamWn83j-2F9Uh0ZrSGuj2FbUMnFYwD1-2Bb1yZnkGBfnAu5mB1DvpYYHgY4Eo-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw0sirRjMOgcEPOXasBWv2O-">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci6.googleusercontent.com/proxy/D_y8TCzuOHP4F7c4FU_6u5TNWv4WJVar97J_2d0sG9W6fIfyRV_oruj7XpKX4AoRphkIuhVpl6heMXyD6pw2_UdoZSTBVVHwObhsuOOxojmWoZIOYqLt1_57npfMuifpOk7e=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/X_Black_Digital_RGB.png?w=100&amp;dpr=2"
  alt="StockX"
  width="100"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="320"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122subheaderTextPostPurchase"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:28px;text-decoration:none;text-align:left;line-height:32px;font-weight:500;padding:40px 40px 0px 0px;color:#006340"
  align="left">
  Order
  Delivered
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:16px;text-decoration:none;text-align:left;line-height:24px;font-weight:600;color:#000005"
  align="left">
  Delivered
  on:
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:16px;text-decoration:none;text-align:left;line-height:24px;font-weight:400;color:#000005"
  align="left">
  ${form?.delivery_date}
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  width="640"
  height="auto">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;margin:0px;padding:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  width="260">
  <a href="https://${form?.item_link}"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://${form?.item_link}&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3e1r6vtwiSIsZe2DwK_n_F">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:22px;text-decoration:none;text-align:center;letter-spacing:1px;color:#006340"
  src="${form?.image_link}"
  alt="Jordan 3 Retro White Cement Reimagined"
  width="260"
  height="auto"
  class="CToWUd"
  data-bit="iit"
  jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
  </a>
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  width="280">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:24px;text-decoration:none;text-align:left;line-height:30px;padding:30px 15px 15px;font-weight:500;color:#006340"
  width="280">
  <a href="https://${form?.item_link}"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://${form?.item_link}&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3e1r6vtwiSIsZe2DwK_n_F">${form?.item_name}</a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;padding:0px 0px 0px 15px;color:#000000"
  width="280">
  <ul
  style="list-style-type:none;margin:0px;padding:5px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Style
  ID:&nbsp;${form?.style_id}
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  ${form?.size}
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Condition:&nbsp;New,
  StockX
  Verified
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Order
  number:&nbsp;${form?.order_number}
  </li>
  </ul>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;font-weight:400;padding:15px 0px 0px 15px;color:#000000"
  width="280">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Purchase
  Price:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.purchase_price}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Sales
  Tax:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.amount}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Processing
  Fee:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.processing_fee}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Shipping:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.shipping}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:0px;text-decoration:none;text-align:left;line-height:0px;padding:5px 0px 0px;border-bottom-width:0px;border-bottom-style:solid;border-bottom-color:#000000;color:#ffffff"
  colspan="2"
  width="240">
  &nbsp;&nbsp;
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:14px;text-decoration:none;text-align:left;line-height:18px;font-weight:600;display:inline-block;min-width:200px;text-transform:uppercase;color:#006340"
  width="200">
  Total
  Payment
  </td>
  <td style="text-align:right;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:14px;text-decoration:none;line-height:18px;font-weight:600;color:#006340"
  align="right">
  ${form?.total}*
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:center;line-height:16px;font-weight:normal;padding:15px 0px 30px 15px;color:#000000"
  align="center"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-radius:2px;padding:8px 18px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  bgcolor="#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7XfsLHDYAwZZpIn9Z6XRqUs6AIPmBcDOpzV6Ot47iN7ywTFdrt73bTpC2I7Belb8P5aM3uFK4ypp5lTk1k5FIsCutbZRbTU9in-2BVFzGZk0TYI-3D5lgH_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTtPb68CO9656-2BR8gOtiKBpEXOW9-2BRnSuKl-2FOTYFTRv-2BCdugbRIWjJj-2Bq68TlFFEGjIc-2BYyc33LGabBwxEAr94sygQGS-2F-2FnMMQXxEDZcPmPY-2FNngGk-2FmIxdYPMejXDHEWLFmZFCtlC52SlzPMyFb04g-3D"
  style="font-size:20px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;border-radius:2px;border:0px;display:inline-block;line-height:35px;padding:0px 10px;font-weight:500;color:#ffffff"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7XfsLHDYAwZZpIn9Z6XRqUs6AIPmBcDOpzV6Ot47iN7ywTFdrt73bTpC2I7Belb8P5aM3uFK4ypp5lTk1k5FIsCutbZRbTU9in-2BVFzGZk0TYI-3D5lgH_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTtPb68CO9656-2BR8gOtiKBpEXOW9-2BRnSuKl-2FOTYFTRv-2BCdugbRIWjJj-2Bq68TlFFEGjIc-2BYyc33LGabBwxEAr94sygQGS-2F-2FnMMQXxEDZcPmPY-2FNngGk-2FmIxdYPMejXDHEWLFmZFCtlC52SlzPMyFb04g-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3s2d4DOvx_SfvtvljvOUnR">View
  Order</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="left">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px 0px 15px 15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:300;font-style:italic;color:#000000"
  align="center"
  width="100%">
  *All
  applicable
  duties
  and
  VAT
  are
  included
  in
  the
  total
  price
  of
  this
  item.
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122topcopy30"
  style="padding:30px 20px 15px 105px;line-height:0;font-size:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  bgcolor="#D4D1C7">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:400;padding-bottom:15px;color:#000005"
  align="center"
  width="100%">
  Thanks
  again
  for
  choosing
  StockX!
  Don’t
  forget
  to
  remind
  people
  that
  you
  #GotItOnStockX
  by
  showing
  off
  your
  latest
  purchase
  on
  social.
  We
  suggest
  leaving
  the
  StockX
  tag
  on
  for
  the
  pics.
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-top:15px;line-height:0;font-size:0px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-bottom:30px;line-height:0;font-size:0px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="bottom"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPpnyf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttXOIdVh71Y4yBSckt1Z0vTeGVmx4Lb7S9fYv5Uhu-2BxZHxDduDRaPIhhQic3-2BHuL4lR-2FF1neZGIkCtA7GIm9UHLVWjlpdRQ9OEMGAVugf7BQiEIUiVeKuI8vFPwFKZwWDzHUO-2F2wj99LGy5vaSMAqNak-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPpnyf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttXOIdVh71Y4yBSckt1Z0vTeGVmx4Lb7S9fYv5Uhu-2BxZHxDduDRaPIhhQic3-2BHuL4lR-2FF1neZGIkCtA7GIm9UHLVWjlpdRQ9OEMGAVugf7BQiEIUiVeKuI8vFPwFKZwWDzHUO-2F2wj99LGy5vaSMAqNak-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw2dJ1_LKcTD7iuqJW3SrSp4">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/kU2Anna_KfAyUPUHG1krlOWNFDR5g2Xd7txJkkkFbJQc9YdHk7jwk5bTQQrHSQckfOeIi0abMiYMnCRzSWgHIMjD5bsRUE780AMcMqKWb3LibuJXmd4Hra5y=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/facebook.gif"
  alt="facebook"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6-b8U_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcge3E-2FZAAacgpl0i6ABRKne5oTYGuWkPeidRKEk1DKoRXEhfTRqEcQwdST75ASoNtSKbYIFFGIMjUd35ytzZhJ4aFZTY7hliXs8Q2I1nqJ9OCu9-2BCAgbsQjl338UPK4k0XjSUEvxebBI3olbLCr2gY-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6-b8U_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcge3E-2FZAAacgpl0i6ABRKne5oTYGuWkPeidRKEk1DKoRXEhfTRqEcQwdST75ASoNtSKbYIFFGIMjUd35ytzZhJ4aFZTY7hliXs8Q2I1nqJ9OCu9-2BCAgbsQjl338UPK4k0XjSUEvxebBI3olbLCr2gY-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw28ly5ibgqsnvCiAyBKn4Cw">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/IsSRGmVZs4_APEsLplGjM2monuZLFaAqlMwofRn0YBYEA0WO6hpNRWv67LT5Gwt3SF9oX6ummIMStvRdoAfIgGPC34ZPMt29bqJvwO7vw-xgaKlnQPHBO60=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/twitter.gif"
  alt="twitter"
  width="30"
  height="25"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxPc0dZ-2FaTNy2lEyzahPZBa8x9dj_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfcCGj7PDaJoGoKnWhcvbfENvKYp6T61hW6XEuzfY8JMU817ral4ik4NC-2FdvMXuHa8i-2Fs47hHlhdpCEkvXFf0vKwRgdibn6EpIL-2F4EuEZu0aJwLjd6Ku1InJAORywg4nQkFmEJCHpTbCsAegJHFW5FI-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxPc0dZ-2FaTNy2lEyzahPZBa8x9dj_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfcCGj7PDaJoGoKnWhcvbfENvKYp6T61hW6XEuzfY8JMU817ral4ik4NC-2FdvMXuHa8i-2Fs47hHlhdpCEkvXFf0vKwRgdibn6EpIL-2F4EuEZu0aJwLjd6Ku1InJAORywg4nQkFmEJCHpTbCsAegJHFW5FI-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw2KpKBl2JNqtyhhROCLZR9q">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/pdvlrlwiDu1EQ0b55wIibc-wmOmF8Tmk4qFrnBDQRuiZqwDHVeJ8p4975f_nx_2zLclMO4hOajS5o0pwpunev08lyK6II-mdgJCrwXrtdCgAsEnqjW5Nnt9Y9g=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/instagram.gif"
  alt="instagram"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHq1DJ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttdy4SaD66SIIS-2B9Iucyr-2F-2BXuiJGhPh33549aBWcKVXyeC6XPP8bKrtCA-2BzgnlVB1gB9Mj6NGltwR9HbqT9hm6V4L0eia7v9mOTAkX4Zdcg-2FLR7a1AFqap0UAZ-2Fqdt2iSbtKWi89qobh3SWrTfbqcLiw-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHq1DJ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttdy4SaD66SIIS-2B9Iucyr-2F-2BXuiJGhPh33549aBWcKVXyeC6XPP8bKrtCA-2BzgnlVB1gB9Mj6NGltwR9HbqT9hm6V4L0eia7v9mOTAkX4Zdcg-2FLR7a1AFqap0UAZ-2Fqdt2iSbtKWi89qobh3SWrTfbqcLiw-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw1zg1_uXA6alHSI8qGMHMuo">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/oDqYerJ6hsLj5YpocdcAXiQhJ8CykCKKQR1bszNScGipWFnFUF2ENV3SpfvKZYzHA_zK0PpHvj1yiIuTg9f6FnTh7hDUOqWpqDhHblRkFwff5p9gG6lBVcg=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/youtube.gif"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClU8H49_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSg6jQJ7ZsImS6ves8DQYeum6h4h5WyalKbcGPJnappxF0YEgrfKTsx38DqU3C7mCVUFiitdyxtEJNSsTBiLPNP8hWgF9bmFrMJ-2Fw521Y6dwOLHB8wG-2Bld4LDFmryFGep1xl8knbWzYDLJ54EZ9WQ2c-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClU8H49_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSg6jQJ7ZsImS6ves8DQYeum6h4h5WyalKbcGPJnappxF0YEgrfKTsx38DqU3C7mCVUFiitdyxtEJNSsTBiLPNP8hWgF9bmFrMJ-2Fw521Y6dwOLHB8wG-2Bld4LDFmryFGep1xl8knbWzYDLJ54EZ9WQ2c-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw0pI7ehqO4PxYPLaXmEyHie">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/EJUu4K2VkK5bvTz3nX5t3C88DOYJ_Vn-FXEWCijXWCBt14-RmUGlDR5Gnu3JjLwoFsmBPEdNv8jW-5Lw9smlT7KvOSXMwfhrVol0CI8rUEg=s0-d-e1-ft#https://stockx-assets.s3.amazonaws.com/Discord-Logo-black.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="line-height:0;font-size:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:30px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  bgcolor="#D4D1C7"
  width="100%">
  <table
  style="display:block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:600;padding-top:0px;padding-left:105px;padding-right:105px;color:#000000"
  colspan="2"
  align="center"
  width="100%">
  Frequently
  Asked
  Questions
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:normal;padding-top:5px;padding-left:105px;padding-right:105px;color:#000000"
  align="center"
  width="100%">
  <ul style="margin:0px 0px 0px 15px;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:20px;font-weight:400;color:#006340"
  type="disc">
  <li
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:18px;font-weight:400;color:#006340">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYeh-2B3kwF5a3nRMv3JukgzGiOAnmKIykX0ZWtP0QNN-2FkWfnTExyiucaWJWVSwKY4CtwvB60L-2FhsFOIGxBvWY6SEfci6GMjDS95xtePff048gfzPZo8dKWqaSvp-2B1TfdkZMJfelT9g-2F43VW7CopmNEicvmC9KHeHEuXlvso9fjpS87he72ycJOa7LIHQm4Z-2FdFt1kWXG0kEK27Ib8N-2FncAcm21p8dlG49Hgkw0Jd89OPuKfrneg3klhWduxq1VGDIpjnYtL6J6yIr-2BJGy-2FLqd5Ke-2Fg-3D-3DdKru_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfy9GqQFWi5d1ozYXlS47b5DdqC-2BTtCwcdBcDHy3Laq5mtpTVlcgZ-2FwN9ekH1ALJahvgEDd85nWqOypsM55bILZDzR4SJBDkHsO8QjlOkr6N0FfB-2B4JLytDH3d5RdNB3zzjv2NUYjRnuxnDBRZB8sSk-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYeh-2B3kwF5a3nRMv3JukgzGiOAnmKIykX0ZWtP0QNN-2FkWfnTExyiucaWJWVSwKY4CtwvB60L-2FhsFOIGxBvWY6SEfci6GMjDS95xtePff048gfzPZo8dKWqaSvp-2B1TfdkZMJfelT9g-2F43VW7CopmNEicvmC9KHeHEuXlvso9fjpS87he72ycJOa7LIHQm4Z-2FdFt1kWXG0kEK27Ib8N-2FncAcm21p8dlG49Hgkw0Jd89OPuKfrneg3klhWduxq1VGDIpjnYtL6J6yIr-2BJGy-2FLqd5Ke-2Fg-3D-3DdKru_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfy9GqQFWi5d1ozYXlS47b5DdqC-2BTtCwcdBcDHy3Laq5mtpTVlcgZ-2FwN9ekH1ALJahvgEDd85nWqOypsM55bILZDzR4SJBDkHsO8QjlOkr6N0FfB-2B4JLytDH3d5RdNB3zzjv2NUYjRnuxnDBRZB8sSk-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw3HRPF9IvDMSUeeuD-jaUaF">What
  is
  the
  StockX
  Return
  Policy?</a>
  </li>
  <li
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:18px;font-weight:400;color:#006340">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYedpWZgszC-2BNZCYsabL2sa6oOfBW-2FWScDdn-2FfiSZB-2FmEtdQ12Q0pxBuRm8sTK8wHey9yaVfcAI25-2F-2FR6Sb-2FHcWdG8yiVRtwIOdK9Xgqq-2Fg2pzb-2BLdfrm4q9jF6VfEuQWpYbUMNFki4ggHbiQsHb-2FqssBvfPyoCh58b9GfuGaNUYUW3QW3r7GCqkkizP4HEncwePN-2BqqqZwOObAG-2BTEYzWKn394PUT5hvqcig5gok3DJoOwHNxE6t0FggRyeX5SMs-2FK71P5L-2F0RAiGY-2F-2FNFjFjmwstfl0AJP-2F3-2BYacbXsQXnKPrk5OXxqgfQA0HDEgoMHZVxpcp_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttReb1i3yF8bwZ4-2FI4wFjeqZvZlCFKY3bfQ2ng-2By1iqhDLmXwx2S-2B2h-2FhMkmTx6qtZnRU-2BVQyvRyzF8d2rTAo67wGd6MJ9uC0RD42BpqT5ZvAmvCrNoLY1pAeFpl4-2Bdv0WYhZrUgtAZOuXdQmEsqJfpg-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYedpWZgszC-2BNZCYsabL2sa6oOfBW-2FWScDdn-2FfiSZB-2FmEtdQ12Q0pxBuRm8sTK8wHey9yaVfcAI25-2F-2FR6Sb-2FHcWdG8yiVRtwIOdK9Xgqq-2Fg2pzb-2BLdfrm4q9jF6VfEuQWpYbUMNFki4ggHbiQsHb-2FqssBvfPyoCh58b9GfuGaNUYUW3QW3r7GCqkkizP4HEncwePN-2BqqqZwOObAG-2BTEYzWKn394PUT5hvqcig5gok3DJoOwHNxE6t0FggRyeX5SMs-2FK71P5L-2F0RAiGY-2F-2FNFjFjmwstfl0AJP-2F3-2BYacbXsQXnKPrk5OXxqgfQA0HDEgoMHZVxpcp_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttReb1i3yF8bwZ4-2FI4wFjeqZvZlCFKY3bfQ2ng-2By1iqhDLmXwx2S-2B2h-2FhMkmTx6qtZnRU-2BVQyvRyzF8d2rTAo67wGd6MJ9uC0RD42BpqT5ZvAmvCrNoLY1pAeFpl4-2Bdv0WYhZrUgtAZOuXdQmEsqJfpg-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw0LfLSfumKhue_eq4Na0_zP">What
  does
  the
  verification
  process
  entail
  for
  Buyers?</a>
  </li>
  </ul>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122headlineBox"
  style="padding-bottom:10px;padding-top:10px;padding-left:50px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  bgcolor="#006340">
  <table
  style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:25px;text-decoration:none;text-align:left;line-height:30px;font-weight:400;color:#d4d1c7"
  align="left"
  width="640">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb3VtjuBuM0gmQ1zo0P0iNdXSBgs5yTW4VoWYSdXfTK2DcGt73kb7bptM409p6bKL8jMKV4IQhJprRTWkyo7R1j2rrDHJ8k-2FYyrXjUGxV-2Bur3D-2FVM8mpO8izOfIiqKP5hoA-3D-3DatSQ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttX9ARtJ8-2FfMVoVErcLDZe-2Fxwr42ftq-2FDQYe2vYKa5oiGfLY3ORDFzmwq2HC4UQrww2LurbdJe8oeWW7WwKLehEVylz0joB-2B1AoM6Niejpccg6KMzLzLmLeiWsWaZY1cHMkdLCxrH0xzz4Dv3nNJy-2F1Y-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#ffffff"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb3VtjuBuM0gmQ1zo0P0iNdXSBgs5yTW4VoWYSdXfTK2DcGt73kb7bptM409p6bKL8jMKV4IQhJprRTWkyo7R1j2rrDHJ8k-2FYyrXjUGxV-2Bur3D-2FVM8mpO8izOfIiqKP5hoA-3D-3DatSQ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttX9ARtJ8-2FfMVoVErcLDZe-2Fxwr42ftq-2FDQYe2vYKa5oiGfLY3ORDFzmwq2HC4UQrww2LurbdJe8oeWW7WwKLehEVylz0joB-2B1AoM6Niejpccg6KMzLzLmLeiWsWaZY1cHMkdLCxrH0xzz4Dv3nNJy-2F1Y-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw345zlg6NSI7vb1HipdTTCe">Picked
  For
  You</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122container"
  style="border-collapse:collapse;padding:20px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="3"
  align="center"
  width="640">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border:0px;border-collapse:collapse;margin:0px auto;padding:0px;display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  width="640">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px 14px 0px 28px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDe-2BRmH2x2pcH-2Bzt-2FliSkZhYnsjoJvW1MbCww2rxLbxfiK76NfqG6dpQlOm-2FL-2FeD9-2BAzcRmU3iOmD47S-2Fo0PZQtHmWyLvHXbIu1fZ4fqis0EPHDrpaFetgXKlVqMlOShHOsFHrpo0kIm-2BA67kloSvDaIKLpL_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZxXimj67qOpg0eBsHUpUXBg4qZ10O7Fmw9v3NifaHAoRod8A5S-2FXsOaIgn6be-2FHuqOrNNwXCHp11wZVfoIM-2FJkzoCvHnCygiTS8yPq1VQ6I6iRSyy2SphfRFJMZyGKm1xnc8YlPm7PfUsniDYb4Fuk-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDe-2BRmH2x2pcH-2Bzt-2FliSkZhYnsjoJvW1MbCww2rxLbxfiK76NfqG6dpQlOm-2FL-2FeD9-2BAzcRmU3iOmD47S-2Fo0PZQtHmWyLvHXbIu1fZ4fqis0EPHDrpaFetgXKlVqMlOShHOsFHrpo0kIm-2BA67kloSvDaIKLpL_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZxXimj67qOpg0eBsHUpUXBg4qZ10O7Fmw9v3NifaHAoRod8A5S-2FXsOaIgn6be-2FHuqOrNNwXCHp11wZVfoIM-2FJkzoCvHnCygiTS8yPq1VQ6I6iRSyy2SphfRFJMZyGKm1xnc8YlPm7PfUsniDYb4Fuk-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw2umaZ2naIwhp0kMRVxiRk-">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci3.googleusercontent.com/proxy/svOJyZuHCPyVGrJw0Rdh_ihKqvJjCYNjrHfJDid8rjHDHkCa9W6mAr5P-RO6ctc2eMY2jDY85YPMrUhlptjgx7IgNQvvrMXfsWwLgjmmdF9loL6GpgqG4XyZWD564mHrpojn6g=s0-d-e1-ft#https://images.stockx.com/images/Nike-Dunk-Low-Retro-White-Black-2021-Product.jpg"
  alt="Nike Dunk Low Retro White Black Panda (2021)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Nike
  Dunk
  Low
  Retro
  White
  Black
  Panda
  (2021)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="padding:0px 14px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Bi9J-2BAWxsYIzMzwcNH0etGfN5LuyaLekYUB8x5I0GQd0MIDAl-2BO9TkvOEjjndAYBNgkrEOq0NG6-2BkXn7YiJF-2FSp52GTGFWafh7jQ8E7o1llJtYXv-2FTNhDFdzul84G68U-2BthaoY85H28c-2FmfRFViKsm6l-2FnJoFRhi3-2FXXkwycKx3aNPXavlkiDZgD3gHMIkYoQ-3D-3DBK6M_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc53GjkWS-2FfL6oiorR6wGzZ83eJ0N5mpMrBEfO18-2F30lmAdyFtG0U35366lm10R5rytWO5iG-2FlvBC-2Fsu3SvFZd0zDrOwtJiUGzQzy4vG1J754ym4iIjvw7HCQDw5uyHmk-2BL7-2Fiqo8i50THNSg5daaqM-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Bi9J-2BAWxsYIzMzwcNH0etGfN5LuyaLekYUB8x5I0GQd0MIDAl-2BO9TkvOEjjndAYBNgkrEOq0NG6-2BkXn7YiJF-2FSp52GTGFWafh7jQ8E7o1llJtYXv-2FTNhDFdzul84G68U-2BthaoY85H28c-2FmfRFViKsm6l-2FnJoFRhi3-2FXXkwycKx3aNPXavlkiDZgD3gHMIkYoQ-3D-3DBK6M_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc53GjkWS-2FfL6oiorR6wGzZ83eJ0N5mpMrBEfO18-2F30lmAdyFtG0U35366lm10R5rytWO5iG-2FlvBC-2Fsu3SvFZd0zDrOwtJiUGzQzy4vG1J754ym4iIjvw7HCQDw5uyHmk-2BL7-2Fiqo8i50THNSg5daaqM-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw1ra2TtQDPItEDpp7cVbtvg">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci5.googleusercontent.com/proxy/mTwucrH-GQCDjELI9tKT0ySrs-CfNEtROGlCZSkCuZDFOPkGCDIAn2WgE2g2nxQM0OY0jhGrnH3-RRc05revIwckqy_v0I55BuFA0_vR9zawpncP-9Kyk9Yr5r9ael89Mtw5wUmJ-6UlrX4i2CY0Qx4=s0-d-e1-ft#https://images.stockx.com/images/Air-Jordan-1-Retro-Low-OG-SP-Travis-Scott-Olive-W-Product.jpg"
  alt="Jordan 1 Retro Low OG SP Travis Scott Olive (Women's)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Jordan
  1
  Retro
  Low
  OG
  SP
  Travis
  Scott
  Olive
  (Women's)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="padding:0px 28px 0px 14px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDcvo3B9PufsUvdHMoqACJK7gFMYQH6jtSG5XIxww3tJmP8L1hPBL4b7WQudj2fMfQ7mtg34alJtNodTHqa-2FuTOMOwX-2FGA-2F9-2F3QuIBI7craRu076vg7Cc0fXi-2BNVmktWlo59hMC5E-2FCc0rRvR8uMe8K-2BzHR4_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcHD-2FWF-2BoYUqox6W7SAkBtlkA9E-2BkeE5iW6wSRihwZ9wTpVrOFriC5GCYCQX57bUQa4PKhKGZ1Wm-2Bn202Zm3Yw-2FbjG5UZa8Smjg5iG3tH2PslD80jzAPFJbu08QBtgpIoWQJAVzUPqeP0MZrVJt0aDM-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDcvo3B9PufsUvdHMoqACJK7gFMYQH6jtSG5XIxww3tJmP8L1hPBL4b7WQudj2fMfQ7mtg34alJtNodTHqa-2FuTOMOwX-2FGA-2F9-2F3QuIBI7craRu076vg7Cc0fXi-2BNVmktWlo59hMC5E-2FCc0rRvR8uMe8K-2BzHR4_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcHD-2FWF-2BoYUqox6W7SAkBtlkA9E-2BkeE5iW6wSRihwZ9wTpVrOFriC5GCYCQX57bUQa4PKhKGZ1Wm-2Bn202Zm3Yw-2FbjG5UZa8Smjg5iG3tH2PslD80jzAPFJbu08QBtgpIoWQJAVzUPqeP0MZrVJt0aDM-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw3mAUMRz_H1voCFoO-gHMf-">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci6.googleusercontent.com/proxy/BNaMRgKWA5N0HOJATrYJMWGFm-gyhrA-qvKWq1oTyCwpsJTCbBedKdyZGK9DuWGO2fgOu0oG_pX9lYKiS7Enw62rKFjbDqJzLrQ1kY3EjLDUKtslXvY5lH9ShUsGYsRs=s0-d-e1-ft#https://images.stockx.com/images/Nike-Dunk-Low-White-Black-2021-W-Product.jpg"
  alt="Nike Dunk Low Retro White Black Panda (2021) (Women's)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Nike
  Dunk
  Low
  Retro
  White
  Black
  Panda
  (2021)
  (Women's)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  bgcolor="#006340"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:45px 30px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:normal;padding-left:105px;padding-bottom:45px;color:#d4d1c7"
  align="center">
  <ul style="margin:0px;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;line-height:24px;font-weight:600;display:inline-block;list-style-type:none;color:#d4d1c7"
  type="none">
  <li
  style="display:inline-block;padding:0px 5px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;margin:0px!important">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3DZKQn_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZnLt8zE1dsHLJcPNMRFFIx3Yq7YvQH-2BjhX5-2FjOVGFRVYO8spTaBMKbMmsTUZrjWp0q2OuM7VTYqcp8704eujHfzEVpcifHBvVcV8klJxzZcXUd-2BAGCteQ2DmmvPz3MA-2Bu2EQuLCF9O8Yay6J9dus4s-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  align="left"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3DZKQn_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZnLt8zE1dsHLJcPNMRFFIx3Yq7YvQH-2BjhX5-2FjOVGFRVYO8spTaBMKbMmsTUZrjWp0q2OuM7VTYqcp8704eujHfzEVpcifHBvVcV8klJxzZcXUd-2BAGCteQ2DmmvPz3MA-2Bu2EQuLCF9O8Yay6J9dus4s-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw0iBx__zElxu-xMIuwoEz6_">Email
  Settings</a>
  </li>
  <li
  style="display:inline-block;border-left-width:1px;border-left-style:solid;padding:0px 10px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;border-left-color:#d4d1c7">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7ukcblo93b-2BPW5F-2Fcb7sEBQh6WoKt2-2BiEBviXe-2BhUhKgUJm0YGXi8-2FQray-2BgHprlG0sEiOwvTG2g6sIE0j0AJR-2BRbGi3mRx19ZNnZY-2BBoBaGYA-3D-3D83Sa_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttauqndCTK9olYRNWdqJCjWV-2BTYeyC915eDdL6jz6w-2B-2BVmIuX2nC27qiDdiwvqNhf9z7f-2BjDxl6ZcUcr-2FzZ6QQXWBtfeotaVWGicaYyosSzbctTryG6prE3si7H-2BuvdZShprsyFQNAe4XLo7FSsDDpWw-3D"
  style="text-decoration:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  rel="noopener noreferrer"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7ukcblo93b-2BPW5F-2Fcb7sEBQh6WoKt2-2BiEBviXe-2BhUhKgUJm0YGXi8-2FQray-2BgHprlG0sEiOwvTG2g6sIE0j0AJR-2BRbGi3mRx19ZNnZY-2BBoBaGYA-3D-3D83Sa_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttauqndCTK9olYRNWdqJCjWV-2BTYeyC915eDdL6jz6w-2B-2BVmIuX2nC27qiDdiwvqNhf9z7f-2BjDxl6ZcUcr-2FzZ6QQXWBtfeotaVWGicaYyosSzbctTryG6prE3si7H-2BuvdZShprsyFQNAe4XLo7FSsDDpWw-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3L5y05AZaX_EdesbarfTnQ">Help</a>
  </li>
  <li
  style="display:inline-block;border-left-width:1px;border-left-style:solid;padding-left:10px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;border-left-color:#d4d1c7">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0wlvZCGseNuC-2BvJXrp9jQuf-2FDvneA5YDfjajzeVys7hGYNtKkTaPWX-2ByFtYuswYyW4xOPINIhhAYfJyvilgGHXVGSj1Sv4eRy-2BEC5PK31OLJhGb3s60HvFMoBVhpNKdRg-3D-3DyfF1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSuFgbor5U8o7kaQbFzZHb34ha9sunSlvZa-2FVN0JGKjgejFpgeCQJ2Py6qr2SjnxGhbD6Y-2FYqOsV-2BhQmx6MmPnULmMqAMMGENpKufkjpPbSImSRRl-2BE-2BhlCXibyfe0ulVJZJefrLvaopsWSZWepVrfE-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0wlvZCGseNuC-2BvJXrp9jQuf-2FDvneA5YDfjajzeVys7hGYNtKkTaPWX-2ByFtYuswYyW4xOPINIhhAYfJyvilgGHXVGSj1Sv4eRy-2BEC5PK31OLJhGb3s60HvFMoBVhpNKdRg-3D-3DyfF1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSuFgbor5U8o7kaQbFzZHb34ha9sunSlvZa-2FVN0JGKjgejFpgeCQJ2Py6qr2SjnxGhbD6Y-2FYqOsV-2BhQmx6MmPnULmMqAMMGENpKufkjpPbSImSRRl-2BE-2BhlCXibyfe0ulVJZJefrLvaopsWSZWepVrfE-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw0_L3qFCglKtFDTO8KHGOYK">Jobs</a>
  </li>
  </ul>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  bgcolor="#eae8e3">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D61P9_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSGbQfHrcf3YKVtxPeBsFfoyOXg1VwyATKav2eDm27hPwaDB0-2FJDptbpGxNuXROidahXV5XYH-2B-2FaWNzlNI14NXMZyWkjFuCzoWciLKA2hw-2BR8w4qBZC6wcU9YYvvsFMLEA0uPpetoslhxlS75w0whtk-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D61P9_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSGbQfHrcf3YKVtxPeBsFfoyOXg1VwyATKav2eDm27hPwaDB0-2FJDptbpGxNuXROidahXV5XYH-2B-2FaWNzlNI14NXMZyWkjFuCzoWciLKA2hw-2BR8w4qBZC6wcU9YYvvsFMLEA0uPpetoslhxlS75w0whtk-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3AHSHYHr3ghv_QKQ1PeFjD">
  <img style="display:block;border:medium;font-family:ProximaNova,Helvetica,Arial,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;max-width:55px;font-weight:400;color:#006340"
  src="https://ci5.googleusercontent.com/proxy/KWlZiyaBvMEXWAdAhl6QKBE0O3_twEEBYJl3sDSjTmlvNc9McWuCH_kWHsGMNbIL2bq-i8HWYRqHSosHVNtygicT64I8RtIhwOiPEAzXUdWmU4YLU8Glwlr_O_u95tQYP5jgbm73fpm6ESr9xLczbczvVZXf_g8TYHKzEM93J3urC3GG6xsTey0bsMR2IXRM5MrkM65Ljo65i5cqoAYcGBOm8tvcyRvPAdNA7Vh9_Jjbfl_7jH3zix2Ur5uj-E5gqmf_bIISb7CDWJjrg0AjK-YwpEoHU1fDr-A=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/X_Green_Digital_RGB.png?dpr=2&amp;w=55&amp;border=1%2Ceae8e3&amp;h=55&amp;fit=fill&amp;bg=eae8e3&amp;pad=10&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=40%2C40%2C40%2C40"
  alt="StockX"
  width="55"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-bottom:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="bottom"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPaeEd_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttaiaWUIt-2FyuPQfJXJWnmiTyzimN6DI4FDP4-2FQ1ByUPPBYEfysoCOaB87eo9omh1-2BpFDQKiMhn4KzwZfa4c1xEHtk6gXkYGUGzZTjA2LWY8eDHodUIeu97-2F5T1DWLf4LF5gCL-2Bwb7zA1KYbALKb3iUyk-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPaeEd_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttaiaWUIt-2FyuPQfJXJWnmiTyzimN6DI4FDP4-2FQ1ByUPPBYEfysoCOaB87eo9omh1-2BpFDQKiMhn4KzwZfa4c1xEHtk6gXkYGUGzZTjA2LWY8eDHodUIeu97-2F5T1DWLf4LF5gCL-2Bwb7zA1KYbALKb3iUyk-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw1oxydfVJAMHMaZDLmZAugi">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/rB-ND2FkLdBiFxtVxbJCi0UPcylv2IbvKksA6UDrc0P_fS5HN0eEi3ykbqzcjKoQpUGzAhT0SKAiQiJiUZILE-Ty8lTWv94UdwVl6hZBHafnMsdtTHo=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/facebook.png"
  alt="facebook"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6oYNu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSqIWsyHv6Y32sJ9ykyRtBED437tI40-2BqH73x9VXHS8VwHXlWkmnIQOGEf0tNQuXIS79PQfYgRghJRaUsbHa2BhJm1vMsdfzjCCxzdt0Qq0Key-2BBst-2FIGquE2MqIO47CNLNyBGOrAB7-2FPQAZl-2BJisPU-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6oYNu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSqIWsyHv6Y32sJ9ykyRtBED437tI40-2BqH73x9VXHS8VwHXlWkmnIQOGEf0tNQuXIS79PQfYgRghJRaUsbHa2BhJm1vMsdfzjCCxzdt0Qq0Key-2BBst-2FIGquE2MqIO47CNLNyBGOrAB7-2FPQAZl-2BJisPU-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3DBWcQfUmkzc5d5yKpCBb-">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/NO_jZhAgxzrMrMt5CfIO20kqHmmSdHagMnw-nOEzQp_nSC9_C5BnEfz7tQbZoEVXvypkC4u0q8GtLNsNlVzA-7U6s-LttoBQk38Dj5TIdhkLCIAVnQ=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/twitter.png"
  alt="twitter"
  width="30"
  height="25"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxNLSp4YxOr1AunmDar2oMy2lW5v_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttRFEwaf8j6e2tOM706DlTzBuh3JDFhGPnWQc6Kv-2BAOYcKUb-2BCzpGCRdb6xhTI8kQq6atisTz-2B5DJ4sTEQgaDijk4VZO4bmGV1PkstkotNjM2o01sukAc2HKT-2BsAdvITneAfBsVPjkWi62igBGbPZGuI-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxNLSp4YxOr1AunmDar2oMy2lW5v_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttRFEwaf8j6e2tOM706DlTzBuh3JDFhGPnWQc6Kv-2BAOYcKUb-2BCzpGCRdb6xhTI8kQq6atisTz-2B5DJ4sTEQgaDijk4VZO4bmGV1PkstkotNjM2o01sukAc2HKT-2BsAdvITneAfBsVPjkWi62igBGbPZGuI-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw2s9_iM7JcBurnw1offyGY8">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/L_BgVah88eOU_oX1iFn1yNLtSOqkOf8Uw7DUGCpMxPHSzNAdTBsxNS52QmB6bZVWdBKaAtPQQPTMrtUZAVssUfpYnW3CPmCHx6Du280u2_6rzCA15k7D=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/instagram.png"
  alt="instagram"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHwgO5_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSQHTlLwvn1mM4GQSmKAsQAOXD-2BD4Rsjjsqv8B5PVSSJgEY-2Brku6aFEzXp0gJdzrrBhlgKzfUudVuhfv3BB21wRq0b4LBewk1-2BMdQwANquAc3Tq6WW4PX1KptXli9YiswRa-2FohJIdCbWdVMfiEEfzr8-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHwgO5_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSQHTlLwvn1mM4GQSmKAsQAOXD-2BD4Rsjjsqv8B5PVSSJgEY-2Brku6aFEzXp0gJdzrrBhlgKzfUudVuhfv3BB21wRq0b4LBewk1-2BMdQwANquAc3Tq6WW4PX1KptXli9YiswRa-2FohJIdCbWdVMfiEEfzr8-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw3P7mHb3ox7A5oAR8qvn4YR">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/Q7fEt2mF-3UbTLML5Gi6zIgWY_QwbBysLfJRtex0mAq9-bwi8xhrJv5CmR5xbFDZI6F-wwAic4lbS1Bk_9XQTPx8jePR0_nYbL4PiepA6nmVQdpiJQ=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/youtube.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClUszmG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttT6-2FibNPsCwrVJ-2BgJQ-2F0Wh9zFVQR5rv2sz7mSD8d1IXuc4ajR6pIlCgPxCTQXTxzU3azV3lP0gy-2FyYO-2B0AmNOKw6G5VsZ5CPgOiukji-2FDzBpxyw8XWogOc3MM-2Byb0-2Bd-2FiXLNYkQwZ9O2wR9oFji2kvw-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClUszmG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttT6-2FibNPsCwrVJ-2BgJQ-2F0Wh9zFVQR5rv2sz7mSD8d1IXuc4ajR6pIlCgPxCTQXTxzU3azV3lP0gy-2FyYO-2B0AmNOKw6G5VsZ5CPgOiukji-2FDzBpxyw8XWogOc3MM-2Byb0-2Bd-2FiXLNYkQwZ9O2wR9oFji2kvw-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw0Tz1iYII-lx1pB4_xoSQv3">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/ts38XLNq8N_uScKwbU3w9wTMmszKo5ekGYSzoXmllhdZmKCDZsjF1AOkkC_7Ke2DFlsweHJQbebM_mrQ6jW1tIxhK3gLYLY__Kx2DdCDKA=s0-d-e1-ft#https://stockx-assets.s3.amazonaws.com/Discord-Logo-grey.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="padding:0px 30px 30px;text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:10px;color:#006340"
  width="100%">
  ©2023
  StockX.
  All
  Rights
  Reserved.
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:5px;color:#006340"
  width="100%">
  The
  sender
  of
  this
  email
  is
  StockX
  located
  at
  <a href="https://www.google.com/maps/search/1046+Woodward+Avenue,+Detroit,+MI+48226,+USA?entry=gmail&amp;source=g"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/1046%2BWoodward%2BAvenue,%2BDetroit,%2BMI%2B48226,%2BUSA?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw12jBRL-Vqm6gAEhOerPird">1046
  Woodward
  Avenue,
  Detroit,
  MI
  48226,
  USA</a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:5px;color:#006340"
  width="100%">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3D0IL8_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSVn1Mk8K8JC5r-2FNKgbZKlFv8EpNw4nZq68DuEMe-2Bbwj3Ft-2FZBYK6CynwtYXOGqupd4NQpaQf3dj8y15XsNtT33csKqxdDk42NfLQ9Z53jwSzObU5oG5MXBss4dnR09dAYz5EFn6LcnzQ5ArqgE0Cu4-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3D0IL8_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSVn1Mk8K8JC5r-2FNKgbZKlFv8EpNw4nZq68DuEMe-2Bbwj3Ft-2FZBYK6CynwtYXOGqupd4NQpaQf3dj8y15XsNtT33csKqxdDk42NfLQ9Z53jwSzObU5oG5MXBss4dnR09dAYz5EFn6LcnzQ5ArqgE0Cu4-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw26xWiZ0noa1B6OiNT3Vlie">Update
  email
  settings</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table> <img
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;height:1px!important;width:1px!important;border-width:0px!important;margin:0px!important;padding:0px!important"
  src="https://ci5.googleusercontent.com/proxy/71RtYSzFOedwPCy-YViRa2hteV1bgE9_5WvLDoCOdV44-A0pJUCY3TkswlIIvSC0TWSyJPWidVzibeD1uqlfIXr-JCY9wkTp_bW2kp2oPR9SB6qtCDdbpnf2ayaFkT4QwEy2VDE5XQVmbRj1OVXwtFaotGWozmS9JNKIX7qHNkUNzydjwbTkvfkOQpgovUOG_9CrYXS2-eK97Ndb8GggCYTDwmadjELVBi8R5guNsyoBnqQl3Z31lRAx_ffxOYZ8bMAQB37yzBD9g8kieJJg0PTrdtmevFBjtaC8U69tsPL-xwRlj2avXuZe0N7ZUsUbLhEb2fXMvDq6OBd-oQ5tefbzIPvYOS1A-KOikHqtoGg260uWAmjQCtwzaNQWgB3GBNYGEt1Tef-cPjT1XYEUhh3LzZreuLzSENehJ_poxKa5vcVPf5hy2JU2GDotmnSI1222VJf1GXbkGNZsRjoqvQII5oRE21zZxuMUqiFwgStK5TL8BzEyn4EoLfyGHyxbh4-lKsijyc6dLldOQQeZO7RGOETlG3I9lcl3rB2MxxcEM-rfUiVvN8st8sna0v1w3vC67YFkNLhaV7aU6W2bGpuyArgJkZtTDYZFMYKbVSf8HTQh8svIdMDZ5Anq7sNX4bqxYAsfLb55KXvHTK_v4gtHzesbDr-vWayjrO3-MH9R5UOwQJ1C38beKYGTa50JPzxba4F3ls7gPm2xpmAMM_1kq-d_zFBeou_ffRp7QoftkjBDKUD3VgRMzdiLsfqcLfvhctQ09g5DiM_PE6CqgCXJGlhKAnEHdq8OuKTpVa4K_Q8H_eZjjHGYQ_730UqV9AvMNnvwC_0yN7knhP6hSC0nYVuiZJfW9Wh5u29OOw2MkknZJ2m8MZBTfc2fUW1pWlace3ddnK90bNRQdmk4-g27ySznRLNuXbKMiNZRsIO7aiOJkGoJm2Pg_7JYV_rNvIAdBO9ULFQ1cL-87scxcDJWh-E=s0-d-e1-ft#https://link.tmail.stockx.com/wf/open?upn=gRxMUVBU4yMmfJUAsrxyQtk-2FW5f0l2hSTc-2BWDSLvBPJ9bKMQCDXl4lXCQG6ef665u56jvmthmIaT0wyoEvCVLcbM0v2T7KTm-2Bi71g3NLUmK6jEUBG4FMb-2FiU8k-2FiOAGa4YpYNS37CJxj1StHy94OiJRus2F9Cn1Cl-2FrKADlV4T6p-2BO5WUXXqiyAqOFFU5gjmGwiSTUcHjZ2QAGyUgZH992-2FczzKf3BQDfgzXTMFkNx-2BOtRJiMoKXSuzEUGCJx0sl7ZIifraM2ETRNh0mkk5uK-2F5WBPH5PzmRnldA2wsGm1lAS600umHH4sWQDZ2xilu1jbp5osnLRkRqbtq2a-2BB01CxEIGz1PnqDZggtGt4s6rqsLos3qVMixOpfRTp2Mo2EtBbiASSkW7T9aSdwLVMSlnrb5jN4-2FKn0TCaw0x3nM5Op7pBne16pjOz-2BSiUd0w-2BO9zWOeLV8HjQyq6wsJgvRBMW-2BYKkiDErl87dP562nU-2FoirMbnEPSLIfLZlrfI9Bz2-2BXx0QYHmZCnlx5MPnt2M4gyjk6-2FxuYVVKYAxhMarYh9PtiVYzJbMaNZeKhioeUE4eaZMWyuBEU4jum79uUsPAXK-2BKH58nJSxJ97eFBGCitxakpQDCe5TV1QzNvv6mF2w"
  alt="" width="1" height="1" border="0" class="CToWUd" data-bit="iit">
  <div class="yj6qo"></div>
  <div class="adL"> </div>
  </div>
  <div class="adL"> </div>
  </div>
  <div class="adL"> </div>
  </div>
  </div>
  <div class="adL">
  </div>
  </div>
  </div>
  <div id=":pk" class="ii gt" style="display:none">
  <div id=":pl" class="a3s aiL "></div>
  </div>
  <div class="hi"></div>
  </div>
  </body>
  
  </html>`;
};

export const stockxVatEmail = (form: any) => {
  return `
  <!DOCTYPE html>
  <html lang="en">
  
  <head>
  <title></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/style.css" rel="stylesheet">
  </head>
  
  <body>
  <div class="">
  <div class="aHl"></div>
  <div id=":pg" tabindex="-1"></div>
  <div id=":qf" class="ii gt"
  jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzNTU5OTE2OTQxMDkzMCIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzNTU5OTE2OTQxMDkzMCIsbnVsbCxbXV0.">
  <div id=":qe" class="a3s aiL ">
  <div>
  <div class="adM"> </div>
  <div>
  <div class="adM"> </div>
  <div>
  <div class="adM"> </div><u></u>
  <div
  style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-bottom:0px;width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;min-width:100%;background-color:#eae8e3;color:#000000">
  <table
  style="border-collapse:collapse;margin:0px auto;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="100%" cellspacing="0" cellpadding="0" align="center"
  bgcolor="#eae8e3">
  <tbody style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center" valign="top" bgcolor="#eae8e3" width="640">
  <table
  style="border-collapse:collapse;margin:0px auto;table-layout:fixed;max-width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640" cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center" valign="top" width="640">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640" cellspacing="0"
  cellpadding="0" align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="640"
  cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:0px;margin:0px;line-height:0px;color:#a0a0a0"
  align="center"
  width="640">Your StockX
  order has been
  delivered!
  <br>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122wrapper"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  width="100%">
  <table
  style="border-collapse:collapse;min-width:100%;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0" width="100%"
  cellspacing="0" cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  bgcolor="#D4D1C7"
  width="100%">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="line-height:0;font-size:0px;display:block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="min-height:250px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  valign="top"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;min-height:250px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122bgimageGreen"
  style="background-image:url('');background-repeat:no-repeat;background-size:cover;height:320px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;background-color:#006340"
  align="center"
  valign="top"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;height:250px;padding:45px 15px 0px 105px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D5cQu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttVrtWVeR1CEYE-2BKz-2F0MwQA0MjTs0-2BXTxVVk2c-2FJtBJ-2FWacQPD7WM6EqS1Qvik5vMosHZQ8nh9BGk2JodvTkhWThd9PF1JEKOEkBCpyuOvveWFPVli8eY25ohnzS8QvsvgsEDtIz-2B78RL2C3cn8IFtzA-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D5cQu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttVrtWVeR1CEYE-2BKz-2F0MwQA0MjTs0-2BXTxVVk2c-2FJtBJ-2FWacQPD7WM6EqS1Qvik5vMosHZQ8nh9BGk2JodvTkhWThd9PF1JEKOEkBCpyuOvveWFPVli8eY25ohnzS8QvsvgsEDtIz-2B78RL2C3cn8IFtzA-3D&amp;source=gmail&amp;ust=1692892263918000&amp;usg=AOvVaw361-hO8RTdRgAOuSrRC-uT">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#d4d1c7"
  src="https://ci3.googleusercontent.com/proxy/muCmpQqhW-d2-M5t28iRxF7R0GOzUvg41IYR3mN4Xi6s_4E8VyzW4vxQ2S78N7fXpK5FdZUBL9jvWk3n4a_WPYm1dlFw34WCTFw9eQg3-u503-9D-txNSVUbepMq-1w1cbaXWopGplXQUh7jXTOH=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/StockX_Vertical_Gray_Digital_RGB.png?w=26&amp;dpr=2"
  alt="StockX"
  width="25"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="padding:40px 55px 40px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  width="50%">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnzbM_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTHjbNz-2FwWHGFZ-2BZl-2F8t3W7T82sDUYPnQR48Nss-2FuiFm5e4oABjcjo0KPsxfUncciWgNi0vEmvgvZ5iUavYz5wZYcdeE9rAQ-2FK9c3A912gWTyYNH2U91Bh8CTgH6EfcQj2y3u9ibj3OX8n3U9urupmA-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnzbM_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTHjbNz-2FwWHGFZ-2BZl-2F8t3W7T82sDUYPnQR48Nss-2FuiFm5e4oABjcjo0KPsxfUncciWgNi0vEmvgvZ5iUavYz5wZYcdeE9rAQ-2FK9c3A912gWTyYNH2U91Bh8CTgH6EfcQj2y3u9ibj3OX8n3U9urupmA-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw2gGpR8EDKoZcsHHHxZVP_G">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci4.googleusercontent.com/proxy/wGin-PZspav7xTd9PfPJAjTyj-AUtQ7yXRM2T7lBXXpsg9jPnlY2pInePlkOf9bLTEymfLCbxU263MvwpkHHKgsy-SFy_jR0Aqwz_lOwZGOFlt_5piw54ResVBiuZb4AXAhBXXzJMW_VRqPiqLxnouTC1yLPv3iutpgNI0qYVdVlp9jCbbbu_S8vY-3KTQuaNeU-8u6v_V5goWqh7y0Q3VKXxY35LWIWuDjafethtJrRsBNDA4Y_K_Dq1RBhVVrDXFclsH79xbdBRkaf2Ol205Zgs5DlDBT6SI9CzyhVvNUxHnEjftIQbWL1gbawzDHiAevljQ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b051ordered-icon2.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="left">
  Ordered
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnOOf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttd7-2BFu8BciJcbFIEKEaYqJdCmwHBr3bXSlVsqhkZsQks2n9QRRtnp-2FwwSCyUV5DSZsyDVDesvey8Zo7XDh96t9yEmxk0nS54EQJXezUZC-2FnT-2Fiab41-2FX9-2Fgr2Se0Ym1jmKstazCnRN3HpMOrANw3UZg-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DnOOf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttd7-2BFu8BciJcbFIEKEaYqJdCmwHBr3bXSlVsqhkZsQks2n9QRRtnp-2FwwSCyUV5DSZsyDVDesvey8Zo7XDh96t9yEmxk0nS54EQJXezUZC-2FnT-2Fiab41-2FX9-2Fgr2Se0Ym1jmKstazCnRN3HpMOrANw3UZg-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw1a9jh-wnUwyfAEbobzE9lS">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#d4d1c7"
  src="https://ci4.googleusercontent.com/proxy/O33NNBC3yUiMvQKhC9IIxFy05ekUvaTrsZU-9Rxcj2qq1fKPv8tduELBqXDE8mO1FvZZhxAappYbPmI9Gcyawe1njm1Ds-8KUFqZq7wkFfPIDaIXXaxvsS3K41zfFeMn2eUpPGRydVZGJB5wRSDTCL-H6izWHtGfz6GBjq4aB5poTUF0GNcgFArdwp2MJbpCgR1biVZJx-iwD3qKQ5gUzEri2i_attMpypEpSvIXgZeH7W4xNsBaM7pJ_Y9euHbj0mAMMiaOBTvH7qDL_soj3v6tB68n5leYZ-gsfrxOwwQKDFVHtQDraXw1JTT-eNcYRPcwM8kLx0mRw-CJ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b052shippedToStockX-icon2.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="right">
  Shipped
  to
  StockX
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3De-zK_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfXhH-2FMI7v2Cgvukh8oVq3EZI1sKEUrBNyXCfM-2BAdojXuXEFB-2Bp9GQgXYLd-2B95Remm3g1AlSTJJ8GOFttK-2FCLqWzRANWYqvAgmdg36wEbP5v-2Ba9X8jYQtSBAYDS3lxLo67CM98gqSFjM3p9a3cUjydY-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3De-zK_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfXhH-2FMI7v2Cgvukh8oVq3EZI1sKEUrBNyXCfM-2BAdojXuXEFB-2Bp9GQgXYLd-2B95Remm3g1AlSTJJ8GOFttK-2FCLqWzRANWYqvAgmdg36wEbP5v-2Ba9X8jYQtSBAYDS3lxLo67CM98gqSFjM3p9a3cUjydY-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw3G1mT4-t5HGsEzmShpdNrO">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci6.googleusercontent.com/proxy/E-5Nrbb8x2O73YH6te4RGNca0ZKp3XsZcRR0dPy6DNPV3_lDPNUCU7W2h76IGH7zC3x10g6gpiZQW82YsmHFkd-PCNOHs-Fh2Sez4QqeD8rr-B_PwSozbO7xnp0uB1z-GN-YA31b9cSoldtGQJJ7T8IRnTRat_Zpo-zA786cb4XuOtwjYOJI4_0r1Nn8EGB1C09oPtTDy-FFwoZQElM25w8noidhlWWaIhTuGIHh31a9JXLEXIv1z6S3GRpMneJsZmSbH-kDN1WOkQxuUJ5c1GSu5cCPq0_w6zs8BC9mztt0ICQB8bbnmda0002xSHRoVI7ErbDy=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/ArrivedAtStockX_bid.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;padding-bottom:10px;vertical-align:middle;color:#000000"
  align="left">
  Arrived
  at
  StockX
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DZ7k1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttUpox7NLhOeK1h930V7US7y6zltMR-2FmiPJ3wATox425m8L4Q-2BgH65Ep-2B-2FIPFgv3NeJR0u9Xa9ffJ9JPDjbFrlFsWeWEO3ptTx0zSjCpfoJ6UHtP-2F9ekf6VogMdUMuQFX5-2BkBXbAdsCFlBdaAn1sAyh4-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3DZ7k1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttUpox7NLhOeK1h930V7US7y6zltMR-2FmiPJ3wATox425m8L4Q-2BgH65Ep-2B-2FIPFgv3NeJR0u9Xa9ffJ9JPDjbFrlFsWeWEO3ptTx0zSjCpfoJ6UHtP-2F9ekf6VogMdUMuQFX5-2BkBXbAdsCFlBdaAn1sAyh4-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw339hsS3ZkJ2Z2nRCJZ2W-r">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci4.googleusercontent.com/proxy/iNQJ6pvYuTFfeZ354GdEgbajAngl5zNYIrAkf1x05iD_mWd2dth1paf9Vta6Jb6WDmiZYwY-rJsnboOUGTK8vfFa5ovcuEJ4ICiXEOpb-6JDXnUz2uEMkrUnaVzLg5s40IQt-xF5QTJ4w-GpBsxDnY-v1xAlYjuZH1983irc0Yf0DFLKJ8TULrWd9O4msR3mlwjisqOLALOaJ7TH9vif-7z8KcwNZadtrPIHdWEbqY_QtVVpfEOgBGTn-47qHPeyTECS6msQakSnN8cPLGg3ta7dKwGzA035N7VJXMVD0yHZ6Pt2-L7rCQmojCCwxm9eDFGk-_kH=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b053shippedToBuyer3.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=000000&amp;fit=fill&amp;border=1%2C000000&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;vertical-align:middle;padding-bottom:10px;color:#000000"
  align="left">
  Verified
  +
  Shipped
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;padding-bottom:10px;color:#d4d1c7"
  align="left">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3D_GdG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfM-2ByR08Sq8lnrD-2BgZgiDD1dxUzOoMuFu7NMdRoKGB5DuXJqShBK-2BZG9eyGy-2BlaEfA0KFHXgBe5lXFwyHIehM4Zr1gCg9PZGNP4KGLWfrqrUoY2oZhv0aJi-2BLB7pG0qb8qbY-2B4j7w5bEk5yXgPrn6y4-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7X9f8uJn6rhchk0z2KrlpknA-3D-3D_GdG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfM-2ByR08Sq8lnrD-2BgZgiDD1dxUzOoMuFu7NMdRoKGB5DuXJqShBK-2BZG9eyGy-2BlaEfA0KFHXgBe5lXFwyHIehM4Zr1gCg9PZGNP4KGLWfrqrUoY2oZhv0aJi-2BLB7pG0qb8qbY-2B4j7w5bEk5yXgPrn6y4-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw2URHY3B3-lbMCVQCT4XOJZ">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci5.googleusercontent.com/proxy/tjUNdPU5iBMSvZXjEs1MJMg4N1a2oKWeRBKzGCCQgidBUOhheiwBtdMCruzNzKSRgd62iW5iu2EVd7Z70Hc1hcCc_osO1UlHYAu-yHWpyDaYT5zXB1ZU_nnZGD84cFyKk89VAodVXlhw6FP3ePhPu7GzK7R_l7VNs2xdeR42fmlgQMP9yXkKGUNHenyr7nVlXAagCkP5YjBmUD4u58OL-KUJVjfAOwJBiFw9pW3yY4V8jipSFeO01oEPmmhY0bI0gfv2nUglSD3cXF6NrVOljQkaL0NXTdrs5M_geJCYgKUPqQ4vb6Ne--xDCNACFmH8dF4LdXJmANQ=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/transactional/buyer-icons/b054delivered-icon_v3.png?dpr=2&amp;w=100&amp;fill=solid&amp;fill-color=D4D1C7&amp;fit=fill&amp;border=1%2CD4D1C7&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=50%2C50%2C50%2C50"
  alt=""
  width="40"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:22px;text-decoration:none;text-align:left;line-height:26px;font-weight:400;padding-left:15px;vertical-align:middle;padding-bottom:10px;color:#d4d1c7"
  align="left">
  Delivered
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="640">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="320"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:45px 175px 45px 45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  height="100%">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3DduC-_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc23g65RVWC1lM-2BK-2F9pYv7ntbYraPLLrnZN8cykczq9cTAxVRoLrqDa0wqNdnilUCTYN4wY7UyRr1Lh4uyx4lprRkBzBIEamWn83j-2F9Uh0ZrSGuj2FbUMnFYwD1-2Bb1yZnkGBfnAu5mB1DvpYYHgY4Eo-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3DduC-_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc23g65RVWC1lM-2BK-2F9pYv7ntbYraPLLrnZN8cykczq9cTAxVRoLrqDa0wqNdnilUCTYN4wY7UyRr1Lh4uyx4lprRkBzBIEamWn83j-2F9Uh0ZrSGuj2FbUMnFYwD1-2Bb1yZnkGBfnAu5mB1DvpYYHgY4Eo-3D&amp;source=gmail&amp;ust=1692892263919000&amp;usg=AOvVaw0sirRjMOgcEPOXasBWv2O-">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;color:#000000"
  src="https://ci6.googleusercontent.com/proxy/D_y8TCzuOHP4F7c4FU_6u5TNWv4WJVar97J_2d0sG9W6fIfyRV_oruj7XpKX4AoRphkIuhVpl6heMXyD6pw2_UdoZSTBVVHwObhsuOOxojmWoZIOYqLt1_57npfMuifpOk7e=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/X_Black_Digital_RGB.png?w=100&amp;dpr=2"
  alt="StockX"
  width="100"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="320"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  valign="top"
  bgcolor="#D4D1C7"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122subheaderTextPostPurchase"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  valign="top"
  width="320">
  <table
  style="border-collapse:collapse;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:'Book Antiqua','Palatino Linotype','Palatino LT STD',Georgia,serif;font-size:28px;text-decoration:none;text-align:left;line-height:32px;font-weight:500;padding:40px 40px 0px 0px;color:#006340"
  align="left">
  Order
  Delivered
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:16px;text-decoration:none;text-align:left;line-height:24px;font-weight:600;color:#000005"
  align="left">
  Delivered
  on:
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:16px;text-decoration:none;text-align:left;line-height:24px;font-weight:400;color:#000005"
  align="left">
  ${form?.delivery_date}
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  width="640"
  height="auto">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;margin:0px;padding:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  width="260">
  <a href="https://${form?.item_link}"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://${form?.item_link}&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3e1r6vtwiSIsZe2DwK_n_F">
  <img style="display:block;border:medium;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:22px;text-decoration:none;text-align:center;letter-spacing:1px;color:#006340"
  src="${form?.image_link}"
  alt="Jordan 3 Retro White Cement Reimagined"
  width="260"
  height="auto"
  class="CToWUd"
  data-bit="iit"
  jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
  </a>
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  width="280">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:24px;text-decoration:none;text-align:left;line-height:30px;padding:30px 15px 15px;font-weight:500;color:#006340"
  width="280">
  <a href="https://${form?.item_link}"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://${form?.item_link}&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3e1r6vtwiSIsZe2DwK_n_F">${form?.item_name}</a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;padding:0px 0px 0px 15px;color:#000000"
  width="280">
  <ul
  style="list-style-type:none;margin:0px;padding:5px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Style
  ID:&nbsp;${form?.style_id}
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  ${form?.size}
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Condition:&nbsp;New,
  StockX
  Verified
  </li>
  <li
  style="list-style-type:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  Order
  number:&nbsp;${form?.order_number}
  </li>
  </ul>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;text-align:left;font-weight:400;padding:15px 0px 0px 15px;color:#000000"
  width="280">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Purchase
  Price:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.purchase_price}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  VAT
  (incl.
  above):
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.amount}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Processing
  Fee:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.processing_fee}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:600;min-width:200px;color:#000000"
  width="200">
  Shipping:
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:right;line-height:16px;font-weight:600;color:#000000"
  align="right">
  ${form?.shipping}
  </td>
  </tr>
  </tbody>
  </table>
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:0px;text-decoration:none;text-align:left;line-height:0px;padding:5px 0px 0px;border-bottom-width:0px;border-bottom-style:solid;border-bottom-color:#000000;color:#ffffff"
  colspan="2"
  width="240">
  &nbsp;&nbsp;
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:14px;text-decoration:none;text-align:left;line-height:18px;font-weight:600;display:inline-block;min-width:200px;text-transform:uppercase;color:#006340"
  width="200">
  Total
  Payment
  </td>
  <td style="text-align:right;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:14px;text-decoration:none;line-height:18px;font-weight:600;color:#006340"
  align="right">
  ${form?.total}*
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:center;line-height:16px;font-weight:normal;padding:15px 0px 30px 15px;color:#000000"
  align="center"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-radius:2px;padding:8px 18px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  bgcolor="#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7XfsLHDYAwZZpIn9Z6XRqUs6AIPmBcDOpzV6Ot47iN7ywTFdrt73bTpC2I7Belb8P5aM3uFK4ypp5lTk1k5FIsCutbZRbTU9in-2BVFzGZk0TYI-3D5lgH_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTtPb68CO9656-2BR8gOtiKBpEXOW9-2BRnSuKl-2FOTYFTRv-2BCdugbRIWjJj-2Bq68TlFFEGjIc-2BYyc33LGabBwxEAr94sygQGS-2F-2FnMMQXxEDZcPmPY-2FNngGk-2FmIxdYPMejXDHEWLFmZFCtlC52SlzPMyFb04g-3D"
  style="font-size:20px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-decoration:none;border-radius:2px;border:0px;display:inline-block;line-height:35px;padding:0px 10px;font-weight:500;color:#ffffff"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2FS7-2BMqhehldXWtLoAXBwywpZDHru09gtJRzdPmDCz7XfsLHDYAwZZpIn9Z6XRqUs6AIPmBcDOpzV6Ot47iN7ywTFdrt73bTpC2I7Belb8P5aM3uFK4ypp5lTk1k5FIsCutbZRbTU9in-2BVFzGZk0TYI-3D5lgH_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttTtPb68CO9656-2BR8gOtiKBpEXOW9-2BRnSuKl-2FOTYFTRv-2BCdugbRIWjJj-2Bq68TlFFEGjIc-2BYyc33LGabBwxEAr94sygQGS-2F-2FnMMQXxEDZcPmPY-2FNngGk-2FmIxdYPMejXDHEWLFmZFCtlC52SlzPMyFb04g-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw3s2d4DOvx_SfvtvljvOUnR">View
  Order</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="left">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px 0px 15px 15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:13px;text-decoration:none;text-align:left;line-height:16px;font-weight:300;font-style:italic;color:#000000"
  align="center"
  width="100%">
  *All
  applicable
  duties
  and
  VAT
  are
  included
  in
  the
  total
  price
  of
  this
  item.
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122topcopy30"
  style="padding:30px 20px 15px 105px;line-height:0;font-size:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  bgcolor="#D4D1C7">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:400;padding-bottom:15px;color:#000005"
  align="center"
  width="100%">
  Thanks
  again
  for
  choosing
  StockX!
  Don’t
  forget
  to
  remind
  people
  that
  you
  #GotItOnStockX
  by
  showing
  off
  your
  latest
  purchase
  on
  social.
  We
  suggest
  leaving
  the
  StockX
  tag
  on
  for
  the
  pics.
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-top:15px;line-height:0;font-size:0px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-bottom:30px;line-height:0;font-size:0px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="left">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="bottom"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPpnyf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttXOIdVh71Y4yBSckt1Z0vTeGVmx4Lb7S9fYv5Uhu-2BxZHxDduDRaPIhhQic3-2BHuL4lR-2FF1neZGIkCtA7GIm9UHLVWjlpdRQ9OEMGAVugf7BQiEIUiVeKuI8vFPwFKZwWDzHUO-2F2wj99LGy5vaSMAqNak-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPpnyf_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttXOIdVh71Y4yBSckt1Z0vTeGVmx4Lb7S9fYv5Uhu-2BxZHxDduDRaPIhhQic3-2BHuL4lR-2FF1neZGIkCtA7GIm9UHLVWjlpdRQ9OEMGAVugf7BQiEIUiVeKuI8vFPwFKZwWDzHUO-2F2wj99LGy5vaSMAqNak-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw2dJ1_LKcTD7iuqJW3SrSp4">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/kU2Anna_KfAyUPUHG1krlOWNFDR5g2Xd7txJkkkFbJQc9YdHk7jwk5bTQQrHSQckfOeIi0abMiYMnCRzSWgHIMjD5bsRUE780AMcMqKWb3LibuJXmd4Hra5y=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/facebook.gif"
  alt="facebook"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6-b8U_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcge3E-2FZAAacgpl0i6ABRKne5oTYGuWkPeidRKEk1DKoRXEhfTRqEcQwdST75ASoNtSKbYIFFGIMjUd35ytzZhJ4aFZTY7hliXs8Q2I1nqJ9OCu9-2BCAgbsQjl338UPK4k0XjSUEvxebBI3olbLCr2gY-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6-b8U_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcge3E-2FZAAacgpl0i6ABRKne5oTYGuWkPeidRKEk1DKoRXEhfTRqEcQwdST75ASoNtSKbYIFFGIMjUd35ytzZhJ4aFZTY7hliXs8Q2I1nqJ9OCu9-2BCAgbsQjl338UPK4k0XjSUEvxebBI3olbLCr2gY-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw28ly5ibgqsnvCiAyBKn4Cw">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/IsSRGmVZs4_APEsLplGjM2monuZLFaAqlMwofRn0YBYEA0WO6hpNRWv67LT5Gwt3SF9oX6ummIMStvRdoAfIgGPC34ZPMt29bqJvwO7vw-xgaKlnQPHBO60=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/twitter.gif"
  alt="twitter"
  width="30"
  height="25"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxPc0dZ-2FaTNy2lEyzahPZBa8x9dj_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfcCGj7PDaJoGoKnWhcvbfENvKYp6T61hW6XEuzfY8JMU817ral4ik4NC-2FdvMXuHa8i-2Fs47hHlhdpCEkvXFf0vKwRgdibn6EpIL-2F4EuEZu0aJwLjd6Ku1InJAORywg4nQkFmEJCHpTbCsAegJHFW5FI-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxPc0dZ-2FaTNy2lEyzahPZBa8x9dj_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfcCGj7PDaJoGoKnWhcvbfENvKYp6T61hW6XEuzfY8JMU817ral4ik4NC-2FdvMXuHa8i-2Fs47hHlhdpCEkvXFf0vKwRgdibn6EpIL-2F4EuEZu0aJwLjd6Ku1InJAORywg4nQkFmEJCHpTbCsAegJHFW5FI-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw2KpKBl2JNqtyhhROCLZR9q">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/pdvlrlwiDu1EQ0b55wIibc-wmOmF8Tmk4qFrnBDQRuiZqwDHVeJ8p4975f_nx_2zLclMO4hOajS5o0pwpunev08lyK6II-mdgJCrwXrtdCgAsEnqjW5Nnt9Y9g=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/instagram.gif"
  alt="instagram"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHq1DJ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttdy4SaD66SIIS-2B9Iucyr-2F-2BXuiJGhPh33549aBWcKVXyeC6XPP8bKrtCA-2BzgnlVB1gB9Mj6NGltwR9HbqT9hm6V4L0eia7v9mOTAkX4Zdcg-2FLR7a1AFqap0UAZ-2Fqdt2iSbtKWi89qobh3SWrTfbqcLiw-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHq1DJ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttdy4SaD66SIIS-2B9Iucyr-2F-2BXuiJGhPh33549aBWcKVXyeC6XPP8bKrtCA-2BzgnlVB1gB9Mj6NGltwR9HbqT9hm6V4L0eia7v9mOTAkX4Zdcg-2FLR7a1AFqap0UAZ-2Fqdt2iSbtKWi89qobh3SWrTfbqcLiw-3D&amp;source=gmail&amp;ust=1692892263920000&amp;usg=AOvVaw1zg1_uXA6alHSI8qGMHMuo">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/oDqYerJ6hsLj5YpocdcAXiQhJ8CykCKKQR1bszNScGipWFnFUF2ENV3SpfvKZYzHA_zK0PpHvj1yiIuTg9f6FnTh7hDUOqWpqDhHblRkFwff5p9gG6lBVcg=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/blk/youtube.gif"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClU8H49_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSg6jQJ7ZsImS6ves8DQYeum6h4h5WyalKbcGPJnappxF0YEgrfKTsx38DqU3C7mCVUFiitdyxtEJNSsTBiLPNP8hWgF9bmFrMJ-2Fw521Y6dwOLHB8wG-2Bld4LDFmryFGep1xl8knbWzYDLJ54EZ9WQ2c-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClU8H49_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSg6jQJ7ZsImS6ves8DQYeum6h4h5WyalKbcGPJnappxF0YEgrfKTsx38DqU3C7mCVUFiitdyxtEJNSsTBiLPNP8hWgF9bmFrMJ-2Fw521Y6dwOLHB8wG-2Bld4LDFmryFGep1xl8knbWzYDLJ54EZ9WQ2c-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw0pI7ehqO4PxYPLaXmEyHie">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci4.googleusercontent.com/proxy/EJUu4K2VkK5bvTz3nX5t3C88DOYJ_Vn-FXEWCijXWCBt14-RmUGlDR5Gnu3JjLwoFsmBPEdNv8jW-5Lw9smlT7KvOSXMwfhrVol0CI8rUEg=s0-d-e1-ft#https://stockx-assets.s3.amazonaws.com/Discord-Logo-black.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="line-height:0;font-size:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:30px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="2"
  align="center"
  bgcolor="#D4D1C7"
  width="100%">
  <table
  style="display:block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:600;padding-top:0px;padding-left:105px;padding-right:105px;color:#000000"
  colspan="2"
  align="center"
  width="100%">
  Frequently
  Asked
  Questions
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:normal;padding-top:5px;padding-left:105px;padding-right:105px;color:#000000"
  align="center"
  width="100%">
  <ul style="margin:0px 0px 0px 15px;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:20px;font-weight:400;color:#006340"
  type="disc">
  <li
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:18px;font-weight:400;color:#006340">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYeh-2B3kwF5a3nRMv3JukgzGiOAnmKIykX0ZWtP0QNN-2FkWfnTExyiucaWJWVSwKY4CtwvB60L-2FhsFOIGxBvWY6SEfci6GMjDS95xtePff048gfzPZo8dKWqaSvp-2B1TfdkZMJfelT9g-2F43VW7CopmNEicvmC9KHeHEuXlvso9fjpS87he72ycJOa7LIHQm4Z-2FdFt1kWXG0kEK27Ib8N-2FncAcm21p8dlG49Hgkw0Jd89OPuKfrneg3klhWduxq1VGDIpjnYtL6J6yIr-2BJGy-2FLqd5Ke-2Fg-3D-3DdKru_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfy9GqQFWi5d1ozYXlS47b5DdqC-2BTtCwcdBcDHy3Laq5mtpTVlcgZ-2FwN9ekH1ALJahvgEDd85nWqOypsM55bILZDzR4SJBDkHsO8QjlOkr6N0FfB-2B4JLytDH3d5RdNB3zzjv2NUYjRnuxnDBRZB8sSk-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYeh-2B3kwF5a3nRMv3JukgzGiOAnmKIykX0ZWtP0QNN-2FkWfnTExyiucaWJWVSwKY4CtwvB60L-2FhsFOIGxBvWY6SEfci6GMjDS95xtePff048gfzPZo8dKWqaSvp-2B1TfdkZMJfelT9g-2F43VW7CopmNEicvmC9KHeHEuXlvso9fjpS87he72ycJOa7LIHQm4Z-2FdFt1kWXG0kEK27Ib8N-2FncAcm21p8dlG49Hgkw0Jd89OPuKfrneg3klhWduxq1VGDIpjnYtL6J6yIr-2BJGy-2FLqd5Ke-2Fg-3D-3DdKru_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttfy9GqQFWi5d1ozYXlS47b5DdqC-2BTtCwcdBcDHy3Laq5mtpTVlcgZ-2FwN9ekH1ALJahvgEDd85nWqOypsM55bILZDzR4SJBDkHsO8QjlOkr6N0FfB-2B4JLytDH3d5RdNB3zzjv2NUYjRnuxnDBRZB8sSk-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw3HRPF9IvDMSUeeuD-jaUaF">What
  is
  the
  StockX
  Return
  Policy?</a>
  </li>
  <li
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:15px;line-height:18px;font-weight:400;color:#006340">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYedpWZgszC-2BNZCYsabL2sa6oOfBW-2FWScDdn-2FfiSZB-2FmEtdQ12Q0pxBuRm8sTK8wHey9yaVfcAI25-2F-2FR6Sb-2FHcWdG8yiVRtwIOdK9Xgqq-2Fg2pzb-2BLdfrm4q9jF6VfEuQWpYbUMNFki4ggHbiQsHb-2FqssBvfPyoCh58b9GfuGaNUYUW3QW3r7GCqkkizP4HEncwePN-2BqqqZwOObAG-2BTEYzWKn394PUT5hvqcig5gok3DJoOwHNxE6t0FggRyeX5SMs-2FK71P5L-2F0RAiGY-2F-2FNFjFjmwstfl0AJP-2F3-2BYacbXsQXnKPrk5OXxqgfQA0HDEgoMHZVxpcp_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttReb1i3yF8bwZ4-2FI4wFjeqZvZlCFKY3bfQ2ng-2By1iqhDLmXwx2S-2B2h-2FhMkmTx6qtZnRU-2BVQyvRyzF8d2rTAo67wGd6MJ9uC0RD42BpqT5ZvAmvCrNoLY1pAeFpl4-2Bdv0WYhZrUgtAZOuXdQmEsqJfpg-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7umMHYPoRx27ZwaI5gZLCxYedpWZgszC-2BNZCYsabL2sa6oOfBW-2FWScDdn-2FfiSZB-2FmEtdQ12Q0pxBuRm8sTK8wHey9yaVfcAI25-2F-2FR6Sb-2FHcWdG8yiVRtwIOdK9Xgqq-2Fg2pzb-2BLdfrm4q9jF6VfEuQWpYbUMNFki4ggHbiQsHb-2FqssBvfPyoCh58b9GfuGaNUYUW3QW3r7GCqkkizP4HEncwePN-2BqqqZwOObAG-2BTEYzWKn394PUT5hvqcig5gok3DJoOwHNxE6t0FggRyeX5SMs-2FK71P5L-2F0RAiGY-2F-2FNFjFjmwstfl0AJP-2F3-2BYacbXsQXnKPrk5OXxqgfQA0HDEgoMHZVxpcp_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttReb1i3yF8bwZ4-2FI4wFjeqZvZlCFKY3bfQ2ng-2By1iqhDLmXwx2S-2B2h-2FhMkmTx6qtZnRU-2BVQyvRyzF8d2rTAo67wGd6MJ9uC0RD42BpqT5ZvAmvCrNoLY1pAeFpl4-2Bdv0WYhZrUgtAZOuXdQmEsqJfpg-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw0LfLSfumKhue_eq4Na0_zP">What
  does
  the
  verification
  process
  entail
  for
  Buyers?</a>
  </li>
  </ul>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122headlineBox"
  style="padding-bottom:10px;padding-top:10px;padding-left:50px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  bgcolor="#006340">
  <table
  style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:25px;text-decoration:none;text-align:left;line-height:30px;font-weight:400;color:#d4d1c7"
  align="left"
  width="640">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb3VtjuBuM0gmQ1zo0P0iNdXSBgs5yTW4VoWYSdXfTK2DcGt73kb7bptM409p6bKL8jMKV4IQhJprRTWkyo7R1j2rrDHJ8k-2FYyrXjUGxV-2Bur3D-2FVM8mpO8izOfIiqKP5hoA-3D-3DatSQ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttX9ARtJ8-2FfMVoVErcLDZe-2Fxwr42ftq-2FDQYe2vYKa5oiGfLY3ORDFzmwq2HC4UQrww2LurbdJe8oeWW7WwKLehEVylz0joB-2B1AoM6Niejpccg6KMzLzLmLeiWsWaZY1cHMkdLCxrH0xzz4Dv3nNJy-2F1Y-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#ffffff"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb3VtjuBuM0gmQ1zo0P0iNdXSBgs5yTW4VoWYSdXfTK2DcGt73kb7bptM409p6bKL8jMKV4IQhJprRTWkyo7R1j2rrDHJ8k-2FYyrXjUGxV-2Bur3D-2FVM8mpO8izOfIiqKP5hoA-3D-3DatSQ_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttX9ARtJ8-2FfMVoVErcLDZe-2Fxwr42ftq-2FDQYe2vYKa5oiGfLY3ORDFzmwq2HC4UQrww2LurbdJe8oeWW7WwKLehEVylz0joB-2B1AoM6Niejpccg6KMzLzLmLeiWsWaZY1cHMkdLCxrH0xzz4Dv3nNJy-2F1Y-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw345zlg6NSI7vb1HipdTTCe">Picked
  For
  You</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td id="m_-125385995880698122container"
  style="border-collapse:collapse;padding:20px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  colspan="3"
  align="center"
  width="640">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border:0px;border-collapse:collapse;margin:0px auto;padding:0px;display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  width="640">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px 14px 0px 28px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDe-2BRmH2x2pcH-2Bzt-2FliSkZhYnsjoJvW1MbCww2rxLbxfiK76NfqG6dpQlOm-2FL-2FeD9-2BAzcRmU3iOmD47S-2Fo0PZQtHmWyLvHXbIu1fZ4fqis0EPHDrpaFetgXKlVqMlOShHOsFHrpo0kIm-2BA67kloSvDaIKLpL_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZxXimj67qOpg0eBsHUpUXBg4qZ10O7Fmw9v3NifaHAoRod8A5S-2FXsOaIgn6be-2FHuqOrNNwXCHp11wZVfoIM-2FJkzoCvHnCygiTS8yPq1VQ6I6iRSyy2SphfRFJMZyGKm1xnc8YlPm7PfUsniDYb4Fuk-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDe-2BRmH2x2pcH-2Bzt-2FliSkZhYnsjoJvW1MbCww2rxLbxfiK76NfqG6dpQlOm-2FL-2FeD9-2BAzcRmU3iOmD47S-2Fo0PZQtHmWyLvHXbIu1fZ4fqis0EPHDrpaFetgXKlVqMlOShHOsFHrpo0kIm-2BA67kloSvDaIKLpL_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZxXimj67qOpg0eBsHUpUXBg4qZ10O7Fmw9v3NifaHAoRod8A5S-2FXsOaIgn6be-2FHuqOrNNwXCHp11wZVfoIM-2FJkzoCvHnCygiTS8yPq1VQ6I6iRSyy2SphfRFJMZyGKm1xnc8YlPm7PfUsniDYb4Fuk-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw2umaZ2naIwhp0kMRVxiRk-">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci3.googleusercontent.com/proxy/svOJyZuHCPyVGrJw0Rdh_ihKqvJjCYNjrHfJDid8rjHDHkCa9W6mAr5P-RO6ctc2eMY2jDY85YPMrUhlptjgx7IgNQvvrMXfsWwLgjmmdF9loL6GpgqG4XyZWD564mHrpojn6g=s0-d-e1-ft#https://images.stockx.com/images/Nike-Dunk-Low-Retro-White-Black-2021-Product.jpg"
  alt="Nike Dunk Low Retro White Black Panda (2021)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Nike
  Dunk
  Low
  Retro
  White
  Black
  Panda
  (2021)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="padding:0px 14px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Bi9J-2BAWxsYIzMzwcNH0etGfN5LuyaLekYUB8x5I0GQd0MIDAl-2BO9TkvOEjjndAYBNgkrEOq0NG6-2BkXn7YiJF-2FSp52GTGFWafh7jQ8E7o1llJtYXv-2FTNhDFdzul84G68U-2BthaoY85H28c-2FmfRFViKsm6l-2FnJoFRhi3-2FXXkwycKx3aNPXavlkiDZgD3gHMIkYoQ-3D-3DBK6M_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc53GjkWS-2FfL6oiorR6wGzZ83eJ0N5mpMrBEfO18-2F30lmAdyFtG0U35366lm10R5rytWO5iG-2FlvBC-2Fsu3SvFZd0zDrOwtJiUGzQzy4vG1J754ym4iIjvw7HCQDw5uyHmk-2BL7-2Fiqo8i50THNSg5daaqM-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Bi9J-2BAWxsYIzMzwcNH0etGfN5LuyaLekYUB8x5I0GQd0MIDAl-2BO9TkvOEjjndAYBNgkrEOq0NG6-2BkXn7YiJF-2FSp52GTGFWafh7jQ8E7o1llJtYXv-2FTNhDFdzul84G68U-2BthaoY85H28c-2FmfRFViKsm6l-2FnJoFRhi3-2FXXkwycKx3aNPXavlkiDZgD3gHMIkYoQ-3D-3DBK6M_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttc53GjkWS-2FfL6oiorR6wGzZ83eJ0N5mpMrBEfO18-2F30lmAdyFtG0U35366lm10R5rytWO5iG-2FlvBC-2Fsu3SvFZd0zDrOwtJiUGzQzy4vG1J754ym4iIjvw7HCQDw5uyHmk-2BL7-2Fiqo8i50THNSg5daaqM-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw1ra2TtQDPItEDpp7cVbtvg">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci5.googleusercontent.com/proxy/mTwucrH-GQCDjELI9tKT0ySrs-CfNEtROGlCZSkCuZDFOPkGCDIAn2WgE2g2nxQM0OY0jhGrnH3-RRc05revIwckqy_v0I55BuFA0_vR9zawpncP-9Kyk9Yr5r9ael89Mtw5wUmJ-6UlrX4i2CY0Qx4=s0-d-e1-ft#https://images.stockx.com/images/Air-Jordan-1-Retro-Low-OG-SP-Travis-Scott-Olive-W-Product.jpg"
  alt="Jordan 1 Retro Low OG SP Travis Scott Olive (Women's)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Jordan
  1
  Retro
  Low
  OG
  SP
  Travis
  Scott
  Olive
  (Women's)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  <td style="padding:0px 28px 0px 14px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="top">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="font-family:Arial,Helvetica,sans-serif;font-size:18px;text-align:center;text-transform:uppercase;border:0px;color:#000000">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDcvo3B9PufsUvdHMoqACJK7gFMYQH6jtSG5XIxww3tJmP8L1hPBL4b7WQudj2fMfQ7mtg34alJtNodTHqa-2FuTOMOwX-2FGA-2F9-2F3QuIBI7craRu076vg7Cc0fXi-2BNVmktWlo59hMC5E-2FCc0rRvR8uMe8K-2BzHR4_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcHD-2FWF-2BoYUqox6W7SAkBtlkA9E-2BkeE5iW6wSRihwZ9wTpVrOFriC5GCYCQX57bUQa4PKhKGZ1Wm-2Bn202Zm3Yw-2FbjG5UZa8Smjg5iG3tH2PslD80jzAPFJbu08QBtgpIoWQJAVzUPqeP0MZrVJt0aDM-3D"
  style="font-family:Arial,Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0U5iLiAdGx7sIcYlBEMjDcvo3B9PufsUvdHMoqACJK7gFMYQH6jtSG5XIxww3tJmP8L1hPBL4b7WQudj2fMfQ7mtg34alJtNodTHqa-2FuTOMOwX-2FGA-2F9-2F3QuIBI7craRu076vg7Cc0fXi-2BNVmktWlo59hMC5E-2FCc0rRvR8uMe8K-2BzHR4_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttcHD-2FWF-2BoYUqox6W7SAkBtlkA9E-2BkeE5iW6wSRihwZ9wTpVrOFriC5GCYCQX57bUQa4PKhKGZ1Wm-2Bn202Zm3Yw-2FbjG5UZa8Smjg5iG3tH2PslD80jzAPFJbu08QBtgpIoWQJAVzUPqeP0MZrVJt0aDM-3D&amp;source=gmail&amp;ust=1692892263921000&amp;usg=AOvVaw3mAUMRz_H1voCFoO-gHMf-">
  <img style="display:block;font-family:Arial,Helvetica,sans-serif;color:#ffffff"
  src="https://ci6.googleusercontent.com/proxy/BNaMRgKWA5N0HOJATrYJMWGFm-gyhrA-qvKWq1oTyCwpsJTCbBedKdyZGK9DuWGO2fgOu0oG_pX9lYKiS7Enw62rKFjbDqJzLrQ1kY3EjLDUKtslXvY5lH9ShUsGYsRs=s0-d-e1-ft#https://images.stockx.com/images/Nike-Dunk-Low-White-Black-2021-W-Product.jpg"
  alt="Nike Dunk Low Retro White Black Panda (2021) (Women's)"
  width="168"
  height="auto"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:ProximaNova,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-align:center;line-height:16px;padding:5px 0px 0px;max-width:168px;color:#000000"
  align="center">
  Nike
  Dunk
  Low
  Retro
  White
  Black
  Panda
  (2021)
  (Women's)
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left"
  bgcolor="#006340"
  width="100%">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="640"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="padding:45px 30px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="left">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;text-decoration:none;text-align:left;line-height:24px;font-weight:normal;padding-left:105px;padding-bottom:45px;color:#d4d1c7"
  align="center">
  <ul style="margin:0px;padding:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:18px;line-height:24px;font-weight:600;display:inline-block;list-style-type:none;color:#d4d1c7"
  type="none">
  <li
  style="display:inline-block;padding:0px 5px 0px 0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;margin:0px!important">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3DZKQn_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZnLt8zE1dsHLJcPNMRFFIx3Yq7YvQH-2BjhX5-2FjOVGFRVYO8spTaBMKbMmsTUZrjWp0q2OuM7VTYqcp8704eujHfzEVpcifHBvVcV8klJxzZcXUd-2BAGCteQ2DmmvPz3MA-2Bu2EQuLCF9O8Yay6J9dus4s-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  align="left"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3DZKQn_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttZnLt8zE1dsHLJcPNMRFFIx3Yq7YvQH-2BjhX5-2FjOVGFRVYO8spTaBMKbMmsTUZrjWp0q2OuM7VTYqcp8704eujHfzEVpcifHBvVcV8klJxzZcXUd-2BAGCteQ2DmmvPz3MA-2Bu2EQuLCF9O8Yay6J9dus4s-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw0iBx__zElxu-xMIuwoEz6_">Email
  Settings</a>
  </li>
  <li
  style="display:inline-block;border-left-width:1px;border-left-style:solid;padding:0px 10px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;border-left-color:#d4d1c7">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7ukcblo93b-2BPW5F-2Fcb7sEBQh6WoKt2-2BiEBviXe-2BhUhKgUJm0YGXi8-2FQray-2BgHprlG0sEiOwvTG2g6sIE0j0AJR-2BRbGi3mRx19ZNnZY-2BBoBaGYA-3D-3D83Sa_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttauqndCTK9olYRNWdqJCjWV-2BTYeyC915eDdL6jz6w-2B-2BVmIuX2nC27qiDdiwvqNhf9z7f-2BjDxl6ZcUcr-2FzZ6QQXWBtfeotaVWGicaYyosSzbctTryG6prE3si7H-2BuvdZShprsyFQNAe4XLo7FSsDDpWw-3D"
  style="text-decoration:none;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  rel="noopener noreferrer"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2FbxauprzYozKAjaUUB-2FB-2B7ukcblo93b-2BPW5F-2Fcb7sEBQh6WoKt2-2BiEBviXe-2BhUhKgUJm0YGXi8-2FQray-2BgHprlG0sEiOwvTG2g6sIE0j0AJR-2BRbGi3mRx19ZNnZY-2BBoBaGYA-3D-3D83Sa_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttauqndCTK9olYRNWdqJCjWV-2BTYeyC915eDdL6jz6w-2B-2BVmIuX2nC27qiDdiwvqNhf9z7f-2BjDxl6ZcUcr-2FzZ6QQXWBtfeotaVWGicaYyosSzbctTryG6prE3si7H-2BuvdZShprsyFQNAe4XLo7FSsDDpWw-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3L5y05AZaX_EdesbarfTnQ">Help</a>
  </li>
  <li
  style="display:inline-block;border-left-width:1px;border-left-style:solid;padding-left:10px;margin:0px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;border-left-color:#d4d1c7">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0wlvZCGseNuC-2BvJXrp9jQuf-2FDvneA5YDfjajzeVys7hGYNtKkTaPWX-2ByFtYuswYyW4xOPINIhhAYfJyvilgGHXVGSj1Sv4eRy-2BEC5PK31OLJhGb3s60HvFMoBVhpNKdRg-3D-3DyfF1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSuFgbor5U8o7kaQbFzZHb34ha9sunSlvZa-2FVN0JGKjgejFpgeCQJ2Py6qr2SjnxGhbD6Y-2FYqOsV-2BhQmx6MmPnULmMqAMMGENpKufkjpPbSImSRRl-2BE-2BhlCXibyfe0ulVJZJefrLvaopsWSZWepVrfE-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#d4d1c7"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0wlvZCGseNuC-2BvJXrp9jQuf-2FDvneA5YDfjajzeVys7hGYNtKkTaPWX-2ByFtYuswYyW4xOPINIhhAYfJyvilgGHXVGSj1Sv4eRy-2BEC5PK31OLJhGb3s60HvFMoBVhpNKdRg-3D-3DyfF1_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSuFgbor5U8o7kaQbFzZHb34ha9sunSlvZa-2FVN0JGKjgejFpgeCQJ2Py6qr2SjnxGhbD6Y-2FYqOsV-2BhQmx6MmPnULmMqAMMGENpKufkjpPbSImSRRl-2BE-2BhlCXibyfe0ulVJZJefrLvaopsWSZWepVrfE-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw0_L3qFCglKtFDTO8KHGOYK">Jobs</a>
  </li>
  </ul>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;padding:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center"
  bgcolor="#eae8e3">
  <table
  style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D61P9_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSGbQfHrcf3YKVtxPeBsFfoyOXg1VwyATKav2eDm27hPwaDB0-2FJDptbpGxNuXROidahXV5XYH-2B-2FaWNzlNI14NXMZyWkjFuCzoWciLKA2hw-2BR8w4qBZC6wcU9YYvvsFMLEA0uPpetoslhxlS75w0whtk-3D"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb0H5t5ixb4CxbpmYtLyztqEgX623hbRfg8QmYEsPraDxzvq4vNls6sHP3dqs9C0KHz39elLtmIb8kq6pmih-2BwOvnTgvzDRumKvadcEOVlTYB60uiBlbkqO2BEFi9kVi2DQ-3D-3D61P9_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSGbQfHrcf3YKVtxPeBsFfoyOXg1VwyATKav2eDm27hPwaDB0-2FJDptbpGxNuXROidahXV5XYH-2B-2FaWNzlNI14NXMZyWkjFuCzoWciLKA2hw-2BR8w4qBZC6wcU9YYvvsFMLEA0uPpetoslhxlS75w0whtk-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3AHSHYHr3ghv_QKQ1PeFjD">
  <img style="display:block;border:medium;font-family:ProximaNova,Helvetica,Arial,sans-serif;text-transform:none;font-size:15px;letter-spacing:1px;line-height:25px;max-width:55px;font-weight:400;color:#006340"
  src="https://ci5.googleusercontent.com/proxy/KWlZiyaBvMEXWAdAhl6QKBE0O3_twEEBYJl3sDSjTmlvNc9McWuCH_kWHsGMNbIL2bq-i8HWYRqHSosHVNtygicT64I8RtIhwOiPEAzXUdWmU4YLU8Glwlr_O_u95tQYP5jgbm73fpm6ESr9xLczbczvVZXf_g8TYHKzEM93J3urC3GG6xsTey0bsMR2IXRM5MrkM65Ljo65i5cqoAYcGBOm8tvcyRvPAdNA7Vh9_Jjbfl_7jH3zix2Ur5uj-E5gqmf_bIISb7CDWJjrg0AjK-YwpEoHU1fDr-A=s0-d-e1-ft#https://stockx-assets.imgix.net/emails/logos/X_Green_Digital_RGB.png?dpr=2&amp;w=55&amp;border=1%2Ceae8e3&amp;h=55&amp;fit=fill&amp;bg=eae8e3&amp;pad=10&amp;border-radius=50%2C50%2C50%2C50&amp;border-radius-inner=40%2C40%2C40%2C40"
  alt="StockX"
  width="55"
  height="auto"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="border-collapse:collapse;border:0px;display:block;padding-bottom:15px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  align="center">
  <table
  style="border:medium;border-collapse:collapse;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  cellspacing="0"
  cellpadding="0"
  align="center">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="bottom"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPaeEd_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttaiaWUIt-2FyuPQfJXJWnmiTyzimN6DI4FDP4-2FQ1ByUPPBYEfysoCOaB87eo9omh1-2BpFDQKiMhn4KzwZfa4c1xEHtk6gXkYGUGzZTjA2LWY8eDHodUIeu97-2F5T1DWLf4LF5gCL-2Bwb7zA1KYbALKb3iUyk-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fbw6L5BVJoM4VcEsO6MiZzoBDZUuaxM4Wmd-2BqZWvukDTPaeEd_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttaiaWUIt-2FyuPQfJXJWnmiTyzimN6DI4FDP4-2FQ1ByUPPBYEfysoCOaB87eo9omh1-2BpFDQKiMhn4KzwZfa4c1xEHtk6gXkYGUGzZTjA2LWY8eDHodUIeu97-2F5T1DWLf4LF5gCL-2Bwb7zA1KYbALKb3iUyk-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw1oxydfVJAMHMaZDLmZAugi">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/rB-ND2FkLdBiFxtVxbJCi0UPcylv2IbvKksA6UDrc0P_fS5HN0eEi3ykbqzcjKoQpUGzAhT0SKAiQiJiUZILE-Ty8lTWv94UdwVl6hZBHafnMsdtTHo=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/facebook.png"
  alt="facebook"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6oYNu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSqIWsyHv6Y32sJ9ykyRtBED437tI40-2BqH73x9VXHS8VwHXlWkmnIQOGEf0tNQuXIS79PQfYgRghJRaUsbHa2BhJm1vMsdfzjCCxzdt0Qq0Key-2BBst-2FIGquE2MqIO47CNLNyBGOrAB7-2FPQAZl-2BJisPU-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2KHJQw8LMb-2FR49z8oyC4mlv9ihWF3WyMAqjga4jN6q6oYNu_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSqIWsyHv6Y32sJ9ykyRtBED437tI40-2BqH73x9VXHS8VwHXlWkmnIQOGEf0tNQuXIS79PQfYgRghJRaUsbHa2BhJm1vMsdfzjCCxzdt0Qq0Key-2BBst-2FIGquE2MqIO47CNLNyBGOrAB7-2FPQAZl-2BJisPU-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw3DBWcQfUmkzc5d5yKpCBb-">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/NO_jZhAgxzrMrMt5CfIO20kqHmmSdHagMnw-nOEzQp_nSC9_C5BnEfz7tQbZoEVXvypkC4u0q8GtLNsNlVzA-7U6s-LttoBQk38Dj5TIdhkLCIAVnQ=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/twitter.png"
  alt="twitter"
  width="30"
  height="25"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxNLSp4YxOr1AunmDar2oMy2lW5v_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttRFEwaf8j6e2tOM706DlTzBuh3JDFhGPnWQc6Kv-2BAOYcKUb-2BCzpGCRdb6xhTI8kQq6atisTz-2B5DJ4sTEQgaDijk4VZO4bmGV1PkstkotNjM2o01sukAc2HKT-2BsAdvITneAfBsVPjkWi62igBGbPZGuI-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb44CYwS-2BQg9cnBMyv0hiWxNLSp4YxOr1AunmDar2oMy2lW5v_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttRFEwaf8j6e2tOM706DlTzBuh3JDFhGPnWQc6Kv-2BAOYcKUb-2BCzpGCRdb6xhTI8kQq6atisTz-2B5DJ4sTEQgaDijk4VZO4bmGV1PkstkotNjM2o01sukAc2HKT-2BsAdvITneAfBsVPjkWi62igBGbPZGuI-3D&amp;source=gmail&amp;ust=1692892263922000&amp;usg=AOvVaw2s9_iM7JcBurnw1offyGY8">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci3.googleusercontent.com/proxy/L_BgVah88eOU_oX1iFn1yNLtSOqkOf8Uw7DUGCpMxPHSzNAdTBsxNS52QmB6bZVWdBKaAtPQQPTMrtUZAVssUfpYnW3CPmCHx6Du280u2_6rzCA15k7D=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/instagram.png"
  alt="instagram"
  width="30"
  height="30"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHwgO5_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSQHTlLwvn1mM4GQSmKAsQAOXD-2BD4Rsjjsqv8B5PVSSJgEY-2Brku6aFEzXp0gJdzrrBhlgKzfUudVuhfv3BB21wRq0b4LBewk1-2BMdQwANquAc3Tq6WW4PX1KptXli9YiswRa-2FohJIdCbWdVMfiEEfzr8-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2Fe8EKuUZ5hkGgGlqvYXaRiSDsyYsprpykaEsBO9RJxHwgO5_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSQHTlLwvn1mM4GQSmKAsQAOXD-2BD4Rsjjsqv8B5PVSSJgEY-2Brku6aFEzXp0gJdzrrBhlgKzfUudVuhfv3BB21wRq0b4LBewk1-2BMdQwANquAc3Tq6WW4PX1KptXli9YiswRa-2FohJIdCbWdVMfiEEfzr8-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw3P7mHb3ox7A5oAR8qvn4YR">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/Q7fEt2mF-3UbTLML5Gi6zIgWY_QwbBysLfJRtex0mAq9-bwi8xhrJv5CmR5xbFDZI6F-wwAic4lbS1Bk_9XQTPx8jePR0_nYbL4PiepA6nmVQdpiJQ=s0-d-e1-ft#https://email-assets.stockx.com/evergreenimages/social/youtube.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  <td
  style="font-size:1px;line-height:1px;width:45px;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  &nbsp;
  </td>
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  valign="middle"
  width="30">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClUszmG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttT6-2FibNPsCwrVJ-2BgJQ-2F0Wh9zFVQR5rv2sz7mSD8d1IXuc4ajR6pIlCgPxCTQXTxzU3azV3lP0gy-2FyYO-2B0AmNOKw6G5VsZ5CPgOiukji-2FDzBpxyw8XWogOc3MM-2Byb0-2Bd-2FiXLNYkQwZ9O2wR9oFji2kvw-3D"
  style="text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb-2BGtGJcAS04ydLnD40CM3iOtwTCypu0PVq-2FAwJeOuClUszmG_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttT6-2FibNPsCwrVJ-2BgJQ-2F0Wh9zFVQR5rv2sz7mSD8d1IXuc4ajR6pIlCgPxCTQXTxzU3azV3lP0gy-2FyYO-2B0AmNOKw6G5VsZ5CPgOiukji-2FDzBpxyw8XWogOc3MM-2Byb0-2Bd-2FiXLNYkQwZ9O2wR9oFji2kvw-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw0Tz1iYII-lx1pB4_xoSQv3">
  <img style="display:inline-block;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  src="https://ci6.googleusercontent.com/proxy/ts38XLNq8N_uScKwbU3w9wTMmszKo5ekGYSzoXmllhdZmKCDZsjF1AOkkC_7Ke2DFlsweHJQbebM_mrQ6jW1tIxhK3gLYLY__Kx2DdCDKA=s0-d-e1-ft#https://stockx-assets.s3.amazonaws.com/Discord-Logo-grey.png"
  alt="YouTube"
  width="30"
  height="21"
  border="0"
  class="CToWUd"
  data-bit="iit">
  </a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td
  style="padding:0px 30px 30px;text-align:center;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <table
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  border="0"
  width="100%"
  cellspacing="0"
  cellpadding="0">
  <tbody
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:10px;color:#006340"
  width="100%">
  ©2023
  StockX.
  All
  Rights
  Reserved.
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:5px;color:#006340"
  width="100%">
  The
  sender
  of
  this
  email
  is
  StockX
  located
  at
  <a href="https://www.google.com/maps/search/1046+Woodward+Avenue,+Detroit,+MI+48226,+USA?entry=gmail&amp;source=g"
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/1046%2BWoodward%2BAvenue,%2BDetroit,%2BMI%2B48226,%2BUSA?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw12jBRL-Vqm6gAEhOerPird">1046
  Woodward
  Avenue,
  Detroit,
  MI
  48226,
  USA</a>
  </td>
  </tr>
  <tr
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif">
  <td style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;font-size:10px;font-weight:400;text-decoration:none;text-align:center;line-height:12px;padding-top:5px;color:#006340"
  width="100%">
  <a href="https://link.tmail.stockx.com/ls/click?upn=JIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3D0IL8_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSVn1Mk8K8JC5r-2FNKgbZKlFv8EpNw4nZq68DuEMe-2Bbwj3Ft-2FZBYK6CynwtYXOGqupd4NQpaQf3dj8y15XsNtT33csKqxdDk42NfLQ9Z53jwSzObU5oG5MXBss4dnR09dAYz5EFn6LcnzQ5ArqgE0Cu4-3D"
  style="text-decoration:none;font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;color:#006340"
  rel="noopener"
  target="_blank"
  data-saferedirecturl="https://www.google.com/url?q=https://link.tmail.stockx.com/ls/click?upn%3DJIQY7zBfXDLTJFCjYRV-2Fb2GLcuvqoQN0Di2SNEQY32ha9EfE-2BKV03jVZEIgSQw-2FegbfMwVLBQCRlcrT9UxTBzSJmNqRSMipmlOeqI7MzAMPJ9LdDgdRUfupF8N64fWBwskxXRrxWBRSq-2BXkovLlV3A-3D-3D0IL8_rSvXJZ42P741h-2FyNJ0cJu9zQdixqCZz0wTeuBCy4LKZJ3ZVlCHHTRJani3EGFZeK1iuZ61fUcW-2FEDRCpQTJFdTMxXPLeKDJgfVHsDGqbLXtQBnEVlZlmFM-2FsJmK6aT8xj7GRZBS4P1fwB-2Bb0yTl1pp5t6PErrV91vC6MiyvUa3wacjNBeZo-2B4Q2fapGGmhC9uTZCQUIuX43tbIrDQomBMhsRrtBiaS-2FpStNBlr7RrxxrbxW3yMf7DAJmAr94w14U7JJNqV20FwO5VXl7cojy-2F1ZBK-2FVK1vSWDbKgSyVsUBNnq3-2BXgYWQS9948ZptSid68HW7qwzuSCBtv17sobrydeEYlZgUZTMP8ISgnT6Ypz2eGh92m26TSgxzV5tZ-2BxnqF3762UWegFbFkDoCbmRnO0QFeCDCWkkmtqwMRpeSvqR4w8c1s8KxXVw5s-2Bocz3dDB6YVyaA7jslpcDrgfvNttSVn1Mk8K8JC5r-2FNKgbZKlFv8EpNw4nZq68DuEMe-2Bbwj3Ft-2FZBYK6CynwtYXOGqupd4NQpaQf3dj8y15XsNtT33csKqxdDk42NfLQ9Z53jwSzObU5oG5MXBss4dnR09dAYz5EFn6LcnzQ5ArqgE0Cu4-3D&amp;source=gmail&amp;ust=1692892263923000&amp;usg=AOvVaw26xWiZ0noa1B6OiNT3Vlie">Update
  email
  settings</a>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table>
  </td>
  </tr>
  </tbody>
  </table> <img
  style="font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;height:1px!important;width:1px!important;border-width:0px!important;margin:0px!important;padding:0px!important"
  src="https://ci5.googleusercontent.com/proxy/71RtYSzFOedwPCy-YViRa2hteV1bgE9_5WvLDoCOdV44-A0pJUCY3TkswlIIvSC0TWSyJPWidVzibeD1uqlfIXr-JCY9wkTp_bW2kp2oPR9SB6qtCDdbpnf2ayaFkT4QwEy2VDE5XQVmbRj1OVXwtFaotGWozmS9JNKIX7qHNkUNzydjwbTkvfkOQpgovUOG_9CrYXS2-eK97Ndb8GggCYTDwmadjELVBi8R5guNsyoBnqQl3Z31lRAx_ffxOYZ8bMAQB37yzBD9g8kieJJg0PTrdtmevFBjtaC8U69tsPL-xwRlj2avXuZe0N7ZUsUbLhEb2fXMvDq6OBd-oQ5tefbzIPvYOS1A-KOikHqtoGg260uWAmjQCtwzaNQWgB3GBNYGEt1Tef-cPjT1XYEUhh3LzZreuLzSENehJ_poxKa5vcVPf5hy2JU2GDotmnSI1222VJf1GXbkGNZsRjoqvQII5oRE21zZxuMUqiFwgStK5TL8BzEyn4EoLfyGHyxbh4-lKsijyc6dLldOQQeZO7RGOETlG3I9lcl3rB2MxxcEM-rfUiVvN8st8sna0v1w3vC67YFkNLhaV7aU6W2bGpuyArgJkZtTDYZFMYKbVSf8HTQh8svIdMDZ5Anq7sNX4bqxYAsfLb55KXvHTK_v4gtHzesbDr-vWayjrO3-MH9R5UOwQJ1C38beKYGTa50JPzxba4F3ls7gPm2xpmAMM_1kq-d_zFBeou_ffRp7QoftkjBDKUD3VgRMzdiLsfqcLfvhctQ09g5DiM_PE6CqgCXJGlhKAnEHdq8OuKTpVa4K_Q8H_eZjjHGYQ_730UqV9AvMNnvwC_0yN7knhP6hSC0nYVuiZJfW9Wh5u29OOw2MkknZJ2m8MZBTfc2fUW1pWlace3ddnK90bNRQdmk4-g27ySznRLNuXbKMiNZRsIO7aiOJkGoJm2Pg_7JYV_rNvIAdBO9ULFQ1cL-87scxcDJWh-E=s0-d-e1-ft#https://link.tmail.stockx.com/wf/open?upn=gRxMUVBU4yMmfJUAsrxyQtk-2FW5f0l2hSTc-2BWDSLvBPJ9bKMQCDXl4lXCQG6ef665u56jvmthmIaT0wyoEvCVLcbM0v2T7KTm-2Bi71g3NLUmK6jEUBG4FMb-2FiU8k-2FiOAGa4YpYNS37CJxj1StHy94OiJRus2F9Cn1Cl-2FrKADlV4T6p-2BO5WUXXqiyAqOFFU5gjmGwiSTUcHjZ2QAGyUgZH992-2FczzKf3BQDfgzXTMFkNx-2BOtRJiMoKXSuzEUGCJx0sl7ZIifraM2ETRNh0mkk5uK-2F5WBPH5PzmRnldA2wsGm1lAS600umHH4sWQDZ2xilu1jbp5osnLRkRqbtq2a-2BB01CxEIGz1PnqDZggtGt4s6rqsLos3qVMixOpfRTp2Mo2EtBbiASSkW7T9aSdwLVMSlnrb5jN4-2FKn0TCaw0x3nM5Op7pBne16pjOz-2BSiUd0w-2BO9zWOeLV8HjQyq6wsJgvRBMW-2BYKkiDErl87dP562nU-2FoirMbnEPSLIfLZlrfI9Bz2-2BXx0QYHmZCnlx5MPnt2M4gyjk6-2FxuYVVKYAxhMarYh9PtiVYzJbMaNZeKhioeUE4eaZMWyuBEU4jum79uUsPAXK-2BKH58nJSxJ97eFBGCitxakpQDCe5TV1QzNvv6mF2w"
  alt="" width="1" height="1" border="0" class="CToWUd" data-bit="iit">
  <div class="yj6qo"></div>
  <div class="adL"> </div>
  </div>
  <div class="adL"> </div>
  </div>
  <div class="adL"> </div>
  </div>
  </div>
  <div class="adL">
  </div>
  </div>
  </div>
  <div id=":pk" class="ii gt" style="display:none">
  <div id=":pl" class="a3s aiL "></div>
  </div>
  <div class="hi"></div>
  </div>
  </body>
  
  </html>`;
};
