export const stadiumEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":14r" tabindex="-1"></div>
<div id=":18n" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzMzYwOTA5NTU0MDQ2NCIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzMzYwOTA5NTU0MDQ2NCIsbnVsbCxbXV0.">
<div id=":18o" class="a3s aiL ">
<div class="adM">
<br>
</div>
<div class="adM">
</div>
<div>
<div class="adM">
</div>
<div class="gmail_quote">
<div class="adM">
</div>
<blockquote class="gmail_quote"
style="margin:0 0 0 .8ex;border-left:1px #ccc solid;padding-left:1ex">
<div class="adM">
</div>
<div>
<div class="adM">
</div><u></u>
<div
style="min-width:100%;margin:0;padding:0;box-sizing:border-box;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;background-color:#efefef;width:100%">
<table
style="border-spacing:0;padding:0;vertical-align:top;background:#efefef;height:100%;width:100%;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;border-collapse:collapse"
border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left" align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;font-size:16px;font-weight:normal;margin:0 auto;float:none;text-align:center"
align="center" valign="top">
<center style="width:100%;min-width:344px">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:676px"
width="676" align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left" valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left" valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;padding-right:0;padding-left:0;width:684px"
align="left" valign="top"
width="684">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%" align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:48px;line-height:48px"
align="left"
valign="top"
height="48px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;background-color:#ffffff;margin:0 auto;text-align:inherit;width:100%"
width="100%"
align="inherit"
bgcolor="#ffffff">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:612px"
width="612"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<a href="https://mail.stadiumgoods.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGuJJzdINKF4kK1aGH47JzeDtFzfP5FyMJUsFXM8ekzb7zgc3jGKOVXtpKX%3DSAAY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbnStk7on2_cQwtYoPmDuJx_r-RmS8rJFKN5Xo0fdOQDLXm459XIcPZEAzVhXpX0iH-GdWWT5xKj.&amp;_di_=0o5r7eppto5kgh65t3oaarsjar0mi4cvgm7qj28oe608vum9qimg"
style="text-decoration:underline;color:#a41d23;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://mail.stadiumgoods.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGuJJzdINKF4kK1aGH47JzeDtFzfP5FyMJUsFXM8ekzb7zgc3jGKOVXtpKX%253DSAAY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbnStk7on2_cQwtYoPmDuJx_r-RmS8rJFKN5Xo0fdOQDLXm459XIcPZEAzVhXpX0iH-GdWWT5xKj.%26_di_%3D0o5r7eppto5kgh65t3oaarsjar0mi4cvgm7qj28oe608vum9qimg&amp;source=gmail&amp;ust=1692890366447000&amp;usg=AOvVaw0GuVXPMwu_-wHoY_BeMgLd">
<img style="outline:none;text-decoration:none;max-width:100%;clear:both;display:block;border:0;width:156.8px"
src="https://ci5.googleusercontent.com/proxy/H5SG-idJouMEv6dBjxgsPlYaFcOlQVFyJYFY7kRS4qntw_uQ4B6aZ6UvcsNeEwtlIiWQx4fDD-XiZzTj_oP0tuE4PF8wBHu-t7ki_UfIxqYHWf1-LR05d3qDInHEBvQD2k6nxzXObuZbyIOxf2jBx5jrjIXxnMW4FUD5FCbMWg8PfwU=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetchu006/contentlibrary/resources/stadium_goods_logo.jpg"
alt="Stadium goods logo"
width="156.8"
class="CToWUd"
data-bit="iit">
</a>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:24px;line-height:24px"
align="left"
valign="top"
height="24px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:612px"
width="612"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<h1
style="text-align:left;margin:0;font-family:Helvetica,Arial,sans-serif;font-size:24px;line-height:1.35;color:#131313;font-weight:600;font-style:normal">
We
received
your
order!
</h1>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:16px;line-height:16px"
align="left"
valign="top"
height="16px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:16px;line-height:1.35">
Orders
require
1-3
days
processing
time
prior
to
shipment.
You
will
be
notified
via
email
with
a
tracking
number
once
your
order
has
shipped.
<br>
<br>If
this
is
a
multi-item
order,
please
note
that
items
may
be
split
into
different
shipments.
<br>
<br>Questions?
Check
out
our
FAQ
or
email
us
at
<a href="mailto:support@stadiumgoods.com"
style="text-decoration:underline;color:#a41d23;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
rel="noopener"
target="_blank">support@stadiumgoods.com</a>.
</p>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;border-top:1px solid #c6c8ca;margin:0 auto;text-align:inherit;width:100%"
width="100%"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<span
style="font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-size:24px;line-height:1.35;font-weight:600;color:#131313">Your
order</span>
<span
style="font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-size:24px;line-height:1.35;font-weight:600;color:#a41d23">${form?.order_number}</span>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;margin:0 auto;text-align:inherit;width:100%"
width="100%"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:612px"
width="612"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:16.66667%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="16.66667%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;margin:0 auto;text-align:inherit;width:100%"
width="100%"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<img style="outline:none;text-decoration:none;max-width:100%;clear:both;display:block;border:0;width:74px;height:auto"
src=${form?.image_link}
alt="Crew Socks  "
width="74"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:66.66667%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="66.66667%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;color:#131313;word-break:break-all">
${form?.item}
</p>
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:12px;line-height:1.35">
${form?.style_id}
</p>
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:12px;line-height:1.35">
Quantity
1
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:16.66667%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="16.66667%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:5px;line-height:5px"
align="left"
valign="top"
height="5px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<p
style="font-family:Helvetica,Arial,sans-serif;margin:0;font-weight:normal;font-size:12px;line-height:1.35;text-align:right;color:#131313;word-break:break-all">
${form?.subtotal}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;background-color:#f8f8f8;padding:0;display:table;width:100%"
width="100%"
align="left"
bgcolor="#f8f8f8">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:612px"
width="612"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:16px;line-height:16px"
align="left"
valign="top"
height="16px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal">
Shipping
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;font-size:16px;margin:0;font-weight:normal;text-align:right;word-break:break-all">
${form?.shipping}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal">
Promo
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;font-size:16px;margin:0;font-weight:normal;text-align:right;word-break:break-all;color:#a41d23">
${form?.discount}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal">
Taxes
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;font-size:16px;margin:0;font-weight:normal;text-align:right;word-break:break-all">
${form?.taxes}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:600;color:#131313">
Total
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;font-size:16px;margin:0;font-weight:600;color:#131313;text-align:right;word-break:break-all">
${form?.total}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:16px;line-height:16px"
align="left"
valign="top"
height="16px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;float:none;margin:0 auto;text-align:inherit;width:612px"
width="612"
align="inherit">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;letter-spacing:0.05em;font-weight:600;color:#131313;text-transform:uppercase">
Shipping
address
</p>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:22px;line-height:22px"
align="left"
valign="top"
height="22px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal">
${form?.full_name}
<br>${form?.street}
<br>${form?.city}
<br>${form?.zip}
<br>${form?.country}
</p>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:50%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0px;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0px;font-weight:normal;width:100%"
align="left"
valign="top">
<p
style="font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;letter-spacing:0.05em;font-weight:600;color:#131313;text-transform:uppercase">
Payment
method
</p>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0px;font-weight:normal;width:0%;padding:0px"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:22px;line-height:22px"
align="left"
valign="top"
height="22px">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;display:table;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;font-weight:normal;margin:0 auto;width:100%;padding-left:0;padding-right:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<th style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal"
align="left"
valign="top">
<p
style="color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal">
PayPal
</p>
</th>
<th style="vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;line-height:22px;text-align:left;font-size:16px;margin:0;font-weight:normal;width:0;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;padding:0;vertical-align:top;text-align:left;width:100%"
width="100%"
align="left">
<tbody>
<tr style="padding:0;vertical-align:top;text-align:left"
align="left"
valign="top">
<td style="padding:0;vertical-align:top;color:#656565;font-family:Helvetica,Arial,sans-serif;text-align:left;margin:0;font-weight:normal;font-size:32px;line-height:32px"
align="left"
valign="top"
height="32px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</blockquote>
</div>
</div>
<div class="iX">...<br><br>[Message clipped]&nbsp;&nbsp;<a
href="https://mail.google.com/mail/u/2?ui=2&amp;ik=a306d55d85&amp;view=lg&amp;permmsgid=msg-f%3A1775033609095540464&amp;ser=1"
target="_blank">View entire message</a></div>
</div>
<div class="yj6qo"></div>
<div class="yj6qo"></div>
</div>
<div id=":19j" class="ii gt" style="display:none">
<div id=":19b" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
