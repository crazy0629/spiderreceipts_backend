export const hermesEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":pq" tabindex="-1"></div>
<div id=":mm" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyNjcxOTk3MjA3MjUwOSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyNjcxOTk3MjA3MjUwOSIsbnVsbCxbXV0.">
<div id=":mn" class="a3s aiL ">
<div class="adM">
<div></div>
</div>
<div class="adM">

</div>
<div>
<div class="adM">
</div>
<div id="m_-6991829648606724244divRplyFwdMsg" dir="ltr" class="adM">
<div>&nbsp;</div>
</div>
<div class="adM">
</div>
<div style="background-color:#f9f9f9;margin:0;min-width:100.0%;text-align:center;padding:0">
<div class="adM">
</div>
<table style="border-spacing:0;font-family:sans-serif;color:#000000;background-color:#f9f9f9"
border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="max-width:600.0px;padding:0" align="center" bgcolor="#f9f9f9"
width="100%">
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px;width:100.0%">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:640.0px"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
colspan="3" bgcolor="#f9f9f9" height="20">&nbsp;</td>
</tr>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
<td style="width:87.5%;font-size:12.0px;color:#989898;font-family:Arial;padding:0"
align="center" valign="middle" bgcolor="#f9f9f9">We
thank you for your order</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
</tr>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
colspan="3" bgcolor="#f9f9f9" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="40">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="overflow:hidden;font-size:1;line-height:1;padding:0"
align="center" bgcolor="#FFFFFF">
<a href="https://www.hermes.com/nl/en/"
style="font-size:1;line-height:1;width:86px;height:50px;text-decoration:none"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/&amp;source=gmail&amp;ust=1692883797779000&amp;usg=AOvVaw1-LvQLeeO0wq-0xhXtYblm">
<img style="font-family:Arial;color:#ffffff;font-size:1px;text-align:center;display:block;border-width:0;width:86px;max-width:86px;height:50px"
src="https://ci4.googleusercontent.com/proxy/MFUzXxeXKg2RAY5PhNL3707Xm5W3DSWDl8g4pHgd5vFOQ5V5L2L4MKsbCp1jYBa8UiN4x0PQ-BLNOh8Cwr0WtiB6Oi-9Lu8nc3H70e2h3eje4jursxG_K8iqsiSXZcU21wSgFLhev7cxEYif=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/LOGO%20HERMES%20GREY?wid=600&amp;fmt=png-alpha"
alt="HERMES PARIS" width="86" height="50"
class="CToWUd" data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f2ce8b">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="40">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#FFFFFF">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Palatino Linotype;font-size:30px;line-height:40px;color:#444444">Dear
Mr.
${form?.full_name},</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#FFFFFF">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:620.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" bgcolor="#ffffff">
<span
style="font-family:Palatino Linotype;line-height:40px;color:#444444">Your
order has been received and is being
reviewed.
<br>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="15">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#FFFFFF">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:620.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" bgcolor="#ffffff">
<span
style="font-family:Arial;font-size:12.0px;line-height:20.0px;color:#9a9a9a">As
soon as your order is available for
pick up in store, you will be
notified by email.</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="23">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:15.0px;line-height:17.0px;color:#626262">${form?.order_date}</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:13.0px;line-height:16.0px;color:#797979">Order
<a href="https://www.hermes.com/nl/en//#tray-find-order"
rel="nofollow noopener"
style="color:#797979;text-decoration:underline"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en//%23tray-find-order&amp;source=gmail&amp;ust=1692883797779000&amp;usg=AOvVaw2ta6ptUV8ngZfodPjI6ApF">#${form?.order_number}</a>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0px;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:center;width:20%;min-width:20%;max-width:20%;padding:0"
align="center" valign="middle"
bgcolor="#ffffff">
<img style="border:0;max-width:100%"
src=${form?.image_link}
alt="Izmir sandal" width="105"
class="CToWUd" data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="width:4%;min-width:4%;max-width:4%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="text-align:left;width:76%;min-width:76%;max-width:76%;padding:0"
align="center" valign="top"
bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0"
align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;width:70%;min-width:70%;max-width:70%;padding:0"
align="left"
valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:15px;line-height:17px;color:#626262">${form?.item}</span>
</td>
<td style="width:30%;min-width:30%;max-width:30%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;
</td>
</tr>
<tr>
<td style="width:70%;min-width:70%;max-width:70%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff"
height="10">&nbsp;</td>
<td style="width:30%;min-width:30%;max-width:30%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff"
height="10">&nbsp;</td>
</tr>
<tr>
<td style="text-align:left;width:70%;min-width:70%;max-width:70%;padding:0"
align="left"
valign="top"
bgcolor="#ffffff">
<span
style="font-family:Arial;font-size:12px;line-height:17px;color:#9b9b9b">Color:
${form?.color}
<br>Size:
${form?.size}
<br>Ref:
${form?.reference_number}
<br>Qty: 1
<br>
<br>
</span>
</td>
<td style="width:30%;min-width:30%;max-width:30%;padding:0"
align="right"
valign="bottom"
bgcolor="#ffffff">
<span
style="font-family:Courier New;font-size:14px;line-height:17px;color:#727272">${form?.subtotal}</span>
</td>
</tr>
<tr>
<td style="width:70%;min-width:70%;max-width:70%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff"
height="10">&nbsp;</td>
<td style="width:30%;min-width:30%;max-width:30%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff"
height="10">&nbsp;</td>
</tr>
<tr>
<td style="text-align:left;width:70%;min-width:70%;max-width:70%;padding:0"
align="left"
valign="middle"
bgcolor="#ffffff">&nbsp;
</td>
<td style="width:30%;min-width:30%;max-width:30%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:14.0px;color:#848484">This
order is a gift.
<br>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:16.0px;line-height:18.0px;color:#505050">Delivery</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="13">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:14.0px;color:#848484">Collection
in store</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="5">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:18.0px;color:#a3a3a3">Hermès
Amsterdam Hooftstraat
<br>P.C. Hooftstraat, 94
<br>1071 BR Amsterdam
<br>Netherlands
<br>Tel. : + 31 (0) 20 305 70 50
<br>
<a href="https://maps.google.com/?q=52.35995650,4.87959620"
rel="nofollow noopener"
style="color:#a3a3a3;text-decoration:underline"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://maps.google.com/?q%3D52.35995650,4.87959620&amp;source=gmail&amp;ust=1692883797780000&amp;usg=AOvVaw2h2OpbV34TX1XOMhwtzTfm">Get
directions</a>
<br>
<br>Opening hours
<br>maandag 12:00 naar 18:00
<br>dinsdag 10:00 naar 18:00
<br>woensdag 10:00 naar 18:00
<br>donderdag 10:00 naar 18:00
<br>vrijdag 10:00 naar 18:00
<br>zaterdag 10:00 naar 17:30
<br>zondag gesloten
<br>
<br>Collection by
<br>Mr.
${form?.full_name}
<br>Your purchases will be available
in-store within 2 to 5 business days
of when your order is validated by
our Customer Service, by 2 p.m.
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0px;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:16.0px;line-height:18.0px;color:#505050">Payment</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="13">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:14.0px;color:#848484">Billing
address</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="5">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:18.0px;color:#a3a3a3">Mr.
${form?.full_name}
<br>${form?.street}
<br>${form?.zip}
${form?.city}
<br>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0px;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;width:50.0%;min-width:50.0%;max-width:50.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:18.0px;color:#a3a3a3">Subtotal
:</span>
</td>
<td style="text-align:right;width:50.0%;min-width:50.0%;max-width:50.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span style="font-family:Courier new">
<a
style="text-decoration:none;color:#333333">${form?.subtotal}</a>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="14">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="14">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;width:50.0%;min-width:50.0%;max-width:50.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:12.0px;line-height:18.0px;color:#a3a3a3">Collection
in store - Hermès Amsterdam
Hooftstraat</span>
</td>
<td style="text-align:right;width:50.0%;min-width:50.0%;max-width:50.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Courier new">${form?.shipping}</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="14">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;font-size:0;line-height:0;padding:0"
align="left" valign="middle"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="14">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#ffffff">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:left;width:70.0%;min-width:70.0%;max-width:70.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Georgia;font-size:20.0px;line-height:23.0px;color:#4b4b4b">Total
(Incl. VAT):</span>
</td>
<td style="text-align:right;width:30.0%;min-width:30.0%;max-width:30.0%;padding:0"
align="left" valign="middle"
bgcolor="#ffffff">
<span style="font-family:Courier new">
<a
style="text-decoration:none;color:#333333">${form?.total}</a>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="40">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#ffffff;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#FFFFFF">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:620.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="text-align:left;padding:0"
align="left" bgcolor="#ffffff">
<span
style="font-family:Arial;font-size:12.0px;line-height:20.0px;color:#9a9a9a">Orders
placed Monday through Friday by 2pm
Eastern Time will ship the same day,
unless items within your order are
subject to a shipping delay.</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#FFFFFF">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="30">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
valign="top" bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" valign="middle"
bgcolor="#ffffff">
<span
style="font-family:Palatino Linotype;font-size:17px;line-height:22px;color:#444444">We
look forward to seeing you again on
<a href="https://www.hermes.com/nl/en/"
style="color:#444444;text-decoration:underline"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw2RYsx1gI9lUg3Qi2u9Ojyc">hermes.com</a>
or at our other
<a href="https://www.hermes.com/nl/en/find-store"
style="color:#444444;text-decoration:underline"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/find-store&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw2guRuf7Gd45e8UcNtHxVg7">stores.</a>
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#ffffff">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center></center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#ffffff!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#ffffff" height="35">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="height:auto;padding:0" align="center"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;height:22px;max-width:59px;width:8%;padding:0"
align="left" valign="top"
bgcolor="#f9f9f9" width="59">&nbsp;</td>
<td style="text-align:center;padding:0"
align="center" valign="top"
bgcolor="#f9f9f9">
<table
style="float:left;border-spacing:0;font-family:sans-serif;color:#333333;margin:0px;width:50%;max-width:241px;text-align:center;display:inline-block"
cellspacing="0" cellpadding="0"
align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;height:19px;max-width:241px;padding:0"
colspan="2" align="left"
valign="top"
bgcolor="#f9f9f9"
width="241">&nbsp;</td>
</tr>
<tr>
<td>
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0px;width:auto;max-width:281px;text-align:center;display:inline-block"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;font-size:0;line-height:0px;min-width:25px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
width="25"
height="57">
<a href="https://www.hermes.com/nl/en//#tray-find-order"
style="color:#333333;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en//%23tray-find-order&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw12phIylNVpugRjGm2pWnAG">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;border-width:0;width:18px;max-width:18px;height:19px"
src="https://ci6.googleusercontent.com/proxy/QuFLEhgacnFV5U49PtmDISOpwg_svQjl62WE_CzGTua4TELEPIZowYdBUNGR8myt2JOT-lL2VDrrNB9RsQ-PD2ejpvz0lrLVXZHiziLAyCmyLCC-M0Vm-xcT=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/trackOrder?fmt=png-alpha"
alt="Order tracking"
width="18"
height="19"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="57">
<a href="https://www.hermes.com/nl/en//#tray-find-order"
style="color:#333333;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en//%23tray-find-order&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw12phIylNVpugRjGm2pWnAG">
<span
style="font-family:Palatino Linotype;font-size:15px;line-height:19px;color:#444444">Order
tracking</span>
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="float:left;border-spacing:0;font-family:sans-serif;color:#333333;margin:0px;width:50%;max-width:241px;text-align:center;display:inline-block"
cellspacing="0" cellpadding="0"
align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;height:19px;max-width:241px;width:241px;padding:0"
colspan="2" align="left"
valign="top"
bgcolor="#f9f9f9"
width="241">&nbsp;</td>
</tr>
<tr>
<td>
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0px;width:auto;max-width:281px;text-align:center;display:inline-block"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;font-size:0;line-height:0px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
width="25"
height="57">
<a href="https://www.hermes.com/nl/en//faq/online-shopping-nl#returns-and-exchanges"
style="color:#333333;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en//faq/online-shopping-nl%23returns-and-exchanges&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw3G2TQJ4QamUraZ9arW5_1o">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;border-width:0;width:18px;max-width:18px;height:19px"
src="https://ci5.googleusercontent.com/proxy/wCUYI50Ly36I-TShQSpS60Uu6ArOzEFZVhk2dLp-doKXp8lVGsU6WQRRRmo1ZHixJMn1F7HDVb6Uge37a62SrgoQ0LbE-RsxDpQcQwShZQEbewnYgQum6g=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/freeBack?fmt=png-alpha"
alt="Complimentary return to sender"
width="18"
height="19"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="57">
<a href="https://www.hermes.com/nl/en//faq/online-shopping-nl#returns-and-exchanges"
style="color:#333333;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en//faq/online-shopping-nl%23returns-and-exchanges&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw3G2TQJ4QamUraZ9arW5_1o">
<span
style="font-family:Palatino Linotype;font-size:15px;line-height:19px;color:#444444">Complimentary
return
to
sender</span>
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td style="margin:0 auto;height:22px;max-width:59px;width:8%;padding:0"
align="left" valign="top"
bgcolor="#f9f9f9" width="59">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="background:#f9f9f9;border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="height:auto;padding:0" align="center"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" valign="top"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0px;width:264;max-width:264px;text-align:center;display:inline-block"
cellspacing="0" cellpadding="0"
align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="margin:0 auto;height:19px;max-width:264px;padding:0"
colspan="9" align="left"
valign="top"
bgcolor="#f9f9f9"
width="264">&nbsp;</td>
</tr>
<tr>
<td style="margin:0 auto;height:22px;max-width:25px;padding:0"
align="left"
valign="top"
bgcolor="#f9f9f9"
width="25">&nbsp;</td>
<td style="width:20px;max-width:20px;margin:0 auto;font-size:0;line-height:0px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="22">
<a href="https://www.facebook.com/hermes"
style="text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.facebook.com/hermes&amp;source=gmail&amp;ust=1692883797781000&amp;usg=AOvVaw1EysxT2yC7sV9Lxds57ZSB">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;display:block;border-width:0;width:10px;max-width:10px;height:22px"
src="https://ci3.googleusercontent.com/proxy/FtjYG1db8VnC8A8YTknTzKsS2UbPUv_UOskIOjD7XYkV2Mw8DGttMziTL8EH76V0q09Bw_JhujMwPxWTCSQ81v9DbtZMzuDlYMcZUIzVGmoKa0zcGxJXuA=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/facebook?fmt=png-alpha"
alt="Facebook"
width="10"
height="22"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;height:22px;max-width:51px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
width="51">&nbsp;</td>
<td style="width:20px;max-width:20px;margin:0 auto;font-size:0;line-height:0px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="22">
<a href="https://www.instagram.com/hermes/"
style="text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.instagram.com/hermes/&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw2IVh4xDsHBwQlUGE1vdhpi">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;display:block;border-width:0;width:20px;max-width:20px;height:20px"
src="https://ci3.googleusercontent.com/proxy/iQkU-F2IRER5433DIvUCxj1fDz8hD1OUFhGmSXImBAuumiXI3bzt4g-7CinexJM_YLem5geyh-BtyEDjL6jnljPvPwgHCZOW_lzwQYfnI4MBHZOhOKGUvsI=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/instagram?fmt=png-alpha"
alt="instagram"
width="20"
height="20"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;height:22px;max-width:51px;padding:0"
align="left"
valign="top"
bgcolor="#f9f9f9"
width="51">&nbsp;</td>
<td style="width:20px;max-width:20px;margin:0 auto;font-size:0;line-height:0px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="22">
<a href="https://twitter.com/hermes_paris"
style="text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://twitter.com/hermes_paris&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw18KCeSGFrZqyEG4eRi_mJq">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;display:block;border-width:0;width:20px;max-width:20px;height:17px"
src="https://ci5.googleusercontent.com/proxy/SQP8NkHVtSIsx6IY4sNAX4QvcwNX8-iAgNz9eAw0C0Bnd4VFS0HqsQ9VuQXA-ubr45SiVo0aserylDvKQOytM62LWZYBqlZ7nCWugHfSuzXwpcf8UcXT=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/twitter?fmt=png-alpha"
alt="Twitter"
width="20"
height="17"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;height:22px;max-width:51px;padding:0"
align="left"
valign="top"
bgcolor="#f9f9f9"
width="51">&nbsp;</td>
<td style="width:20px;max-width:20px;margin:0 auto;font-size:0;line-height:0px;padding:0"
align="left"
valign="middle"
bgcolor="#f9f9f9"
height="22">
<a href="https://www.youtube.com/user/hermes"
style="text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.youtube.com/user/hermes&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw3LyODK9PdRxW9M_q91EQ8p">
<img style="font-family:Arial;color:#ffffff;font-size:0px;text-align:center;display:block;border-width:0;width:18px;max-width:18px;height:22px"
src="https://ci5.googleusercontent.com/proxy/zvyw3HnT3tN1EF1P5NFxiBXPFNTy8rkn4TI449T7wOLZTQxfGLfQOZ4StUwir8rbnT0VwKSyHSxp95DesyMUWkUMO-Pko3cTPf6wQXD2vGT0SQrcUsKj=s0-d-e1-ft#https://assets.hermes.com/is/image/hermesedito/youtube?fmt=png-alpha"
alt="Youtube"
width="18"
height="22"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="margin:0 auto;height:22px;max-width:51px;padding:0"
align="left"
valign="top"
bgcolor="#f9f9f9"
width="51">&nbsp;</td>
</tr>
<tr>
<td style="margin:0 auto;height:18px;max-width:264px;padding:0"
colspan="9" align="left"
valign="top"
bgcolor="#f9f9f9"
width="264">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:620px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" bgcolor="#f9f9f9">
<p>Hermès Customer Service
<br>Phone number:
<a href="tel:+31207940876"
style="color:#9a9a9a;text-decoration:underline"
target="_blank">+31 20 794 08
76</a>
<br>Monday to Friday (except
National holidays)
<br>from 10.30 am to 6.30 pm
<br>and Saturday, 10.00 am to 6.00
pm
<br>
<a href="mailto:service.nl@hermes.com"
style="font-family:'Arial';font-size:11px;line-height:14px;color:#9a9a9a;text-decoration:underline"
rel="noopener"
target="_blank">service.nl@hermes.com</a>
<br>
<a href="https://www.hermes.com/nl/en/"
style="font-family:'Arial';font-size:11px;line-height:14px;color:#9a9a9a;text-decoration:underline"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw1cWHW91UXus83zenAiXBbJ">www.hermes.com</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:620px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" bgcolor="#f9f9f9">
<p>In accordance with
<a href="https://www.hermes.com/nl/en/privacy-and-cookies-nl/"
style="font-family:'Arial';font-size:11px;line-height:14px;color:#9a9a9a;text-decoration:underline"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/privacy-and-cookies-nl/&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw1hT2-rMmWjNBCr9b71KxVN">the
Confidentiality Policy</a>of the
<a href="https://www.hermes.com/nl/en/"
style="font-family:'Arial';font-size:11px;line-height:14px;color:#9a9a9a;text-decoration:underline"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.hermes.com/nl/en/&amp;source=gmail&amp;ust=1692883797782000&amp;usg=AOvVaw1cWHW91UXus83zenAiXBbJ">hermes.com</a>
website, you have the right to
access, modify, correct and delete
information concerning you ("Data
Protection Act" of 6 January 1978).
<br>Contact the Customer Service
Department for any enquiries.
</p>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:600px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:600px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9" height="20">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center
style="background-color:#f9f9f9!important;width:100%;table-layout:fixed">
<div style="background-color:#f9f9f9!important;max-width:680px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:680px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
<td style="height:auto;padding:0" align="center"
bgcolor="#f9f9f9">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100%;max-width:620px;text-align:center"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="text-align:center;padding:0"
align="center" bgcolor="#f9f9f9">
<span
style="font-family:Arial;font-size:11px;line-height:14px;color:#9a9a9a">Hermès
Sellier - Company with capital of 4
976 000 €
<br>Registered office : 24, rue du
Faubourg Saint-Honoré, 75008 Paris -
France - 696 520 410 RCS Paris
</span>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:6.25%;min-width:6.25%;max-width:6.25%;font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<center style="background-color:#f9f9f9;width:100.0%;table-layout:fixed">
<div style="background-color:#f9f9f9;max-width:600.0px">
<table
style="border-spacing:0;font-family:sans-serif;color:#333333;margin:0 auto;width:100.0%;max-width:600.0px;text-align:center"
cellspacing="0" cellpadding="0" align="center" bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="font-size:0;line-height:0;padding:0"
bgcolor="#f9f9f9" height="50">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
</td>
</tr>
</tbody>
</table>
<img src="https://ci5.googleusercontent.com/proxy/3itZltq1aVTADpygzrqrKKOWIU2kccmh6xg6gF-p562oa0tFbmmxGFbTQxqxsIqIcTE-0-FLYcqaPSkgoLGp_ekK-Xe2ww624OG9xNNZQVkvMtj4ncRlUyvPEN-ECS25oyohBInMcrX40Vr41jyKf4Rmpk5NSlI0v8Uv75HvDh3ooN0Ov4kXESNAT9H94RIlJKXTMWgfNzboxI5NfYGzvw8=s0-d-e1-ft#http://tracker.nmp1.com/WBS?0vibDbBLiKPXpBMEtnJyL3X-1Ty9Z8HRGtRlST6un4_qU7rka7-YdeUkrpkjAxrtmwUx4HBWQsJT0QYdYLIJWg/2CMczpI-FUt_La_FEX6jQA.gif"
alt="" width="1" height="1" border="0" class="CToWUd" data-bit="iit">
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">


</div>
</div>
</div>
<div id=":pu" class="ii gt" style="display:none">
<div id=":pv" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
