export const balenciagaEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<div class=""><div class="aHl"></div><div id=":14h" tabindex="-1"></div><div id=":13o" class="ii gt" jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAwNjQxNjE3MjA5MzAwMiIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAwNjQxNjE3MjA5MzAwMiIsbnVsbCxbXV0."><div id=":13p" class="a3s aiL "><div><div class="adM">
</div><div dir="ltr"><div class="adM">
</div><table style="border-left:1px solid #000000;border-right:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:14px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="14" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:598px;font-size:14px;line-height:18px;color:#000000" align="center">
<a href="https://click.news.balenciaga.com/?qs=e8f07fb0b83784a2fbf3c36e0e01f98449ba602fef0501e5b2b04b86f8c785f7bd5f3c4c139454f0dff675f24fab36b3da7865f6f5c00a77f37a47b7d4ee2c5e" rel="noopener" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://click.news.balenciaga.com/?qs%3De8f07fb0b83784a2fbf3c36e0e01f98449ba602fef0501e5b2b04b86f8c785f7bd5f3c4c139454f0dff675f24fab36b3da7865f6f5c00a77f37a47b7d4ee2c5e&amp;source=gmail&amp;ust=1692864432858000&amp;usg=AOvVaw2CWlX54ORn1IpVzoKfaJtC">
<img style="font-size:0px" src="https://ci4.googleusercontent.com/proxy/Ldis3hVPHAAjHiwcFzXcweQYup4iX3IJbkcslitw2kj2r1iQNIN_34gEEGA44a_46-kqYYbIgIJ-3Y_dw7vLfZaGaAECqeM-jsddZckMFbKiBT-OQ8VKZ6uR_DH0wcGFU80AeLyKYnlWAtcI0XE1B_I2gxHgu70osZ89Mg=s0-d-e1-ft#https://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/73c19a3b-e950-4a7b-92a3-3b6c9767e6c7.png" width="137" height="16" border="0" class="CToWUd" data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-bottom:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:14px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="14" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:440px" align="center">
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:80px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="80" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="center">
<p style="line-height:20px;margin:10px">
<strong>ORDER&nbsp;</strong> 
<strong>CONFIRMED</strong> 
<br>
<br>Dear ${form?.full_name}, 
<br>Thank you for your order with&nbsp;Balenciaga.
</p>
</td>
</tr>
</tbody>
</table>
<table style="height:83px" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr style="height:83px">
<td style="width:440px;height:83px">
<img style="height:80px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="80" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:440px" align="center">
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:12px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="12" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="left">
<p style="line-height:20px;margin:0px 10px">
<strong>ORDER DETAILS</strong>
</p>
</td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:599px">
<img style="height:12px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="12" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="vertical-align:middle;width:200px" align="center">
<img style="outline:0px" src=${form?.image_link} width="200" class="CToWUd" data-bit="iit" jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td>
<table border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:290px" align="left">
<p style="font-size:14px;line-height:20px;color:#000000;margin:10px 5px 10px 10px;text-transform:uppercase">
<strong>${form?.item} 
  <br>
</strong> ${form?.subtotal}
</p>
</td>
</tr>
<tr>
<td style="width:290px" align="left">
<p style="font-size:14px;line-height:20px;color:#000000;margin:10px 5px 5px 10px">Color:&nbsp;<wbr>${form?.color} 
<br>Size: ${form?.size} 
<br>Quantity:&nbsp;1
</p>
</td>
</tr>
<tr>
<td style="width:599px">
<img style="height:12px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="12" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:580px" align="center">
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:40px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="40" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:440px;font-size:14px;line-height:20px;color:#000000" align="left">
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:170px" align="center">
<p style="text-align:left;line-height:20px;margin:5px 10px">Subtotal :</p>
</td>
<td style="width:250px" align="left">
<p style="text-align:right;line-height:20px;margin:5px 10px">${form?.subtotal}</p>
</td>
</tr>
<tr>
<td style="width:170px" align="center">
<p style="text-align:left;line-height:20px;margin:5px 10px">Shipping fees :</p>
</td>
<td style="width:250px" align="left">
<p style="text-align:right;line-height:20px;margin:5px 10px">${form?.shipping}</p>
</td>
</tr>
<tr>
<td style="width:170px" align="center">
<p style="text-align:left;line-height:20px;margin:5px 10px">&nbsp;</p>
</td>
<td style="width:250px" align="left">
<p style="text-align:right;line-height:20px;margin:5px 10px">&nbsp;</p>
</td>
</tr>
<tr>
<td style="width:170px" align="center">
<p style="text-align:left;line-height:20px;margin:5px 10px">
<strong>TOTAL (incl. taxes) :</strong>
</p>
</td>
<td style="width:250px" align="left">
<p style="text-align:right;line-height:20px;margin:5px 10px">
<strong>${form?.total}</strong>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:599px">
<img style="height:40px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="40" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:440px" align="center">
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:40px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="40" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="left">
<p style="line-height:20px;color:#666666;margin:0px 10px;padding-bottom:0px;padding-top:0px">
<strong>Shipping Address</strong>
</p>
<p style="line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.full_name}</p>
<p style="line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.street}</p>
<p style="line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.city} 
<br>
</p>
<p style="line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.zip} 
<br>
</p>
</td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:599px">
<img style="height:20px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="20" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="left">
<p style="line-height:20px;color:#666666;margin:0px 10px;padding-bottom:0px;padding-top:0px">
<strong>Billing Address</strong> 
<br>
</p>
<p style="line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p style="color:#000000;font-size:14px;line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.full_name}</p>
<p style="color:#000000;font-size:14px;line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">
<span style="font-size:small;color:#222222">${form?.street}</span>
</p>
<p style="color:#000000;font-size:14px;line-height:20px;margin:0px 10px;padding-bottom:0px;padding-top:0px">${form?.city} 
<br>
</p>
${form?.zip} 
<br>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:599px">
<img style="height:20px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="20" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="left">
<p style="line-height:20px;margin:0px 10px;padding-top:0px;padding-bottom:0px">PAYMENT METHOD: CREDIT CARD</p>
</td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:599px">
<img style="height:20px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="20" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr>
<td style="width:440px;font-size:14px;text-align:center;line-height:20px;color:#000000" align="left">
<p style="line-height:20px;margin:0px 10px;padding-top:0px;padding-bottom:0px">SHIPPING METHOD: STANDARD</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<br>
<table style="border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:15px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="15" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:24px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="24" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="440" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:14px;line-height:16px;color:#000000" align="center">Should you need any further information, please call us at&nbsp; 
<a href="tel:+44%2020%2033%2018%2060%2032" style="color:#000000;margin-right:0px" rel="noopener" target="_blank">+44 20 33 18 60 32</a>&nbsp;or&nbsp; 
<a href="https://www.balenciaga.com/en-lv/contactus" style="color:#000000" rel="noopener" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://www.balenciaga.com/en-lv/contactus&amp;source=gmail&amp;ust=1692864432859000&amp;usg=AOvVaw3TrjcG9JsOEUIW6wNGd-K-">email us</a>. 
<br>By contacting Client Service, you agree that your data will be transferred outside your country. 
<br>
<br>Balenciaga&nbsp;Client Service
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:20px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="20" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;table-layout:fixed" border="0" width="440" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:14px;line-height:16px;color:#000000;text-align:right;width:198px" align="right">
<a href="https://click.news.balenciaga.com/?qs=e8f07fb0b83784a2b34903b382112bf2c6b3d2e0379cd117e406188952849f2caf65a36e9d9ad8686b17282d8674ef24e91790510c80e5c955d811d9e94fd2e2" style="color:#000000;padding:0px;font-family:'Arial Helvetica',sans-serif;line-height:20px" rel="noopener" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://click.news.balenciaga.com/?qs%3De8f07fb0b83784a2b34903b382112bf2c6b3d2e0379cd117e406188952849f2caf65a36e9d9ad8686b17282d8674ef24e91790510c80e5c955d811d9e94fd2e2&amp;source=gmail&amp;ust=1692864432859000&amp;usg=AOvVaw3EENr93dhiHgGG49D_Zrjt">Terms and Conditions</a>
</td>
<td style="width:20px">
<img style="height:16px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="16" border="0" class="CToWUd" data-bit="iit">
</td>
<td style="font-size:14px;line-height:16px;color:#000000;width:198px" align="left">
<a href="https://click.news.balenciaga.com/?qs=e8f07fb0b83784a2a7a93e0e82361974279a44578fc5500ba8a0333e6ae248393d622c95928297e908b0fe5bb72b1d4a6971ba69fa451b5143a2f65b2f130f9c" style="color:#000000;padding:0px;line-height:16px" rel="noopener" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://click.news.balenciaga.com/?qs%3De8f07fb0b83784a2a7a93e0e82361974279a44578fc5500ba8a0333e6ae248393d622c95928297e908b0fe5bb72b1d4a6971ba69fa451b5143a2f65b2f130f9c&amp;source=gmail&amp;ust=1692864432859000&amp;usg=AOvVaw0kDToZS6l5pxlqyu_c3Vhz">Privacy Policy</a>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:24px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="24" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="border-radius:4px" align="center" bgcolor="#ffffff">
<a href="https://click.news.balenciaga.com/?qs=e8f07fb0b83784a24f8996be243ba869ff0cc37b0e38e21b4a9b803621996cc152699d940a6d6fec45e6dc3443ebc799ed6645b63ade5a6640754da81cc273cb" style="color:#000000;border-radius:4px;padding:9px 30px;border:1px solid #000000;display:inline-block;font-size:12px;line-height:20px;text-decoration-line:none" rel="noopener" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://click.news.balenciaga.com/?qs%3De8f07fb0b83784a24f8996be243ba869ff0cc37b0e38e21b4a9b803621996cc152699d940a6d6fec45e6dc3443ebc799ed6645b63ade5a6640754da81cc273cb&amp;source=gmail&amp;ust=1692864432859000&amp;usg=AOvVaw2LmZ8STgnlR1Z3ZjVSctcR">
<span style="color:#000000">VISIT&nbsp;BALENCIAGA.COM</span>
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="line-height:13px" role="presentation" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<div>&nbsp;</div>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:24px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="24" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<div>
<table style="border-collapse:collapse;border-top:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:12px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="12" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px" align="center">
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:599px;font-size:14px;line-height:20px;color:#181212" align="center">© 2023&nbsp;Balenciaga</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse;border-bottom:1px solid #000000" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:12px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="12" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width:599px">
<img style="height:20px" src="https://ci4.googleusercontent.com/proxy/TQ9I_TnVnVIBBl7p-91Zp5Pkr3RyuoPrijXPFcvxGTuiccUuzdFlaAjQ0vTT3lP5K-UkvubcrzAS-Uo1SX0huXWXvXdk9TrrimfD5i5JXEGcHi-OM8iw7OqavkLl1zRa5rwOFtYgtDslsrfVOECAYdpP4NzQytC5OwdU=s0-d-e1-ft#http://image.news.balenciaga.com/lib/fe3e15707564047f701372/m/1/51a78701-58a5-4e28-b13f-fdcd57ed0b3a.gif" width="1" height="20" border="0" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table><div class="yj6qo"></div><div class="adL">
</div></div><div class="adL">
</div></div><div class="adL">


</div></div></div><div id=":14d" class="ii gt" style="display:none"><div id=":155" class="a3s aiL "></div></div><div class="hi"></div></div>
</body>
</html>`;
};
