export const diorEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":14e" tabindex="-1"></div>
<div id=":16s" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAxMDM1ODE1MDkzMjg4OSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAxMDM1ODE1MDkzMjg4OSIsbnVsbCxbXV0.">
<div id=":16r" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div dir="ltr">
<div class="adM">
<br>
</div>
<table style="width:1518px;margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<p
style="margin:0px;padding:0px;text-align:center;font-size:10px;color:#8a8a8a;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:14px">
If you can't see this email, click&nbsp;
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd05f&amp;p1=%40WghcRDu7QY0DNEtsZC75hgEhg4P%2Fir3bj%2BrfMIgYGhw%3D"
style="color:#9c9e9f" rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd05f%26p1%3D%2540WghcRDu7QY0DNEtsZC75hgEhg4P%252Fir3bj%252BrfMIgYGhw%253D&amp;source=gmail&amp;ust=1692868199547000&amp;usg=AOvVaw0IiaOM17Dl3GN8d8tGW_hR">here</a>
<br>
<br>We prepare your order with the greatest care
</p>
</td>
</tr>
</tbody>
</table>
<table style="max-width:600px;margin:0px auto;width:600px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:20px 0px 40px" align="center">
<center>
<img style="display:block;font-family:'Times New Roman',Times,serif;font-size:50px;line-height:normal;color:#000000"
src="https://ci6.googleusercontent.com/proxy/DYB6eJSmHfnzpdAiTy1cHYl0pgV9pjTOUYUBufJpF55VTEE-DJZtqzg3up7fAN_zDyxR8AFekSaXWa1K7lZ17HEUJE_RyJ4sCUtS1BxAyb9_6GsbuGtiBWtvRPEXMO8=s0-d-e1-ft#http://t.news.christiandior.com/res/img/8F081BBF31D832F3906AC0E7C2384E7B.png"
alt="DIOR" width="160" border="0" class="CToWUd"
data-bit="iit">
</center>
</td>
</tr>
</tbody>
</table>
<table style="max-width:1200px;margin:0px auto;width:1200px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0"
width="100%" cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="height:560px"
valign="top" bgcolor="#ffffff"
height="560">
<div>
<table
style="max-width:700px;margin:0px auto;width:700px"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:50px 0px 0px"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="height:510px"
valign="top"
height="510">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td
style="padding:50px 0px 0px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
THANK
YOU
FOR
YOUR
ORDER
</h1>
</td>
</tr>
<tr>
<td
style="padding:35px 0px 0px">
<table
style="margin:0px auto"
border="0"
width="72%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Dear&nbsp;
<strong>${form.full_name}</strong>,
<br>We
are
pleased
to
confirm&nbsp;
<span
style="text-decoration-line:underline">your
order
number
${form.order_number}</span><wbr>, placed on ${form.order_date}<wbr>. It will be prepared with the greatest care and we will notify you by email as soon as it is dispatched.
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding:30px 0px 0px">
<table
style="margin:0px auto"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-radius:30px;padding:0px 50px;height:52px"
valign="middle"
bgcolor="#000000"
height="52">
<p
style="margin:0px;padding:0px;font-size:14px;color:#ffffff;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:17px">
<a href="https://www.dior.com/"
style="color:#ffffff;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.dior.com/&amp;source=gmail&amp;ust=1692868199547000&amp;usg=AOvVaw3iWqshdxs07WkgN-DjPMMb">VIEW
YOUR
ORDER</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding:35px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Thank
you
for
your
trust
and
see
you
very
soon,
<br>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd060&amp;p1=fr_fr&amp;p2=fr-fr_order_confirmation"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd060%26p1%3Dfr_fr%26p2%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199548000&amp;usg=AOvVaw1gI6uGCUq2ExNoyxfES4sW">Dior.com</a>
</p>
</td>
</tr>
<tr>
<td
style="padding:35px 0px 0px">
<table
style="margin:0px auto"
border="0"
width="70%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<p
style="margin:0px;padding:0px;text-align:center;font-size:12px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:20px;font-style:italic">
If
you
have
any
questions,
please
contact
our
customer
relations
department
on&nbsp;
<span
style="text-decoration-line:underline">+1&nbsp;800
929
3467.</span>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:0px" align="center">
<table style="margin:0px auto;width:60px"
border="0" cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">
&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:50px 20px 0px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
DELIVERY ADDRESS AND
<br>BILLING
</h1>
</td>
</tr>
<tr>
<td style="padding:20px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
You have chosen&nbsp;
<strong>
<strong>Standard delivery</strong>
</strong>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto;width:1518px" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center" bgcolor="#eeeeee">
<tbody>
<tr>
<td style="padding:0px 0px 40px">
<table style="max-width:700px;margin:0px auto" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="font-size:0px" align="center"
valign="top">
<div
style="max-width:350px;margin:0px auto;display:inline-block;vertical-align:top">
<table style="margin:0px auto" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td
style="padding:40px 0px 0px">
<table
style="margin:0px auto;width:330px"
border="0"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:15px">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:30px 20px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
<strong
style="text-transform:uppercase">${form.full_name}</strong>
<br>${form.street}
<br>${form.city}
<br>${form.zip}
<br>${form.country}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:50px 0px 0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="border:1px solid #dddddd">
<table style="margin:0px auto" border="0"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:50px 30px 0px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
YOUR ORDER No.
${form.order_number}
</h1>
</td>
</tr>
<tr>
<td style="padding:20px 20px 10px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Each of the items you have
chosen has been made
<br>with all the Dior
know-how. We hope they
<br>will fully meet your
expectations.
</p>
</td>
</tr>
<tr>
<td>
<table style="margin:0px auto"
border="0" width="82%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:20px 0px 10px;border-bottom:1px solid #e5e5e5;height:56px">
<br>
</td>
</tr>
<tr>
<td
style="padding:20px 0px;border-bottom:1px solid #e5e5e5">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:125px"
align="left">
<img style="margin-right:0px"
src=${form.image_link}
alt="dfsdg.png"
width="109"
height="109"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
<br>
</td>
<td style="padding:5px 0px 0px"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<p
style="margin:0px;padding:0px;font-size:17px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal;text-transform:uppercase">
${form.item}
</p>
</td>
</tr>
<tr>
<td>
<p
style="margin:0px;padding:0px;font-size:14px;color:#757575;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
Size:
${form.size}
</p>
</td>
</tr>
<tr>
<td>
<p
style="margin:0px;padding:0px;font-size:13px;color:#757575;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
Quantity:
1
</p>
</td>
</tr>
<tr>
<td>
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
${form.subtotal}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding:10px 0px 15px;border-bottom:1px solid #e5e5e5">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:10px 0px 0px;width:104px">
<p
style="margin:0px;padding:0px;text-align:right;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
Amount
excluding
VAT
</p>
</td>
<td
style="padding:10px 0px 0px 20px">
<p
style="margin:0px;padding:0px;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
${form.subtotal}
</p>
</td>
</tr>
<tr>
<td
style="padding:10px 0px 0px;width:104px">
<p
style="margin:0px;padding:0px;text-align:right;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
Taxes
</p>
</td>
<td
style="padding:10px 0px 0px 20px">
<p
style="margin:0px;padding:0px;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
${form.taxes}
</p>
</td>
</tr>
<tr>
<td
style="padding:10px 0px 0px;width:104px">
<p
style="margin:0px;padding:0px;text-align:right;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
Shipping
cost
</p>
</td>
<td
style="padding:10px 0px 0px 20px">
<p
style="margin:0px;padding:0px;font-size:13px;color:#757575;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
${form.shipping}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding:10px 0px 50px">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:10px 0px 0px;width:104px">
<p
style="margin:0px;padding:0px;text-align:right;font-size:15px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
TOTAL
</p>
</td>
<td
style="padding:10px 0px 0px 20px">
<p
style="margin:0px;padding:0px;font-size:15px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
${form.total}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:30px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
<strong>Returns and exchanges are offered to
you within 30 days</strong>
<br>following receipt of your order.
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:40px 0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px 20px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
OUR NEWSLETTER</h1>
</td>
</tr>
<tr>
<td style="padding:20px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Receive all the latest news from the House
by email
<br>and discover our new collections in
preview.
</p>
</td>
</tr>
<tr>
<td style="padding:20px 0px 0px">
<table style="margin:0px auto" border="0"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-radius:30px;padding:0px 50px;height:52px"
valign="middle"
bgcolor="#000000" height="52">
<p
style="margin:0px;padding:0px;font-size:14px;color:#ffffff;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:17px">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd063&amp;p1=fr-fr_order_confirmation"
style="color:#ffffff;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd063%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199548000&amp;usg=AOvVaw38fgu2WKfJexAt1yV-nFJq">REGISTER</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:50px 0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px 20px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
DISCOVER OUR NEWS</h1>
</td>
</tr>
<tr>
<td style="padding:20px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Creations from our latest collections
<br>and selected for you.
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="font-size:0px" align="center"
valign="top">
<div
style="max-width:233px;margin:0px auto;display:inline-block;vertical-align:top">
<table style="margin:0px auto" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table
style="margin:0px auto;width:213px"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd06a&amp;p1=fr_fr"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd06a%26p1%3Dfr_fr&amp;source=gmail&amp;ust=1692868199548000&amp;usg=AOvVaw2jg10yfLx2_gL1mvCyhlt5">
<img style="display:block"
src="https://ci6.googleusercontent.com/proxy/ouR049GiZKPRQ8unWqrp4DwAQmUJO8YfH_ob4pbAZzvvsxVB3H6Ol_gFx_4ZKpEyceDxjgSZkVc9NUqaHNwLhviT-T_Ejrr_jguxk0H8BAQZr436K14VLi-716F5gK1f2oP_guvl7JIeNLlpe2bwN07USFWLvTxR3UlfYnwK-RoWbWQ7jK3B5Anc4IjHUyW6OUEuyOXZGw-pPchaRihScp7SoimOia1RW2W1U01jtwJy2D9GIMbN91NgTw=s0-d-e1-ft#https://wwws.dior.com/couture/ecommerce/media/catalog/product/cache/1/cover_image_mobile_1/9df78eab33525d08d6e5fb8d27136e95/A/1/1667915114_1ADDU114DOS_H30Q_E01_GHC.jpg"
alt=""
width="213"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
<tr>
<td
style="padding:20px 0px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px;height:35px">
Dior
Ingot 26
bag</p>
</td>
</tr>
<tr>
<td
style="padding:20px 0px 0px">
<table
style="margin:0px auto;width:213px"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-radius:30px;padding:0px 20px;height:52px"
valign="middle"
bgcolor="#000000"
height="52">
<p
style="margin:0px;padding:0px;text-align:center;font-size:14px;color:#ffffff;text-transform:uppercase;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:17px">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd06b&amp;p1=fr_fr"
style="color:#ffffff;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd06b%26p1%3Dfr_fr&amp;source=gmail&amp;ust=1692868199548000&amp;usg=AOvVaw3EzkLu7YuX8xs0R_cDUXcJ">ORDER</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
<div
style="max-width:234px;margin:0px auto;display:inline-block;vertical-align:top">
<table style="margin:0px auto" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table
style="margin:0px auto;width:213px"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd06c&amp;p1=fr_fr"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd06c%26p1%3Dfr_fr&amp;source=gmail&amp;ust=1692868199548000&amp;usg=AOvVaw3DkC9Unsdoc7CaInDMFzAB">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/GnJCVQdkGqK9k5uekEhb3-rZp8OF1NzE_a0-s4W4O6BrYwvvok3JAvhpAl0hUImwJ39c2kmdYCOCKGqM-9IZM5Mm-JK5lV9fMr0lYjy8ixpPjkypVdGG0zVKFVeuYshtkYqV0MQzar4zUL4V0ZqgXxktQ-rlUIiEoh72MzefT8UO6MNUlE4dxQv7yVBg6YVMhjY1JzwfMxqVdbQOEGbeRcZGkcona0FFGkfNlfwQMD8BquKnHrye8hUW8Ys=s0-d-e1-ft#https://wwws.dior.com/couture/ecommerce/media/catalog/product/cache/1/cover_image_mobile_1/9df78eab33525d08d6e5fb8d27136e95/E/c/1666372322_113J631A0684_C585_E01_GHC.jpg"
alt=""
width="213"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
<tr>
<td
style="padding:20px 0px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px;height:35px">
Dior
Oblique
hoodie,
relaxed
fit</p>
</td>
</tr>
<tr>
<td
style="padding:20px 0px 0px">
<table
style="margin:0px auto;width:213px"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-radius:30px;padding:0px 20px;height:52px"
valign="middle"
bgcolor="#000000"
height="52">
<p
style="margin:0px;padding:0px;text-align:center;font-size:14px;color:#ffffff;text-transform:uppercase;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:17px">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd06d&amp;p1=fr_fr"
style="color:#ffffff;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd06d%26p1%3Dfr_fr&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw2e2d7jT0-gBNuQZv53fDeS">ORDER</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
<div
style="max-width:233px;margin:0px auto;display:inline-block;vertical-align:top">
<table style="margin:0px auto" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:20px 0px">
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:1200px;margin:0px auto;width:1200px" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:10px 0px">&nbsp;</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="border:1px solid #dddddd">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:50px 20px 0px">
<h1
style="margin:0px;padding:0px;text-align:center;font-size:28px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
WE ARE AT YOUR DISPOSAL</h1>
</td>
</tr>
<tr>
<td style="padding:20px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Our ambassadors answer all your questions
<br>in your language.
</p>
</td>
</tr>
<tr>
<td style="padding:20px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
<a
style="color:#222222;text-decoration-line:underline">+1&nbsp;800
929 3467.</a>
</p>
</td>
</tr>
<tr>
<td style="padding:10px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
&nbsp;</p>
</td>
</tr>
<tr>
<td style="padding:20px 20px 0px">
<p
style="margin:0px;padding:0px;text-align:center;font-size:15px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:25px">
Monday to Friday from 10 a.m. to 9 p.m.
<br>Saturday from 10 a.m. to 7 p.m.
</p>
</td>
</tr>
<tr>
<td style="padding:20px 0px 50px">
<table style="margin:0px auto" border="0"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-radius:30px;padding:0px 50px;height:52px"
valign="middle"
bgcolor="#000000" height="52">
<p
style="margin:0px;padding:0px;font-size:14px;color:#ffffff;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:17px">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd074"
style="color:#ffffff;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd074&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw2i670FBUsQPwZyYnN59h2a">CONTACT
US</a>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="width:1518px;margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="margin:0px auto;width:1518px" border="0" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px" align="center">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="padding:45px 0px">
<table
style="margin:0px auto;max-width:700px;width:700px"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:0px;vertical-align:top"
align="center">
<table style="margin:0px auto"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th
style="width:215px;margin:0px auto;vertical-align:middle">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<table
style="margin:0px auto"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th
style="padding:0px">
<table
style="margin:0px auto;max-width:700px;width:700px"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="vertical-align:top"
align="center">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th
style="width:215px;margin:0px auto;vertical-align:middle">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:0px">
<h3
style="margin:0px;padding:0px;text-align:center;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:19px">
E-SHOP
ADVANTAGES
</h3>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</th>
<th
style="width:270px;margin:0px auto;vertical-align:middle">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<table
style="margin:0px auto"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th style="width:20px;padding-right:10px"
align="">
<img style="display:block;margin:0px auto"
src="https://ci3.googleusercontent.com/proxy/uEkm-lcy3R1m8VtYxU4x1ll1jSMlnIt9fCe0wX_jlcnPHER6PESsrYjlytt-PiKmWIGTo4595lms_ZEto83LAv8d5QAhy2CHf_UiSB6VgtIXnK5cMO9aO_vO2cr1Xl_1=s0-d-e1-ft#https://t.news.christiandior.com/res/img/58A0EB3971B0E887EDE9301E216197A8.png"
alt="FREE RETURNS"
width="20"
border="0"
class="CToWUd"
data-bit="iit">
</th>
<th
style="padding:0px">
<h3
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:19px">
DELIVERY
<br>OFFERED
</h3>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</th>
<th
style="width:215px;margin:0px auto;vertical-align:middle">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="top">
<table
style="margin:0px auto"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<table
style="margin:0px auto"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th
style="width:20px;padding-right:10px">
<img style="display:block;margin:0px"
src="https://ci4.googleusercontent.com/proxy/Vlmu9KNOKyU5yL9psU20H72UD-3gdhRXCOsyt38JA-wm6rEHwSpjQhMLpJvISY2_ZvZaSqu43HQ3s-Wz5wmGkG_Fqy41Y8xKmKeCEpLJSXVvZb-X6GPQK_TFZvQQi3T3=s0-d-e1-ft#https://t.news.christiandior.com/res/img/E325AB746309A9ACD34916B4E6696398.png"
alt="iconic Dior box"
width="20"
border="0"
class="CToWUd"
data-bit="iit">
</th>
<th
style="padding:0px">
<h3
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:19px">
BOX
<br>ICONIC
</h3>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<h3
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-weight:normal;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:19px">
&nbsp;
</h3>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:800px;margin:0px auto;width:800px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px">
<table style="margin:0px auto;width:800px"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:30px 0px">
<table style="margin:0px auto"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<table
style="margin:0px auto"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<th
style="padding:15px 10px">
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd075&amp;p1=fr-fr_order_confirmation"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd075%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw3qZ6up7vQPHyNO-LWwr8KL">CONTACT</a>
</p>
</th>
<th
style="padding:15px 10px">
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd076&amp;p1=fr_fr"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd076%26p1%3Dfr_fr&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw2vgyIZN-LaQeox0QqUbGpA">SHOPS</a>
</p>
</th>
<th
style="padding:15px 10px">
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd077&amp;p1=fr-fr_order_confirmation"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd077%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw31b4tGmAAPJxNdCBWgFiRf">LEGAL
NOTICE</a>
</p>
</th>
<th
style="padding:15px 10px">
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd078&amp;p1=fr-fr_order_confirmation"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd078%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw0CjEpQSiSjX7-ZAy1Tdv3A">PRIVACY
POLICY</a>
</p>
</th>
<th
style="padding:15px 10px">
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd079&amp;p1=fr-fr_order_confirmation"
style="color:#000000;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd079%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199549000&amp;usg=AOvVaw0Gu9kiua2hJU-S2UXjaMfp">TERMS
OF
SALES</a>
</p>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:700px;margin:0px auto;width:700px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:35px 0px">
<table style="margin:0px auto" border="0"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:10px">
<center>
<p
style="margin:0px;padding:0px;font-size:14px;color:#000000;font-weight:bold;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:normal">
FOLLOW US</p>
</center>
</td>
<td style="width:21px;padding:10px">
<center>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd07a"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd07a&amp;source=gmail&amp;ust=1692868199550000&amp;usg=AOvVaw33aZyqkDwY1CNr4xrqxAHz">
<img style="display:block;margin:0px auto;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:24px"
src="https://ci5.googleusercontent.com/proxy/l-R3WNjK7a5yvDzuerYBlGT06HYBc6aqleQhkeAMMaHhzL0NeTrJdcAWesUsdQBAcw5R-d87zEx9guFuCPDKJmNFQ2PeUmxzB3qrP0f_NpPedo1VkUFiTARfYNal9Ba2=s0-d-e1-ft#https://t.news.christiandior.com/res/img/BC9A13B39A08B9C217D70E9694C1920A.png"
alt="Facebook"
width="21"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</td>
<td style="width:21px;padding:10px">
<center>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd07b"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd07b&amp;source=gmail&amp;ust=1692868199550000&amp;usg=AOvVaw1QR0oLmvdqSacKSqRlLIJJ">
<img style="display:block;margin:0px auto;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:24px"
src="https://ci5.googleusercontent.com/proxy/jfHUVwGMbV5b0g9-v6i5ZXrgS9Sp9Ans6t17Pr_GlBarRsWBZxxgRiwRWdG3r1Tv64QBsujWylWfbqjYLTyDn6jfS-LkiZymdMXF5aauZPeM2k3zKmL9SrqKQo9oWz1S=s0-d-e1-ft#https://t.news.christiandior.com/res/img/2D9BAB5C53B67A77BD2713083B8CE5D8.png"
alt="instagram"
width="21"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</td>
<td style="width:21px;padding:10px">
<center>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd07c"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd07c&amp;source=gmail&amp;ust=1692868199550000&amp;usg=AOvVaw0sdfEjeel8e5bUJliMaGx_">
<img style="display:block;margin:0px auto;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:24px"
src="https://ci4.googleusercontent.com/proxy/qbPdE18gM5TYr9TVmZ1_doBGc7EuNTYuACNPdSgw1Ke0HzomKpX_QSHah1ZteYsOp9XkGgFjKt7BBdqMlp9sNGM2y9hsZBzZEkqTKKWPsG9TKFFnICNtnEYdxyArgnir=s0-d-e1-ft#https://t.news.christiandior.com/res/img/9A4AB339E1A0D3E2B9917730A0C06E0D.png"
alt="Youtube"
width="21"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</td>
<td style="width:21px;padding:10px">
<center>
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd07d"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd07d&amp;source=gmail&amp;ust=1692868199550000&amp;usg=AOvVaw1FGUDCPk4ukj1jG9KKIhi9">
<img style="display:block;margin:0px auto;font-size:14px;color:#000000;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:24px"
src="https://ci5.googleusercontent.com/proxy/HmmtTZR3DAksfvo_gs8taahvGvRZr8fZTU_Kb6n_cXrp0pMhNjg4s7Xc8XxYqHMWWNh46vddOMuf8aK7c_ECUX-3qi9zqOfv1FYEn6jgpNhyKs1RnM5TYPKCmR7ygN07=s0-d-e1-ft#https://t.news.christiandior.com/res/img/FEDE6F0AD19F3BFABDCF2FDEB1D98AF6.png"
alt="twitter"
width="21"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="margin:0px auto" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="line-height:1px;font-size:1px;height:1px"
bgcolor="#e5e5e5" height="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="max-width:690px;margin:0px auto;width:690px" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center">
<table style="margin:0px auto" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:0px 10px 20px">
<table style="margin:0px auto;width:670px"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:45px 0px">
<table style="margin:0px auto"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td>
<p
style="margin:0px;padding:0px;text-align:center;font-size:12px;color:#8a8a8a;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:21px">
At Christian
Dior
Couture, we
take your
choices and
the
confidentiality
of your data
seriously.
<br>Please
consult our
privacy
policy
on&nbsp;
<a href="https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id=h3760535,6aed1b5,28fd07e&amp;p1=fr-fr_order_confirmation"
style="color:#8a8a8a;text-decoration-line:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://diorcouture-rt-prod2-t.adobe-campaign.com/r/?id%3Dh3760535,6aed1b5,28fd07e%26p1%3Dfr-fr_order_confirmation&amp;source=gmail&amp;ust=1692868199550000&amp;usg=AOvVaw2QBAbg76mXrp2pQEn0VzsN">dior.com</a>&nbsp;for
any
information
regarding
the
processing
of your
personal
data by
Christian
Dior
Couture.
<br>
<br>In
accordance
with
applicable
laws and
regulations,
you have the
right to
consult,
modify and
delete any
data
concerning
you. You can
also ask not
to receive
personalized
communications
about our
products and
services.
You can
exercise
this right
at any time,
by
contacting
our customer
service
at&nbsp;+1&nbsp;800
929 3467.
<br>
</p>
<p
style="margin:0px;padding:0px;text-align:center;font-size:12px;color:#8a8a8a;font-family:'Century Gothic',CenturyGothic,AppleGothic,sans-serif;line-height:21px">
You can also
contact our
Data
Protection
Officer
at&nbsp;
<a href="mailto:privacy@christiandior.com"
style="color:#8a8a8a;text-decoration-line:none"
rel="noopener"
target="_blank">privacy@christiandior.com</a>
<br>
<br>
<em>Please
do not
respond
directly
to this
email.</em>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">

</div>
</div>
</div>
<div id=":14i" class="ii gt" style="display:none">
<div id=":14j" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
