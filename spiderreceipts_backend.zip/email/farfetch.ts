export const farfetchEngEmail = (form: any) => {
return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":oz" tabindex="-1"></div>
<div id=":m9" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyMjkwMjY0MTc2NTE3MSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyMjkwMjY0MTc2NTE3MSIsbnVsbCxbXV0.">
<div id=":ma" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div>
<div class="adM">
</div>
<table style="border:0px;padding:0px;margin:0px;display:none;float:left" cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px;padding:0px" height="1">
<img src="https://ci5.googleusercontent.com/proxy/er0PotEiANWpitEEUVkGLdMC4WxC_NO6T03ipAjtcJlyFGs3ETmeNcuOxam5REqFM8O5Stn-GHXdXM5JOeqKthzeraXMi3ZimyJeGqTq91kW9grkAuQLlsFEdbFZ7FCRkTUeqO1EbnrfE12v-8opf1FWwDAA8vFU6S6JYkBj_F6vMeRnO2F0B4igA7QtvortrGiDsmhRO_9kc4iQSx1U9Y3DGHRfppAXSAvOj0W3VRQxUflkEW4SvNwyP1E5o6pkcOh3v92aEmepwWVyZIw0iMApyc8h8eRZxvTzLuKoXCc5054vgUMDcLTktpKrHW0fHfvpZ7jQU3aRYjO5kN6nyC1OoswJXia_WJXUMWoNYRNVpASb8C-BsTm3XZlTYsWZozS9hEwzc6wx6v1TvcA=s0-d-e1-ft#https://email.farfetch.com/pub/as?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXHkMX%3Dw&amp;_ei_=EolaGGF4SNMvxFF7KucKuWOtq33HPn0xHq3DWe1aYeuFPARdhhEr-wbGqUCufvjZ5OHai0kueo4t5nTEzu6AZimwvwMHqi11I2W1uJUdFJwshP8zrHWtGliGM24PX1FKd8k6ljJ5mI-z2tn6b5w."
class="CToWUd" data-bit="iit">
<img src="https://ci4.googleusercontent.com/proxy/OMYXVIX9UpQ32AAwrf1HD8_vygS1Dhw53tKgjzAXzjkZGFH7vvPtop0IvVpx5cs7E-JeIiASmVhIgnei3iuOM54ZJaY6GheQYhNj5_TJD14KPkyaSShmwjMmu-dxZSAqoe57uLyQRI1Ot3CYJkNlIH5PEz0pbk7j6qklb4SSoOWPqp5Z6r3QZ4VylU9mBID-pDqhmkBiFexdfjHTATxLGVO9L9WNdE5BQqZB1ojhgLsb=s0-d-e1-ft#https://tags.bluekai.com/site/64751?e_id_s64751=20341a70e15bc537c660177fafdfa29a882b8856c03a020afbc0dc775f0b7540&amp;e_id_m64751=6ae10530bd70b48dc621c093a8606e6b"
width="1" height="1" class="CToWUd" data-bit="iit">
<br>
<br>
</td>
</tr>
</tbody>
</table>

</div>
</div>

<div>
<table
style="border-spacing:0;vertical-align:top;height:100%;width:100%;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;float:none;text-align:center;border-collapse:collapse;padding:0"
align="center" valign="top">
<center style="width:100%;min-width:576px">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:35px 16px 35px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;height:150px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%"
height="150">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DYABWWAY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.&amp;_di_=3aq4pigqgt3e6krmahl1pivsen543o0g51195594dj4ehjr1ns80"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DYABWWAY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.%26_di_%3D3aq4pigqgt3e6krmahl1pivsen543o0g51195594dj4ehjr1ns80&amp;source=gmail&amp;ust=1692880167798000&amp;usg=AOvVaw0Wl9vrbJFFFn7UC03JImw5">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src="https://ci3.googleusercontent.com/proxy/Z0vZbMGnkEUuL_2fwMHv2GJ5WbcORY3QDqvJHyXSFd4brjO8HRMCyl5cd5Pf9_1IovbRgk5n7OpJeO4k3Y-lKGLgadqz0HMwj53Lr70aEm_kG8-KKCWwtzSy7i474rLUSCsc1g5YxXibaY0GZxwU85C1Zbl8hC4P7XBQR0nnfadIoKDQjIEeI4iCKQ4RzG-JApGBfEN9BovldlAIukp5FLcl9X2C759EXyHDSD9gzbjvxEE=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_default@4x.png"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</a>
<div
style="display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;border:none;margin:0 auto;float:none;text-align:center;display:none"
src="https://ci5.googleusercontent.com/proxy/6z5c-QH7a3fJ5nmuR6sK1-EclhXnsgVH8cph_hCNwJjmtglCechBAtAvUMcOtBdIRcD4FLBvkXXBaed_lRH0B_cw8X-i7den5M1rwlH7bXnppMBgReKRMGtfMoXrfu_MyVKbBGjtaQc1x1n57PA-NKGqQ3aH57rprY00jqfaoNy0THMJ9xXa-LtZUTWXOYg9dEUWXuxKMMlpdDiAsY8MtRAf2ISZc31qd2-u7C3UG8Q=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_dark@4x.png"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</div>
<div
style="display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;border:none;margin:0 auto;float:none;text-align:center;display:none"
src="https://ci5.googleusercontent.com/proxy/g1dd1YBbPmcl2gSyaiRJjB_ZNDS3n0zbASzxIxFlacwYjxIibUqygJfce5LTmfA9bxDTjTWfs4bZAwLSK4GrTr8Ij69I9VICoI7kdd0Y4L9m8xbCjY_SBVbt2-f8lsrS0KDe2KaK5XZW0m6G02_GqJUJ7ee2yeQlYWq2WrUyh32P9RGV0vmQzu0lnG4fUTa8MrV5IkpxzObqhV2yK_SL67Frqo5ZCN5IM5hVXQp4fp4P=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_light@4x.png"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</div>
</center>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:48px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h1
style="margin:0;font-family:'NimbusSansExtD-Bold','Helvetica Neue Bold','Arial Bold',sans-serif;font-weight:bold;font-size:26px;line-height:26px;text-transform:uppercase;text-align:center">
YOU’VE
MADE
A
GREAT
CHOICE
</h1>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:24px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:center">
Order
number:
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.order_number}</span>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:12px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:center">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DYABWWCY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.&amp;_di_=2p4ve96e26v85iptsd3b200nfa6n5l2ok1ihpbhvh7216buajpo0"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DYABWWCY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.%26_di_%3D2p4ve96e26v85iptsd3b200nfa6n5l2ok1ihpbhvh7216buajpo0&amp;source=gmail&amp;ust=1692880167799000&amp;usg=AOvVaw01g7_iJr-DSwIcOnrSm-Rj">View
Account</a>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Hi
${form?.full_name},
</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Thanks for shopping with
FARFETCH. We've received
your order and will process
it shortly, this can take up
to two business days.</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Once we've sent your order,
you'll receive an email with
the tracking number. If
you've placed your order
using our F90 or Same Day
delivery services and have
any questions, please
contact our Customer Service
team.</p>
<br>
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">
Shopped pieces from multiple
locations?</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
We’ve got it covered. We’ll
confirm when each item has
been sent - please note you
may receive more than one
package.</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
We hope you love your new
find!</p>
<br>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
FARFETCH</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<h3
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:19px;line-height:26px;margin-bottom:24px">
Your delivery information
</h3>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
${form?.full_name}
<br>${form?.street}
<br>${form?.city}
<br>${form?.zip}
<br>${form?.country}
<br>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left" valign="top">&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:24px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0 0 6px 0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci6.googleusercontent.com/proxy/jE1HbBMBjNsjb2oClYxm4CUZfBCvZ32D_z9YZd7DPRl4YpsnZKmgU_Lo5BdIhrVd4jJsxlnmXddSh39D93D_lKGU7Wt8nTeG5-OqFEin4SV2J5N4AgMRu3o8pVpFtoXqMty0OxKZ9sYJXL-DO9Ht5x83rTuwtWoD7k3sTSx1D-gRbfyxt6dWyT8EkeiWZcxP71ecvWAmv9WSIevDSRpZWIl8n9w=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconVanLight@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
<span
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci3.googleusercontent.com/proxy/t_21O2vFuq1pplId5OkOBslxKXTUgEwfWmAMmMTB2vdKh1ghKj6HbErmwurZV93BzaZ-0s1oKeFKnEfVNoVQiQVlF7EnIhViFtB5VabebTcfREUhjcU5Yi9sJZOYCZ4RqHpCIIE4yOG7G05UK5npMHJX85tri7mq8AeaKchiLbvFqDF8UwAZ4AEk5iPUt8TCIqVht2vfmGZaWCh4BCa14bPkEg=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconVanDark@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
</span>
<span
style="margin:0;font-size:16px;line-height:22px;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">We
are
here
for
you</span>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Delivering
safely
to
your
door&nbsp;&nbsp;
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DCWYRUBAY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.&amp;_di_=9q8jv6f7kb311u354bgk90i7aj8vk6hvbtehp3nr4uuucpf29hu0"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DCWYRUBAY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.%26_di_%3D9q8jv6f7kb311u354bgk90i7aj8vk6hvbtehp3nr4uuucpf29hu0&amp;source=gmail&amp;ust=1692880167799000&amp;usg=AOvVaw3xUhjiqXcbEenUc5_DpniL">Here’s
how</a>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:24px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0 0 6px 0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci5.googleusercontent.com/proxy/bbW33nqM8uJ4uB71z2771WylpukVSXIGCpi0hkvQ0kPu1srSJsXbTzZ0Q4kIypFRCReY6j94w-c66JnA7bk6qKD7MH9k3D4fTx4GPLESBXLKezKZ2fPhU7VN0eHjy6JapvI0ntKOaqOtkGd-62rH2J9n93iHSkFcTb0pss3v6ODdvvEz5607m-QgvPWCoo34UIxvgoChVoWqjXkrR5gvMKjPdW1ohUW7R4hBRsAE1o0=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconClimateConciousLight@4x.png"
alt="Positively Farfetch environment leaf icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
<span
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci4.googleusercontent.com/proxy/fksJQd_miDol0waIGXS6l6FOPNl_KhMKgxx_mUYhVMxgWUzl8mLMBM6iZWpHSssqpWB4E7kALXxR9HlcCoSQURyh-V25GD1NjX1HahjoLb2b_to3YgRoE8n7MR-5Ue28phnCPqvgM0EXcpJCmhZMQbvPmdSDinq3DGtV8RR-CssSiNqfIjDDsQckjt09SaBp_0tekZF_V5qY51mLIlKPRzJrgPvQ5Uw_SNx7Zi7qQA=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconClimateConciousDark@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
</span>
<span
style="margin:0;font-size:16px;line-height:22px;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">Climate
conscious
delivery</span>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
We
fund
global
environmental
projects
to
offset
the
carbon
footprint
of
all
our
deliveries
and
returns.
Get
more
info
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DCWYSSYCY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.&amp;_di_=kndoc1780k4nqr5gkbsji30hcrs9vlt7s6vga2po31vtq7jhq9f0"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DCWYSSYCY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xBIx0zoKs6lukMd_AvmZBszhch3ce2_kwz_EHiy5AayOy4RaH112DiTi0_HWeFv9EVl_3RSL3HvUYJfMgowuevJfpKQd43eGD5LrLxKg3kJg58og-gw.%26_di_%3Dkndoc1780k4nqr5gkbsji30hcrs9vlt7s6vga2po31vtq7jhq9f0&amp;source=gmail&amp;ust=1692880167800000&amp;usg=AOvVaw19ObzVMCD_5q5ZAJ9Q67_d">here</a>.
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h3
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:19px;line-height:26px">
Your
Order
Summary
</h3>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:25%;border-collapse:collapse;padding:24px 8px 24px 0"
align="left"
valign="top"
width="25%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DTUTWDCRY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAdhcy_tnd9bfPbaMOvfj-nP2dEfh0-Ga_wbtMUQbgWLcLPgJEyDS6XPIjwXcXadNrKRDYgDaHufa1_BlU37-kiiCt35LzIBusQC4yHaxi6A1ekzm9Embz-xh7jpmEtKQGSHpsCl1fGYqrf5VJy2BmzPeUcyZg.&amp;_di_=5q8bhh2n19o2if6im6svor8j89hnpgtfful26pogk738ij27fh00"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DTUTWDCRY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAdhcy_tnd9bfPbaMOvfj-nP2dEfh0-Ga_wbtMUQbgWLcLPgJEyDS6XPIjwXcXadNrKRDYgDaHufa1_BlU37-kiiCt35LzIBusQC4yHaxi6A1ekzm9Embz-xh7jpmEtKQGSHpsCl1fGYqrf5VJy2BmzPeUcyZg.%26_di_%3D5q8bhh2n19o2if6im6svor8j89hnpgtfful26pogk738ij27fh00&amp;source=gmail&amp;ust=1692880167800000&amp;usg=AOvVaw2PNZXi13nc7LaELN9l7Pkx">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src=${form?.image_link}
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</a>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:75%;border-collapse:collapse;padding:24px 0 24px 8px"
align="left"
valign="top"
width="75%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table;margin-bottom:12px"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Delivery
between
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.estimated_delivery_from}</span>
and
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.estimated_delivery_to}</span>
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Shipping
from
${form?.shipped_from}
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">
${form?.brand}
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:66.66667%;border-collapse:collapse;padding:0 8px 0 0"
align="left"
valign="top"
width="66.66667%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
${form?.item}
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:33.33333%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="top"
width="33.33333%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right">
${form?.subtotal}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 8px 0 0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:24px">
Sub-total
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
Shipping
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
Taxes
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
Credit
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Promotions
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:24px">
${form?.subtotal}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
${form?.shipping}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
${form?.taxes}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
-
${form?.credit}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right">
-
${form?.promotions}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272;margin-top:24px">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 8px 0 0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left;margin-bottom:12px;margin-top:24px">
Total
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:24px">
Payment
method
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:right;margin-bottom:12px;margin-top:24px">
${form?.total}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:24px">
PayPalExp
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272;margin-top:24px">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left"
valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 48px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h2
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:24px;line-height:30px;text-align:center">
Loved
that?
<br
style="display:none;overflow:hidden;max-height:0;width:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:24px;line-height:30px">Why
not
try
these?
</h2>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;text-align:center;width:25%;border-collapse:collapse;padding:24px 0 0 0"
align="center"
valign="top"
width="25%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DCWTWTBAY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAcGfq9OB3oJ_zIIExb-ibZkI-Ta7caurqgfbwAAeTtAIPtHT7S_es7QuiUdJwpFdVQrH7YSq9fO3zlupVTRi6ylVwNdbIlVAdAiCBjce95xuaTZqr1KN48pCq9CRmHJTsLW7yTD2eHQWRBUWPzOpT1lF_tL9WRrtu5jQPWyQVR0CSO4e7rwVEeufyuH3Bxa8XoQ2hU1tcgYat5R-Pz8-M5LAKNODogja1NfyHZQ0EmjHoQ39HvkYH8Rym3YCDLi_P8G7odnHLdgyXr6tRWn59K9tf2vAGkne_jT0gl53xzaLSNO5DW5sSuzH7cyjlLFN5dyHjVbJh2b6ael7VUDldSBk7d2ghtwdKdT3Arua-9s-nRIqondDcxbaqT15mUKmJ4NSezLyeXZpqibkg8rfnZdtrLch5Vac3KCmjFJ1jp77zl612sx7jLg4ADW7n7DQwI0oqEQCSOoug0Y28C9H6MJaY0fiLL17n6AFQL5FPG_qUXOGYu1h6daNnpRFDMW_4hhfX2YM8ockEKKAtXSQP9jfwlgAW4RS1GNWTwN-41VkTPgpIkUduWEuGuhtU-JI3TvxcxLhdZfBlsEJxNSTFX393RgTK4hMdQRojx_DdcrEWPtaa665G6UmJE9mqEl0gJy6P2HOUTBVhcfpgWDHkTV10dGtgnD8SBzKGC_0-HdTgukfQua14clC4vlo16-vd-vDCHAk5bgbHdhUGSD9EWdpI21BvpjpngoEqWvs5bG6cNj8GUYjJJU.&amp;_di_=f1fa2fdudek4suaouj8ebrf9pqoms9j3ttgm9s62ri5ofjlbejk0"
align="center"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DCWTWTBAY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAcGfq9OB3oJ_zIIExb-ibZkI-Ta7caurqgfbwAAeTtAIPtHT7S_es7QuiUdJwpFdVQrH7YSq9fO3zlupVTRi6ylVwNdbIlVAdAiCBjce95xuaTZqr1KN48pCq9CRmHJTsLW7yTD2eHQWRBUWPzOpT1lF_tL9WRrtu5jQPWyQVR0CSO4e7rwVEeufyuH3Bxa8XoQ2hU1tcgYat5R-Pz8-M5LAKNODogja1NfyHZQ0EmjHoQ39HvkYH8Rym3YCDLi_P8G7odnHLdgyXr6tRWn59K9tf2vAGkne_jT0gl53xzaLSNO5DW5sSuzH7cyjlLFN5dyHjVbJh2b6ael7VUDldSBk7d2ghtwdKdT3Arua-9s-nRIqondDcxbaqT15mUKmJ4NSezLyeXZpqibkg8rfnZdtrLch5Vac3KCmjFJ1jp77zl612sx7jLg4ADW7n7DQwI0oqEQCSOoug0Y28C9H6MJaY0fiLL17n6AFQL5FPG_qUXOGYu1h6daNnpRFDMW_4hhfX2YM8ockEKKAtXSQP9jfwlgAW4RS1GNWTwN-41VkTPgpIkUduWEuGuhtU-JI3TvxcxLhdZfBlsEJxNSTFX393RgTK4hMdQRojx_DdcrEWPtaa665G6UmJE9mqEl0gJy6P2HOUTBVhcfpgWDHkTV10dGtgnD8SBzKGC_0-HdTgukfQua14clC4vlo16-vd-vDCHAk5bgbHdhUGSD9EWdpI21BvpjpngoEqWvs5bG6cNj8GUYjJJU.%26_di_%3Df1fa2fdudek4suaouj8ebrf9pqoms9j3ttgm9s62ri5ofjlbejk0&amp;source=gmail&amp;ust=1692880167800000&amp;usg=AOvVaw30Sp1Ds47byBk7-pbf-Kgo">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center;padding-bottom:24px"
src="https://ci4.googleusercontent.com/proxy/m9hacfmhFlU3tFH1zYeffvdsKg0hnqDXpGg-Z17VcESr1-nOlX6jetS3mLx25j9O5pznhn2NWozgi7xkUYnaZ0L-OC9A1uy7tCvlPUFu9p0jPq4BQ-rPDaW7Tjdt7sT-hjL6NBCfJxRDu290LPsXnQ6trqdq2TxtTdfdFAjfj6bGDkr4azkkAfHyAdHtUrPWaLiGHGZQRn23CfHCi9XFiFwnHbZxRJXQGOl1C2Y9TXwAejLOdw3U6Ox2XsQIjXZKVKPGflcnHXUN3oFBlWV5j6SGsI9ONbX_IW1OVxwx4KqniaGyT2YyQEWTKIRHX3HLX3YaMKjLhYrJd6VKLor11lo1vZAWeM8TaevFrVM59P4RG_xDdALIpC2dwYuCKIaeajSMl3J4kigaWRA_CSXh8pPDhyRh50OQKF3ALcZnMKYhG1QFgBwy9KJE53iuasNtZIS0oCHEhRgPsWVQa2BBjl1KUJx1vVMsg6qnOV6WlvnBwiYgc1m-oITNqNw8kQjBQ9O-o9IaaJZ090zV3VDQaVxdhrlQ6HrS46ptaoyqACHpbSAS62gEQ0Q3iVxR9PswyGkvQ0w68xqUuGLIVeM8UH9SyUSTJ4IYuLT2T9kyLnmn23RigjQKvsLL=s0-d-e1-ft#https://service-ofr.farfetch.net/v1/10000/products/4c7e8c40160b017a42b9e39876b69e2c574db4963dbdd6dbf815767c98d0449a/cdn/0?campaignName=THANK_YOU_FOR_PLACING_YOUR_ORDER&amp;clientName=Responsys_op&amp;dateTime=2021-12-02T13:15:05Z&amp;strategyName=email_op_orderconfirmation_a&amp;userIdentifier=20341a70e15bc537c660177fafdfa29a882b8856c03a020afbc0dc775f0b7540&amp;userType=emailHash&amp;countryCode=SK&amp;ProductId=15571881&amp;ffref=pp_recom&amp;rtype=inspire_email_op_orderconfirmation_a"
alt=""
width="82"
height="110"
border="0"
class="CToWUd"
data-bit="iit">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src="https://ci3.googleusercontent.com/proxy/6ye-uDQsymlRfYOnHGNp5wHl-vtzcdqViWmGCo0bMBHsbDjVcCOjonghjAoju-7hTMzWAeFRkGuImvax1lctVzznlkgssJDq03C9h7JuxJxhggFgYLcIs--_wgQiBbK8Hw4TMptbaTrlmeStwiSacxGMnnckWw3MM6J4eeE6ToabMQeBYgEJjCEw9rtO7-fZQ0B-KvurOqZhSgfj5pn_d8gpA7ddIYwcFnCgLmJHaeXh9pzrrsBBYbhArjS1JhWZeFIS9nuUVeEUdV1qIYJfbulzhWjeVYiOq-heQnowSD-o6Uax-gBvmA_yDS02BgJ4YB8VhdoxlzR6KCmQix87l9yAnhH9FARXPZ3hg4o6v64eUHC2IL2IyGpBd5JG1YN64KR-FWkebZYLj_EoFS_K8VksBuL4dQZhnM9kBFOgM3CmYkvi-ksiLHB4KXolrqQLHMABu-Wlio4mOUKOqv5aajWNRSya1vBSNywHiR36eau1JETJb7J6_F9Z5nxzFBlwAAxs2U8XDzwkNV-5THkraBV72L7IHRcT4QKElytxHik_mGid--7r1cSIRqe6CVDv4u5sDQ0glJSQ7cwx3lsn9Ia1xLqEnUX2dtPjYHYRSllkLbbkhvFW4TejoNk=s0-d-e1-ft#https://service-ofr.farfetch.net/v1/10000/products/4c7e8c40160b017a42b9e39876b69e2c574db4963dbdd6dbf815767c98d0449a/brand/0?campaignName=THANK_YOU_FOR_PLACING_YOUR_ORDER&amp;clientName=Responsys_op&amp;dateTime=2021-12-02T13:15:05Z&amp;strategyName=email_op_orderconfirmation_a&amp;userIdentifier=20341a70e15bc537c660177fafdfa29a882b8856c03a020afbc0dc775f0b7540&amp;userType=emailHash&amp;countryCode=SK&amp;ProductId=15571881&amp;ffref=pp_recom&amp;rtype=inspire_email_op_orderconfirmation_a"
alt=""
width="136"
height="14"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;text-align:center;width:25%;border-collapse:collapse;padding:24px 0 0 0"
align="center"
valign="top"
width="25%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%3DCWTWTBAY&amp;_ei_=Eq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAcGfq9OB3oJ_zIIExb-ibZkI-Ta7caurqgfbwAAeTtAIPtHT7S_es7QuiUdJwpFdVQrH7YSq9fO3zlupVTRi6ylVwNdbIlVAdAiCBjce95xuaTZqr1KN48pCq9CRmHJTsLW7yTD2eHQWRBUWPzOpT1ly7gCRG-1hiGV4BCXsdrCxUsZowfgCCAxQYWvl5XDy15rzEFTUu_7Q44EENAByZ9K7LMXxxe9Y_Vmnm9LURuIPKlL_UHYsliL85uBtLSuZWJMNMttJpSqGBJKgmeRVcupVFqR_L6HTagTeo2SeiPr2CTkxtilBqp8_0IG2jWnLWh6EQBW5q5hEysAdgOg1t1yf91R_4fPwhT4XYNbJ9o_9FK50ncp3n-jW5pKCJP03AE2m9oGMAQ6_MI51oD80PGcrxvsy4hqqvY7DGWktaJhBViKvyne6Ts_Z_zhl8g8K2rgCuOBowTvPn2NNMW2tYOsUwwlM_WYg38XbkH1PH1eJMPXXoflBXEgBAorF8TlFt3U5Duj54IqJdCFoBcc1FgAZ4sU-EFKjPgBrCqXS4ySBsb_kVHxRaA0nOI_QSDrBbzR86eGmpCC4p2CBDd3602uQ4-5EOdjBwGMasct5Nkv_h2EnzWtYoRh5RH-qN20V7p5ueMeHbQmoGfrFHIA0r8LbG_nrAvClohIGpb7ykLWrGbf08GwrwcIh0CX7-yBtLrss8oQ8KJzjsXXZ81lG5asw-iW-wbEaEhKW1upduAaVVu82ylgwUcT.&amp;_di_=82d9o9c1ufrqdb8h6k96vlvve0dpcr3d1ilhk8bomr26p8u6g9ig"
align="center"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGseo8O8Rzcqudh3df5d4uoWLIzcNrlOCb31o45MeKY1vzezczah4dghOCVXtpKX%253DCWTWTBAY%26_ei_%3DEq2tf9zs59idfPO1Sc_9BbkBGF5RVXKyae5d6QrbL58xhSxMU5-B1e6qFa1CGkXn1Bf9j1YXUE4mvk4nieCMPAcGfq9OB3oJ_zIIExb-ibZkI-Ta7caurqgfbwAAeTtAIPtHT7S_es7QuiUdJwpFdVQrH7YSq9fO3zlupVTRi6ylVwNdbIlVAdAiCBjce95xuaTZqr1KN48pCq9CRmHJTsLW7yTD2eHQWRBUWPzOpT1ly7gCRG-1hiGV4BCXsdrCxUsZowfgCCAxQYWvl5XDy15rzEFTUu_7Q44EENAByZ9K7LMXxxe9Y_Vmnm9LURuIPKlL_UHYsliL85uBtLSuZWJMNMttJpSqGBJKgmeRVcupVFqR_L6HTagTeo2SeiPr2CTkxtilBqp8_0IG2jWnLWh6EQBW5q5hEysAdgOg1t1yf91R_4fPwhT4XYNbJ9o_9FK50ncp3n-jW5pKCJP03AE2m9oGMAQ6_MI51oD80PGcrxvsy4hqqvY7DGWktaJhBViKvyne6Ts_Z_zhl8g8K2rgCuOBowTvPn2NNMW2tYOsUwwlM_WYg38XbkH1PH1eJMPXXoflBXEgBAorF8TlFt3U5Duj54IqJdCFoBcc1FgAZ4sU-EFKjPgBrCqXS4ySBsb_kVHxRaA0nOI_QSDrBbzR86eGmpCC4p2CBDd3602uQ4-5EOdjBwGMasct5Nkv_h2EnzWtYoRh5RH-qN20V7p5ueMeHbQmoGfrFHIA0r8LbG_nrAvClohIGpb7ykLWrGbf08GwrwcIh0CX7-yBtLrss8oQ8KJzjsXXZ81lG5asw-iW-wbEaEhKW1upduAaVVu82ylgwUcT.%26_di_%3D82d9o9c1ufrqdb8h6k96vlvve0dpcr3d1ilhk8bomr26p8u6g9ig&amp;source=gmail&amp;ust=1692880167801000&amp;usg=AOvVaw2HKAQ7yh06DnNFyypFxd0z"></a>
</center>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
</div>
<div class="iX">...<br><br>[Message clipped]&nbsp;&nbsp;<span class="jb">Entire message not available
offline</span></div>
</div>
<div class="yj6qo"></div>
<div class="yj6qo"></div>
</div>
<div id=":ov" class="ii gt" style="display:none">
<div id=":ou" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};

export const farfetchGerEmail = (form: any) => {
return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":q3" tabindex="-1"></div>
<div id=":ps" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyMzExOTgzMjgzMjQ5NSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyMzExOTgzMjgzMjQ5NSIsbnVsbCxbXV0.">
<div id=":pr" class="a3s aiL ">
<div class="adM"> </div>
<div>
<div class="adM">
</div><u></u>
<div
style="min-width:100%;padding:0;box-sizing:border-box;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:100%">
<table
style="border-spacing:0;vertical-align:top;height:100%;width:100%;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
border="0" width="100%" cellspacing="0" cellpadding="0" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0" align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;float:none;text-align:center;border-collapse:collapse;padding:0"
align="center" valign="top">
<center style="width:100%;min-width:576px">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:35px 16px 35px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<div style="display:none">
SIE HABEN SICH RICHTIG
ENTSCHIEDEN
<span
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ<wbr>ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ</span>
</div>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;height:150px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%"
height="150">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DYABWWAY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.&amp;_di_=qa8l2g4oh8dntgev58mmh9h52um38a6mb1kfggd94aaml73ni180"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DYABWWAY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.%26_di_%3Dqa8l2g4oh8dntgev58mmh9h52um38a6mb1kfggd94aaml73ni180&amp;source=gmail&amp;ust=1692880363376000&amp;usg=AOvVaw0nBlJVWEoGddxYLc_7f0WB">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src="https://ci3.googleusercontent.com/proxy/Z0vZbMGnkEUuL_2fwMHv2GJ5WbcORY3QDqvJHyXSFd4brjO8HRMCyl5cd5Pf9_1IovbRgk5n7OpJeO4k3Y-lKGLgadqz0HMwj53Lr70aEm_kG8-KKCWwtzSy7i474rLUSCsc1g5YxXibaY0GZxwU85C1Zbl8hC4P7XBQR0nnfadIoKDQjIEeI4iCKQ4RzG-JApGBfEN9BovldlAIukp5FLcl9X2C759EXyHDSD9gzbjvxEE=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_default@4x.png"
alt="farfetch logo"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</a>
<div
style="display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;border:none;margin:0 auto;float:none;text-align:center;display:none"
src="https://ci5.googleusercontent.com/proxy/6z5c-QH7a3fJ5nmuR6sK1-EclhXnsgVH8cph_hCNwJjmtglCechBAtAvUMcOtBdIRcD4FLBvkXXBaed_lRH0B_cw8X-i7den5M1rwlH7bXnppMBgReKRMGtfMoXrfu_MyVKbBGjtaQc1x1n57PA-NKGqQ3aH57rprY00jqfaoNy0THMJ9xXa-LtZUTWXOYg9dEUWXuxKMMlpdDiAsY8MtRAf2ISZc31qd2-u7C3UG8Q=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_dark@4x.png"
alt="farfetch logo"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</div>
<div
style="display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;border:none;margin:0 auto;float:none;text-align:center;display:none"
src="https://ci5.googleusercontent.com/proxy/g1dd1YBbPmcl2gSyaiRJjB_ZNDS3n0zbASzxIxFlacwYjxIibUqygJfce5LTmfA9bxDTjTWfs4bZAwLSK4GrTr8Ij69I9VICoI7kdd0Y4L9m8xbCjY_SBVbt2-f8lsrS0KDe2KaK5XZW0m6G02_GqJUJ7ee2yeQlYWq2WrUyh32P9RGV0vmQzu0lnG4fUTa8MrV5IkpxzObqhV2yK_SL67Frqo5ZCN5IM5hVXQp4fp4P=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_header/farfetch_logo_global_light@4x.png"
alt="farfetch logo"
width="286"
height="80"
align="center"
class="CToWUd"
data-bit="iit">
</div>
</center>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:48px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h1
style="margin:0;font-family:'NimbusSansExtD-Bold','Helvetica Neue Bold','Arial Bold',sans-serif;font-weight:bold;font-size:26px;line-height:26px;text-transform:uppercase;text-align:center">
SIE
HABEN
SICH
RICHTIG
ENTSCHIEDEN
</h1>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:24px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:center;direction:ltr">
Bestellnummer:
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.order_number}</span>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:12px 0 0 0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:center">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DYABWWCY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.&amp;_di_=ccb96tqphumbbuhkchr80lbg1u6jmoe9sb57s9tujoa8h90t684g"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DYABWWCY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.%26_di_%3Dccb96tqphumbbuhkchr80lbg1u6jmoe9sb57s9tujoa8h90t684g&amp;source=gmail&amp;ust=1692880363377000&amp;usg=AOvVaw30MqMZOieLOmoSA64e1dNA">Konto
ansehen</a>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Liebe/r
${form?.full_name},
</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
vielen Dank für Ihren
Einkauf bei FARFETCH!
Wir haben Ihre
Bestellung erhalten und
werden diese innerhalb
von 2 Werktagen
bearbeiten.</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Sobald wir Ihr Paket
verschickt haben,
schicken wir Ihnen eine
E-Mail mit Ihrer
Trackingnummer. Bei
Fragen zu Bestellungen
mit F90-Versand oder
Zustellung am selben Tag
wenden Sie sich bitte an
unseren Kundenservice.
</p>
<br>
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">
Sie haben mehrere Pieces
bestellt?</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Wir bestätigen den
Versand jedes Ihrer
Pieces einzeln per
E-Mail. Es kann sei,
dass Sie mehr als ein
Paket bekommen.</p>
<br>
<p
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px">
Wir wünschen Ihnen viel
Spaß mit Ihrem Einkauf!
</p>
<br>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
FARFETCH</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<h3
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:19px;line-height:26px;margin-bottom:24px">
Ihre
Versandinformationen
</h3>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
${form?.full_name}
<br>${form?.street}
<br>${form?.city}
<br>${form?.zip}
<br>${form?.country}

<br>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left" valign="top">
&nbsp;</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:24px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0 0 6px 0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci6.googleusercontent.com/proxy/jE1HbBMBjNsjb2oClYxm4CUZfBCvZ32D_z9YZd7DPRl4YpsnZKmgU_Lo5BdIhrVd4jJsxlnmXddSh39D93D_lKGU7Wt8nTeG5-OqFEin4SV2J5N4AgMRu3o8pVpFtoXqMty0OxKZ9sYJXL-DO9Ht5x83rTuwtWoD7k3sTSx1D-gRbfyxt6dWyT8EkeiWZcxP71ecvWAmv9WSIevDSRpZWIl8n9w=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconVanLight@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
<span
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci3.googleusercontent.com/proxy/t_21O2vFuq1pplId5OkOBslxKXTUgEwfWmAMmMTB2vdKh1ghKj6HbErmwurZV93BzaZ-0s1oKeFKnEfVNoVQiQVlF7EnIhViFtB5VabebTcfREUhjcU5Yi9sJZOYCZ4RqHpCIIE4yOG7G05UK5npMHJX85tri7mq8AeaKchiLbvFqDF8UwAZ4AEk5iPUt8TCIqVht2vfmGZaWCh4BCa14bPkEg=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconVanDark@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
</span>
<span
style="margin:0;font-size:16px;line-height:22px;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">Wir
sind
für
Sie
da</span>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Ihr
Paket
wird
sicher
zugestellt&nbsp;&nbsp;
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DCWYRUBAY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.&amp;_di_=1tact3keofbteu5ekb35hcphv0k7vhbor2o0lql64ljhvkt5fi6g"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DCWYRUBAY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.%26_di_%3D1tact3keofbteu5ekb35hcphv0k7vhbor2o0lql64ljhvkt5fi6g&amp;source=gmail&amp;ust=1692880363377000&amp;usg=AOvVaw1Y6Wm34OKQ8NXHPMaYW2Vs">Mehr
Info</a>
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:24px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0 0 6px 0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci5.googleusercontent.com/proxy/bbW33nqM8uJ4uB71z2771WylpukVSXIGCpi0hkvQ0kPu1srSJsXbTzZ0Q4kIypFRCReY6j94w-c66JnA7bk6qKD7MH9k3D4fTx4GPLESBXLKezKZ2fPhU7VN0eHjy6JapvI0ntKOaqOtkGd-62rH2J9n93iHSkFcTb0pss3v6ODdvvEz5607m-QgvPWCoo34UIxvgoChVoWqjXkrR5gvMKjPdW1ohUW7R4hBRsAE1o0=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconClimateConciousLight@4x.png"
alt="Positively Farfetch environment leaf icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
<span
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;display:none">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;float:left;text-align:left;margin-right:6px"
src="https://ci4.googleusercontent.com/proxy/fksJQd_miDol0waIGXS6l6FOPNl_KhMKgxx_mUYhVMxgWUzl8mLMBM6iZWpHSssqpWB4E7kALXxR9HlcCoSQURyh-V25GD1NjX1HahjoLb2b_to3YgRoE8n7MR-5Ue28phnCPqvgM0EXcpJCmhZMQbvPmdSDinq3DGtV8RR-CssSiNqfIjDDsQckjt09SaBp_0tekZF_V5qY51mLIlKPRzJrgPvQ5Uw_SNx7Zi7qQA=s0-d-e1-ft#https://static.cdn.responsys.net/i5/responsysimages/farfetch/contentlibrary/ff_transactional_emails/resources/images_banners/IconClimateConciousDark@4x.png"
alt="Delivery truck icon"
width="20"
height="20"
border="0"
class="CToWUd"
data-bit="iit">
</span>
<span
style="margin:0;font-size:16px;line-height:22px;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">Klimaneutraler
Versand</span>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Wir
finanzieren
globale
Umweltschutzprojekte
und
kompensieren
so
die
CO-Emissionen
bei
jeder
Bestellung
und
Rücksendung.
Weitere
Infos
finden
Sie
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DCWYSSYCY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.&amp;_di_=0li0guq4a1d1th9ngb3sack9iheo70kl25sbkrl0kf5irdpqfh20"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DCWYSSYCY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWwGV7tlS4sDau92GG1VLctJxnVkXPOUJjm5EGd0pd6xYrtlk.%26_di_%3D0li0guq4a1d1th9ngb3sack9iheo70kl25sbkrl0kf5irdpqfh20&amp;source=gmail&amp;ust=1692880363378000&amp;usg=AOvVaw2kyYpZ39QjHVyMdC8rUahK">hier</a>.
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 24px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h3
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:19px;line-height:26px">
Zusammenfassung
Ihrer
Bestellung
</h3>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:33.333333%;border-collapse:collapse;padding:24px 8px 0 0"
align="left"
valign="top"
width="33.333333%">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DTUTWDCRY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWWEoSXKNwmi8lMj1G3_nrNlqbAYmfnDvIOS4UqhYdJYZ56HRLC0ZV0WehVjXyOKEvPqnS8xQbAgJ9peh6A_yYpd8N0Ck2ssWT4Jm4bwgrWR1KV8f4wz6o6BlRwEKWnKIZPPc.&amp;_di_=oqrp0u5o2p2a3mt63gfqq84r29dqfkoucmghn67u92kcu96e607g"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DTUTWDCRY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWWEoSXKNwmi8lMj1G3_nrNlqbAYmfnDvIOS4UqhYdJYZ56HRLC0ZV0WehVjXyOKEvPqnS8xQbAgJ9peh6A_yYpd8N0Ck2ssWT4Jm4bwgrWR1KV8f4wz6o6BlRwEKWnKIZPPc.%26_di_%3Doqrp0u5o2p2a3mt63gfqq84r29dqfkoucmghn67u92kcu96e607g&amp;source=gmail&amp;ust=1692880363378000&amp;usg=AOvVaw0pugIyIRUEgTmBmILqdZdo">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src=${form?.image_link}
width="92"
height="110"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</a>
</th>
<th style="word-wrap:break-word;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;vertical-align:bottom;width:58.333333%;border-collapse:collapse;padding:24px 8px 0 8px"
align="left"
valign="bottom"
width="58.333333%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table;margin-bottom:12px"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Zustellung
zwischen
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.estimated_delivery_from}</span>
und
<span
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">${form?.estimated_delivery_to}</span>
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Verschickt
aus
${form?.shipped_from}
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left">
${form?.brand}
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
${form?.item}
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
</p>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;vertical-align:bottom;width:100%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="bottom"
width="100%">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;white-space:nowrap">
${form?.subtotal}
</p>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272;margin-top:24px">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 8px 0 0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:24px">
Zwischensumme
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
Versand
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
MwSt
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:12px">
Gutschrift
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0">
Promotions
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:24px">
${form?.subtotal}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
${form?.shipping}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
${form?.taxes}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:12px">
-
${form?.credit}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right">
-
${form?.promotions}
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272;margin-top:24px">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 8px 0 0"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:left;margin-bottom:12px;margin-top:24px">
Gesamt
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;margin-bottom:24px">
Zahlungsart
</p>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:50%;border-collapse:collapse;padding:0 0 0 8px"
align="left"
valign="top"
width="50%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<p
style="font-size:16px;line-height:22px;margin:0;font-family:'FarfetchBasis-Bold','Helvetica Neue',Arial,sans-serif;font-weight:bold;text-align:right;margin-bottom:12px;margin-top:24px">
${form?.total}
</p>
<p
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0;text-align:right;margin-bottom:24px">
CreditCard
</p>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:0 16px 0 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<hr
style="border:0;padding:0;margin:0;border-top:1px solid #727272;color:#727272;background:#727272;margin-top:24px">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;width:576px;margin:0 auto;float:none;text-align:center;padding:0"
width="576" align="center">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<td style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:560px;border-collapse:collapse;padding:48px 16px 48px 16px"
align="left" valign="top" width="560">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%" align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left" valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left" valign="top">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0 auto;width:100%;border-collapse:collapse;padding:0"
align="left"
valign="top"
width="100%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<h2
style="margin:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:24px;line-height:30px;text-align:center">
Total
Ihr
Style?
<br
style="display:none;overflow:hidden;max-height:0;width:0;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:24px;line-height:30px">Kennen
Sie
diese
Teile
schon?
</h2>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;width:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
&nbsp;
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;padding:0;width:100%;display:table"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;text-align:center;width:25%;border-collapse:collapse;padding:24px 0 0 0"
align="center"
valign="top"
width="25%">
<table
style="border-spacing:0;border-collapse:collapse;vertical-align:top;text-align:left;width:100%;padding:0"
width="100%"
align="left">
<tbody>
<tr style="vertical-align:top;text-align:left;padding:0"
align="left"
valign="top">
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;border-collapse:collapse;padding:0"
align="left"
valign="top">
<center
style="width:100%;min-width:none">
<a href="https://email.farfetch.com/pub/cc?_ri_=X0Gzc2X%3DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%3DCWTWTBAY&amp;_ei_=EW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWWEoSXKNwmi8lMj1G3_nrNlqbAYmfnDvIOS4UqhYdJY_JEhadDNg-zULQHTzID1bLg7aDbyNvKbgJYj3LassU2pKZsXDPryX27K9iR-awwimkvoKsoHHc2m0hm19MqzNZ5Xdq3X201C-usWhPwNLnQfhTWhfHNBKli2w39nCqJZmfEhVvbRwjD_7bohiG88s7mxrMwU2vqDi1z4Q5PL89uO2kkkU7gMFBy0QJkq4NGoHxLYN9cNiD9Z2tpmjNK19CTLqML-hRfGHnRh6E0jf1e6RkG4FK6cgxRGufJFRp-6qUz9OBUqYXhmAkhRrRFsKpGNjS8ZTvpUF0-d67Ti7dtI-v4FjgGcrTgstXpNe6t4pilrptxcmCaWHcbVtwVAXmG4OYV8mqMPAJVSHZ7lYAkEEdb4xy9CzIOX_2Kv_zDwpvCS6b33t--HsK5kV5c4OWS7zI1GI9rTQPJOKjjwp_n0REejKRb5ELG_pPrURAicSuRc-7jfZq0ho8vVAmi3ZZx73rpuX3o_Kish5x1pO4lLNMP44rH0mUCbWraDH3SJlU1aNzlHbgDDKvTY8mjDUkOrGc_O8N5YXpj4SPKTnpSoOWwfI66B9eaMWNSMxtlAcwL8mnMESO5FBgGYomx0eXPZKAEGxJkbXKVeO41igx8MF2R8deBbCC_OfflsaKjhGIhN8D8DeQ9LVZ_rIkRCiVV6uLS2d-23hOQAyIlmgNSkgRf22Oyg.&amp;_di_=hn9idgqbqr196t9vjqo87vqkue9lh77kuidva4gju68gfgkpsps0"
align="center"
style="font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;text-align:left;font-size:16px;line-height:22px;margin:0;color:#222222;text-decoration:underline;text-decoration-color:#222222"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://email.farfetch.com/pub/cc?_ri_%3DX0Gzc2X%253DAQpglLjHJlYQGzaeo8O8Rzcqudh3df5d4uoWMRzaGcGn2R5u3E1n1kCvRtIvyBYXPU3VXtpKX%253DCWTWTBAY%26_ei_%3DEW2tf9zs59idfPO1Sc_9Bbl3Z9mZFmFAu9v5BpQMjWYWWEoSXKNwmi8lMj1G3_nrNlqbAYmfnDvIOS4UqhYdJY_JEhadDNg-zULQHTzID1bLg7aDbyNvKbgJYj3LassU2pKZsXDPryX27K9iR-awwimkvoKsoHHc2m0hm19MqzNZ5Xdq3X201C-usWhPwNLnQfhTWhfHNBKli2w39nCqJZmfEhVvbRwjD_7bohiG88s7mxrMwU2vqDi1z4Q5PL89uO2kkkU7gMFBy0QJkq4NGoHxLYN9cNiD9Z2tpmjNK19CTLqML-hRfGHnRh6E0jf1e6RkG4FK6cgxRGufJFRp-6qUz9OBUqYXhmAkhRrRFsKpGNjS8ZTvpUF0-d67Ti7dtI-v4FjgGcrTgstXpNe6t4pilrptxcmCaWHcbVtwVAXmG4OYV8mqMPAJVSHZ7lYAkEEdb4xy9CzIOX_2Kv_zDwpvCS6b33t--HsK5kV5c4OWS7zI1GI9rTQPJOKjjwp_n0REejKRb5ELG_pPrURAicSuRc-7jfZq0ho8vVAmi3ZZx73rpuX3o_Kish5x1pO4lLNMP44rH0mUCbWraDH3SJlU1aNzlHbgDDKvTY8mjDUkOrGc_O8N5YXpj4SPKTnpSoOWwfI66B9eaMWNSMxtlAcwL8mnMESO5FBgGYomx0eXPZKAEGxJkbXKVeO41igx8MF2R8deBbCC_OfflsaKjhGIhN8D8DeQ9LVZ_rIkRCiVV6uLS2d-23hOQAyIlmgNSkgRf22Oyg.%26_di_%3Dhn9idgqbqr196t9vjqo87vqkue9lh77kuidva4gju68gfgkpsps0&amp;source=gmail&amp;ust=1692880363378000&amp;usg=AOvVaw258Ey-kSg6_wIGwU6B8BW8">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center;padding-bottom:24px"
src="https://ci4.googleusercontent.com/proxy/igZjn5lOdbkftET9asJBgeTW7QYLY8xO4jfidNHpsV9DT7WP_sPqsFN1EU5JmAzEFQKO8FCcXPMFRZeZQC2slF0xGD1e-NkVoc-hPUQO0Rzbz018aSZOdpaEzZ7-KIbANB2dFT8MLkIZhkCTNtB1IZgmAfcixSYkNY5NZgdA2ht7QpOuyQED8YBonkHDxtG9j8KLi_8olBaeZQkw8dF8NZRFCA-2YVO4_6AEap9OdH5kwTnVU1CfsPBCa_D817MbRkbzYFZrHWeU5x12ZMf7co9K24mbsHxRDDlCmAHobkXqQaxYz2lvSj08HfGnTE9c51UOB24sW34GZLWVUkDQwZjd6zdlTnOpGBWDTmi5FmN0ZW3p8SJj6Icsdt4rIgtsioe-GVj0N9m4Ff-RWAWADojzYsijp9AON4V7Fa6glvPw5EkhprroYZqUNKh4x2BlvO-8CPu70jCCX0TNhvQV_b6zRYEEVZjdxeosl7rtQfoTK8tIvldRRfk19GDbLt7-Z2HjTyH-zJob5bYWSL6PQ9sbehwu9HwWgnuVYqyItZHzrrv3Pu7SDrf6yC8s1pZLVRM_ZUEVGjEXkPn5VYHZLsPtQ4TEDI-F-1VjrifIE4YDiJeu7PusRVrU=s0-d-e1-ft#https://service-ofr.farfetch.net/v1/10000/products/ba203d556c82d44b8bc286b2fd9f84a91455bd56de4f39c9bdf0897cab104537/cdn/0?campaignName=THANK_YOU_FOR_PLACING_YOUR_ORDER&amp;clientName=Responsys_op&amp;dateTime=2022-03-30T23:58:25Z&amp;strategyName=email_op_orderconfirmation_a&amp;userIdentifier=cefecabea35ca7c16c831ad885b38c2b4e26abaeaa9fbfb3523958c28592eac3&amp;userType=emailHash&amp;countryCode=DE&amp;ProductId=16115016&amp;ffref=pp_recom&amp;rtype=inspire_email_op_orderconfirmation_a"
alt=""
width="82"
height="110"
border="0"
class="CToWUd"
data-bit="iit">
<img style="outline:none;text-decoration:none;width:auto;max-width:100%;clear:both;display:block;border:none;margin:0 auto;float:none;text-align:center"
src="https://ci5.googleusercontent.com/proxy/KI3iv5QkjlfTKLqimVYZOaipDq_N7-6fe9llthhBgS9ysGNv3U_1z64Pm0pENDVJQLhRI7_yAkfLcosaa4OkdUAOiAV18gIuLC0Z9OC1X387FSbJn9_l_lAkmiK7F32eZc1FKIoJZQtV63V1ZwvF2ogAHDMhsACHVJVBUzpITtTSU98DE2G-WnPkZKgNyMj-VmvjOZQytyGCN_Gm354Me8yQhWeO4qajJXiiaepvNfut_jg5M_WOIJGJCmgubibMmSuzOlmsonl0KxD4WiLkNR20wZzj9Hy1joiT4fTfQhtq7979f6F7hacVK0H8wwwJqswWOxGKM6yRYWqOOboMmChPRDt6d7KU1xOgJ96_ScRCl5OX-t86N0Z_mKuRqyR9CeLyzSl8nThWGCksW7ZLyAouQPHY8RiAPkxK1GRbiCGZ1bJWeApeZS6G2momlyx1oObVjO4UeiQIIQCpT0KKtLU_Zcvbm08spV59kYSKVGmwZDzesjVNs8ZuIZ0RUmH3VYSs0-1xxNGtAyfGrdcrdChTQDDCTaRJxLsoeO6bGbvmF1ohA2IIaMz6ZMBDqAgChjgkMbyoBcbIASjuEkEFEUszQMIrwK9uiwp--qzu3AVbSg9yKfCq-He9S0s=s0-d-e1-ft#https://service-ofr.farfetch.net/v1/10000/products/ba203d556c82d44b8bc286b2fd9f84a91455bd56de4f39c9bdf0897cab104537/brand/0?campaignName=THANK_YOU_FOR_PLACING_YOUR_ORDER&amp;clientName=Responsys_op&amp;dateTime=2022-03-30T23:58:25Z&amp;strategyName=email_op_orderconfirmation_a&amp;userIdentifier=cefecabea35ca7c16c831ad885b38c2b4e26abaeaa9fbfb3523958c28592eac3&amp;userType=emailHash&amp;countryCode=DE&amp;ProductId=16115016&amp;ffref=pp_recom&amp;rtype=inspire_email_op_orderconfirmation_a"
alt=""
width="136"
height="14"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</center>
</th>
</tr>
</tbody>
</table>
</th>
<th style="word-wrap:break-word;vertical-align:top;font-family:'FarfetchBasis-Regular','Helvetica Neue',Arial,sans-serif;font-weight:400;font-size:16px;line-height:22px;margin:0 auto;text-align:center;width:25%;border-collapse:collapse;padding:24px 0 0 0"
align="center"
valign="top"
width="25%">
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<div class="iX">...<br><br>[Message clipped]&nbsp;&nbsp;<a
href="https://mail.google.com/mail/u/2?ui=2&amp;ik=a306d55d85&amp;view=lg&amp;permmsgid=msg-f:1775023119832832495"
target="_blank">View entire message</a></div>
</div>
<div class="yj6qo"></div>
<div class="yj6qo"></div>
</div>
<div id=":q7" class="ii gt" style="display:none">
<div id=":q8" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
