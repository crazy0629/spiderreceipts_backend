export const trapstarEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":ne" tabindex="-1"></div>
<div id=":ml" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzNDUyMjMxNTU3NTkzMyIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzNDUyMjMxNTU3NTkzMyIsbnVsbCxbXV0.">
<div id=":mm" class="a3s aiL ">
<div class="adM">
<div>&nbsp;</div>
</div>
<div class="adM">

</div>
<div>
<div class="adM">
</div>
<table style="height:100%!important;width:100%!important;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="width:100%;border-spacing:0;border-collapse:collapse;margin:40px 0 20px">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<center>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<h1
style="font-weight:normal;font-size:30px;color:#333;margin:0">
<a href="http://trapstarlondon.com"
style="font-size:30px;color:#333;text-decoration:none"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://trapstarlondon.com&amp;source=gmail&amp;ust=1692891245222000&amp;usg=AOvVaw0twmaIvPP-ekRWXbycnUPo">
<img src="https://ci6.googleusercontent.com/proxy/COKk3ThCOnqmxmdvBy5OOVT0V8vQfaVmLcqECr4Jn0lgoDhhG8fGtNqAGY_jUEhht6Vq60rdhErDqBCZZHf8RDnwcGn9sKfKlJ54NGNifk61Anbu=s0-d-e1-ft#https://stefanbarretto92.files.wordpress.com/2012/11/trapstar.png"
alt="" width="199"
height="63"
class="CToWUd"
data-bit="iit">
</a>
</h1>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;text-transform:uppercase;font-size:14px;color:#999"
align="right">
<span
style="font-size:16px">Order
#TS${form?.order_number}</span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<table style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding-bottom:40px;border-width:0">
<center>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<h2
style="font-weight:normal;font-size:24px;margin:0 0 10px">
Thank you for your purchase!</h2>
<p
style="color:#777;line-height:150%;font-size:16px;margin:0">
Hi ${form?.full_name}, we're getting your order ready to be shipped. We will notify you when it has been sent.
</p>
<table
style="width:100%;border-spacing:0;border-collapse:collapse;margin-top:20px">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;line-height:0em">
&nbsp;</td>
</tr>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="border-spacing:0px;border-collapse:collapse;float:left;margin-right:15px;height:61px">
<tbody>
<tr style="height:61px">
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,'Fira Sans','Droid Sans','Helvetica Neue',sans-serif;border-radius:4px;background-color:#000!important;height:61px;width:162.517px"
align="center"
bgcolor="#1990C6">
<a href="http://trapstarlondon.com"
style="font-size:16px;text-decoration:none;display:block;color:#fff;background-color:#000!important"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://trapstarlondon.com&amp;source=gmail&amp;ust=1692891245223000&amp;usg=AOvVaw2tCfVOjEz6Zyyy-81uHwtl">View
your
order</a>
</td>
</tr>
</tbody>
</table>
<table
style="border-spacing:0;border-collapse:collapse;margin-top:19px">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
or
<a href="http://trapstarlondon.com"
style="font-size:16px;text-decoration:none;color:#000000"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://trapstarlondon.com&amp;source=gmail&amp;ust=1692891245223000&amp;usg=AOvVaw2tCfVOjEz6Zyyy-81uHwtl">Visit
our
store</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<table style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:40px 0">
<center>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<h3
style="font-weight:normal;font-size:20px;margin:0 0 25px">
Order summary</h3>
</td>
</tr>
</tbody>
</table>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr style="width:100%">
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<img style="margin-right:15px;border-radius:8px;border:1px solid #e5e5e5"
src=${form?.image_link}
width="60"
height="60"
align="left"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;width:100%">
<span
style="font-size:16px;font-weight:600;line-height:1.4;color:#555">${form?.item}&nbsp;×&nbsp;1</span>
<br>
<span
style="font-size:14px;color:#999">${form?.size}
/
${form?.color}</span>
<br>
</td>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;white-space:nowrap">
<p style="color:#555;line-height:150%;font-size:16px;font-weight:600;margin:0 0 0 15px"
align="right">
${form?.subtotal}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="width:100%;border-spacing:0;border-collapse:collapse;margin-top:15px;border-top-width:1px;border-top-color:#e5e5e5;border-top-style:solid">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,'Fira Sans','Droid Sans','Helvetica Neue',sans-serif;width:1.79211%">
&nbsp;</td>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,'Fira Sans','Droid Sans','Helvetica Neue',sans-serif;width:98.2437%">
<table
style="width:100%;border-spacing:0;border-collapse:collapse;margin-top:20px">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0">
<p
style="color:#777;line-height:1.2em;font-size:16px;margin:0">
<span
style="font-size:16px">Subtotal</span>
</p>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0"
align="right">
<strong
style="font-size:16px;color:#555">${form?.subtotal}</strong>
</td>
</tr>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0">
<p
style="color:#777;line-height:1.2em;font-size:16px;margin:0">
<span
style="font-size:16px">Shipping</span>
</p>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0"
align="right">
<strong
style="font-size:16px;color:#555">${form?.shipping}</strong>
</td>
</tr>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0">
<p
style="color:#777;line-height:1.2em;font-size:16px;margin:0">
<span
style="font-size:16px">GB
VAT</span>
</p>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:5px 0"
align="right">
<strong
style="font-size:16px;color:#555">${form?.taxes}</strong>
</td>
</tr>
</tbody>
</table>
<table
style="width:100%;border-spacing:0;border-collapse:collapse;margin-top:20px;border-top-width:2px;border-top-color:#e5e5e5;border-top-style:solid">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:20px 0 0">
<p
style="color:#777;line-height:1.2em;font-size:16px;margin:0">
<span
style="font-size:16px">Total</span>
</p>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:20px 0 0"
align="right">
<strong
style="font-size:24px;color:#555">${form?.total}</strong>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<table style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:40px 0">
<center>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<h3
style="font-weight:normal;font-size:20px;margin:0 0 25px">
Customer information</h3>
</td>
</tr>
</tbody>
</table>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<table
style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding-bottom:40px;width:50%"
valign="top">
<h4
style="font-weight:500;font-size:16px;color:#555;margin:0 0 5px">
Shipping address</h4>
<p
style="color:#777;line-height:150%;font-size:16px;margin:0">
${form?.full_name}
<br>${form?.street}
<br>${form?.city},
${form?.zip}
<br>${form?.country}
</p>
</td>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding-bottom:40px;width:50%"
valign="top">
<h4
style="font-weight:500;font-size:16px;color:#555;margin:0 0 5px">
Billing address</h4>
<p
style="color:#777;line-height:150%;font-size:16px;margin:0">
${form?.full_name}
<br>${form?.street}
<br>${form?.city},
${form?.zip}
<br>${form?.country}
</p>
</td>
</tr>
</tbody>
</table>
<table
style="width:100%;border-spacing:0;border-collapse:collapse">
<tbody>
<tr>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding-bottom:40px;width:50%"
valign="top">
<h4
style="font-weight:500;font-size:16px;color:#555;margin:0 0 5px">
Payment</h4>
<p
style="color:#777;line-height:150%;font-size:16px;margin:0">
<img style="height:24px;display:inline-block;margin-right:10px;margin-top:5px"
src="https://ci5.googleusercontent.com/proxy/ClnTx-YysJcvCrM3swKct3jeDFnBqDhP9Ew_-EKcQ1c4Xeo87XDwCj0XhJppm4xvkZyA84xoTnaADnI0hQAF2oqjHPoY3rKZ43SA4BCV_hNsW9ps9vWKpR1FCzXTNM4riUCgt_Ryq5X76fD2-XpjwqtjoslFsuA9PAcbHN-w8fYb0RyPdsaInCJOZ-evfnljWhTCB0HNDflAcCu7WR46SATxuvfamCe7VF6W3K3SZ2P9pfEe=s0-d-e1-ft#https://cdn.shopify.com/shopifycloud/shopify/assets/themes_support/notifications/mastercard-c8d6f1c2e7b63ab95f49954c724c675678d205478e3de8d6f3da384fc068589d.png"
alt="Mastercard"
height="24"
class="CToWUd"
data-bit="iit">
<span
style="font-size:16px">ending
with
${form?.last_4_credit_card}</span>
<br>
</p>
</td>
</tr>
<tr>
<td style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding-bottom:40px;width:50%"
valign="top">
<h4
style="font-weight:500;font-size:16px;color:#555;margin:0 0 5px">
Shipping method</h4>
<p
style="color:#777;line-height:150%;font-size:16px;margin:0">
Please See Item Description
For Dispatch Dates (Pre
Order Items)</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<table
style="width:100%;border-spacing:0;border-collapse:collapse;border-top-width:1px;border-top-color:#e5e5e5;border-top-style:solid">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;padding:35px 0">
<center>
<table
style="width:560px;text-align:left;border-spacing:0;border-collapse:collapse;margin:0 auto">
<tbody>
<tr>
<td
style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Cantarell','Fira Sans','Droid Sans','Helvetica Neue',sans-serif">
<p
style="color:#999;line-height:150%;font-size:14px;margin:0">
If you have any questions, please visit our
customer service help page
<a
style="font-size:14px;text-decoration:none;color:#000000">here.</a>
</p>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
<img style="min-width:600px;height:0"
src="https://ci4.googleusercontent.com/proxy/C5WAwfRu-nhYYB726ZtDmBBZxH2ZQQgtpxwmJT5KONtMOVp6k7laRdD7JghQXsHLcYM4veQr436syfT22M4kVYeof9oM4TIq5I7li0_YUjrim2hpHv5dYG7V9z9OmFYRRwYK3KgYIf0ck0d_WTq1EjhX_DpBFoi4n20fTmcCfJxl76PIrL1HodOHxbkR8PrieSaJX9F3tcNZb-9L3JTm7_owWlAKVQ64kFMBmJHwK7I=s0-d-e1-ft#https://cdn.shopify.com/shopifycloud/shopify/assets/themes_support/notifications/spacer-1a26dfd5c56b21ac888f9f1610ef81191b571603cb207c6c0f564148473cab3c.png"
height="1" class="CToWUd" data-bit="iit">
</td>
</tr>
</tbody>
</table>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">

</div>
</div>
</div>
<div id=":na" class="ii gt" style="display:none">
<div id=":n9" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
