export const grailedEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":142" tabindex="-1"></div>
<div id=":13m" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyODQ3NDE5OTY5MzM3NCIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyODQ3NDE5OTY5MzM3NCIsbnVsbCxbXV0.">
<div id=":13n" class="a3s aiL ">
<div class="adM">
<div></div>
</div>
<div class="adM">

</div>
<div class="adM">
<div></div>
</div>
<div class="adM">

</div>
<div class="adM">
<div></div>
</div>
<div class="adM">

</div>
<div>
<div class="adM">
</div>
<table id="m_1178388504862114150bgwrapper" style="border-collapse:collapse" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table id="m_1178388504862114150wrapper" style="border-collapse:collapse" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="border-collapse:collapse" align="center" valign="top">
<table id="m_1178388504862114150grailed-header-logo"
style="width:620px;border-collapse:collapse" border="0"
width="620" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="height:40px;border-collapse:collapse"
height="40">&nbsp;</td>
</tr>
<tr>
<td style="border-collapse:collapse" align="center"
valign="top">
<a href="https://www.grailed.com/?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none;border-collapse:collapse"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469289000&amp;usg=AOvVaw0axzV_b4Mp5mtDybN5Vg_3">
<img style="display:block;font-family:Arial,sans-serif;font-size:22px;color:#000000;font-weight:bold;letter-spacing:2px;border:0!important;outline:none!important"
src="https://ci6.googleusercontent.com/proxy/OoMdQtRcMdhp72QHQAqyQUpgn-cXhoK25qL_uc_jepyXUrrUvBi1iusrEZTv6LXRcJkPhEXovjiKeVDZmdUuQNLzWDEedz1sd3z3cscv9_LMSMb2qQ=s0-d-e1-ft#https://ds6dnbdlsnuyn.cloudfront.net/emails/logo-no-whitespace.jpg"
alt="GRAILED" width="225" border="0"
class="CToWUd" data-bit="iit">
</a>
</td>
</tr>
<tr>
<td style="height:30px;border-collapse:collapse"
height="30">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table
style="text-align:center;font-family:Helvetica,Arial,sans-serif"
align="center">
<tbody>
<tr>
<td>
<div
style="text-align:center;font-size:24px;margin-top:20px;margin-bottom:15px;font-family:TimesNewRoman">
Congrats on Your Purchase!</div>
</td>
</tr>
<tr style="min-width:320px;max-width:600px">
<td>
<hr
style="margin-bottom:15px;margin-top:35px;border:1px solid #e1e1e1">
<table style="width:100%;margin-bottom:20px">
<tbody>
<tr>
<td>
<table
style="width:33%;min-width:200px"
align="left">
<tbody>
<tr>
<td
style="padding:10px;vertical-align:top">
<a href="https://www.grailed.com/listings/32403073-chanel-chanel-handbag-cleaning-cloth-with-book-ribbon?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/listings/32403073-chanel-chanel-handbag-cleaning-cloth-with-book-ribbon?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw0UjWIGU5cnGQm04JkuRrHH">
<img style="width:100%;max-width:120px"
src=${form?.image_link}
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</a>
</td>
</tr>
</tbody>
</table>
<table
style="width:60%;min-width:200px">
<tbody>
<tr>
<td>
<table
style="width:100%"
align="left">
<tbody>
<tr>
<td
style="padding:10px;text-align:left;vertical-align:top">
<div
style="font-family:'TimesNewRoman'">
ITEM
</div>
<hr
style="border:1px solid #e1e1e1">
<p
style="margin:0;font-size:14px;line-height:25px;min-width:180px">
<strong>${form?.brand}</strong>
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
${form?.item}
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
${form?.size}
</p>
</td>
</tr>
</tbody>
</table>
<table
style="width:100%"
align="left">
<tbody>
<tr>
<td
style="padding:10px;text-align:left;vertical-align:top">
<div
style="font-family:'TimesNewRoman'">
SHIPPING
DETAILS
</div>
<hr
style="border:1px solid #e1e1e1">
<p
style="margin:0;font-size:14px;line-height:25px">
<strong>${form?.full_name}</strong>
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
${form?.street}
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
&nbsp;
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
${form?.city},
${form?.zip}
</p>
<p
style="margin:0;font-size:14px;line-height:25px">
${form?.country}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr style="min-width:320px;max-width:600px">
<td>
<table style="width:100%">
<tbody>
<tr>
<td>
<table style="width:33%"
align="left">
<tbody>
<tr>
<td
style="padding:10px;text-align:left;vertical-align:top">
&nbsp;</td>
</tr>
</tbody>
</table>
<table
style="width:60%;min-width:180px"
align="left">
<tbody>
<tr>
<td
style="padding:10px;text-align:left;vertical-align:top">
<div
style="font-family:'TimesNewRoman'">
PAYMENT</div>
<hr
style="border:1px solid #e1e1e1">
<table
style="width:100%;min-width:30px"
align="left">
<tbody>
<tr>
<td
style="text-align:left;vertical-align:top;width:70%">
<p
style="font-size:14px;line-height:25px">
Sold
Price
</p>
</td>
<td
style="text-align:right;vertical-align:top;width:30%">
<p
style="font-size:14px;line-height:25px">
${form?.subtotal}
</p>
</td>
</tr>
<tr>
<td
style="text-align:left;vertical-align:top;width:70%">
<p
style="font-size:14px;line-height:25px">
Tax
</p>
</td>
<td
style="text-align:right;vertical-align:top;width:30%">
<p
style="font-size:14px;line-height:25px">
${form?.taxes}
</p>
</td>
</tr>
<tr>
<td
style="text-align:left;vertical-align:top;width:70%">
<p
style="font-size:12px;line-height:10px">
<a href="https://help.grailed.com/hc/en-us/articles/9226890136347?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="color:#737373"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://help.grailed.com/hc/en-us/articles/9226890136347?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw3aI5qZoREFf6V-Ozl6Rpsc">Learn
more</a>
</p>
</td>
</tr>
<tr>
<td
style="padding-top:10px;text-align:left;vertical-align:top;width:70%">
<p
style="font-size:18px;line-height:25px">
<strong>TOTAL</strong>
</p>
</td>
<td
style="padding-top:10px;text-align:right;vertical-align:top;width:30%">
<p
style="font-size:18px;line-height:25px">
<strong>${form?.total}</strong>
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<div
style="font-family:TimesNewRoman;font-size:20px;margin:25px 0">
Your Seller is Located in: ${form?.seller_location}
</div>
<table style="margin-bottom:20px" align="center">
<tbody>
<tr>
<td>
<a href="https://www.grailed.com/packingthings?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/packingthings?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw3B_xsoXz7F1Ohn6LOOXAeH">
<img style="outline:none;text-decoration:none;display:block!important;border:0;float:none;border-radius:50%;width:80px;height:80px;margin:0 auto"
title="packingthings"
src=${form?.seller_profile_image_link}
width="80" align="center"
border="0" class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</a>
</td>
<td style="width:50%">
<img style="outline:none;text-decoration:none;clear:both;display:block!important;border:0;height:auto;float:none;width:100%;max-width:180px;margin:0 auto"
src="https://ci6.googleusercontent.com/proxy/EjxBYE24LvDu-fAlUr8BoV8sFu3zgfNCG14wQ3J_N7UKpRuVx4zbgE1KtQAqbx6gSQfd0yeiTcpgk1nvV0bygrSswjqitsYI=s0-d-e1-ft#https://cdn.filestackcontent.com/cnRFkGKgTZWlgVRIsYmv"
width="180" align="center"
border="0" class="CToWUd"
data-bit="iit">
</td>
<td>
<a href="https://www.grailed.com/"
style="text-decoration:none"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw0DFkUsr7RUbpU4BXC-cZUK">
<img style="outline:none;text-decoration:none;display:block!important;border:0;float:none;border-radius:50%;width:80px;height:80px;margin:0 auto"
src="https://ci3.googleusercontent.com/proxy/n9kS7gC7xgJjOPwX_dX_WJwEab3wOjIxVAPvFdmP5n4cDsy_83mHYSmS1nM92irZxh63r-bRaU-CscJUz0ZVqIByUS0vX32GikE0_yyVX7J17aC46Udjgkb6drgVG3w3FMSjWfr97H3rW5WGXCcpqCe3wo7pIjAxaSXUx-v9XlLkE-x66ZLpSW974N8E7inFHnL6Gbhl42elkmI0QIvQVY5RxD85ilFp3SUt7ArqYWazi4PCEqfAtTg_g2UN=s0-d-e1-ft#https://process.fs.grailed.com/AJdAgnqCST4iPtnUxiGtTz/cache=expiry:max/rotate=deg:exif/resize=width:80,height:80,fit:crop/output=quality:70/compress/Xyx4t7BQbyWtBCwRiKRw"
width="80" align="center"
border="0" class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
<tr>
<td>${form?.seller_location}</td>
<td style="width:50">
<strong>TO</strong>
</td>
<td>${form?.country}</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<hr
style="border:1px solid #e1e1e1;margin-bottom:30px">
<div
style="margin:0 auto;font-family:TimesNewRoman;font-size:24px">
Estimated Shipping Time</div>
<div style="margin:1.5rem 0">
<strong>International</strong> : 3-6 weeks (or
longer)
</div>
<div
style="font-size:18px;margin-bottom:30px;text-align:left">
Sellers have up to 7 days to ship the item and
provide tracking. We’ll send you an email as
soon as the item is on its way. If you have any
questions, you can reach out to the seller.
<br>
<br>If you don’t receive tracking within 7 days,
Grailed is here to help. We’ll cancel the order
and issue you a full refund.
<a href="https://help.grailed.com/hc/en-us/articles/1260807541829?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="color:#000000;text-decoration:underline"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://help.grailed.com/hc/en-us/articles/1260807541829?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw2vct9YghclYDZjmiugeQ5B">Learn
more.</a>
</div>
</td>
</tr>
<tr>
<td>
<hr
style="border:1px solid #e1e1e1;margin-bottom:30px">
<table
style="text-align:center;font-family:Helvetica,Arial,sans-serif;margin-top:10px"
align="center">
<tbody>
<tr>
<td>
<div
style="font-size:24px;line-height:25px;padding-bottom:15px;font-family:TimesNewRoman">
More Questions?</div>
<div>Reach out to us anytime, we're
here to help.</div>
<div style="padding-top:30px">
<a href="https://help.grailed.com/hc/en-us?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="color:#ffffff;background-color:#000000;border-radius:2px;font-size:16px;line-height:32px;padding:12px 25px;font-family:Arial;width:156px;max-width:186px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://help.grailed.com/hc/en-us?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw1eMAGz_fm-M-7r8A2q5Jrf">Contact
Support</a>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-collapse:collapse" align="center" valign="top">
<table style="width:626px;border-collapse:collapse" border="0"
width="620" cellspacing="0" cellpadding="0" align="center"
bgcolor="#f9f9f9">
<tbody>
<tr>
<td style="border-collapse:collapse" width="10">&nbsp;
</td>
<td style="border-collapse:collapse" align="center"
valign="top">
<table style="width:600px;border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="height:28px;border-collapse:collapse"
height="28">&nbsp;</td>
</tr>
<tr>
<td style="border-collapse:collapse"
align="center" valign="top">
<table
style="width:80px;border-collapse:collapse"
border="0" width="80"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:0px;line-height:0px;border-collapse:collapse"
align="left"
valign="top"
width="25">
<a href="https://twitter.com/grailed?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor&amp;utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none;border-collapse:collapse"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://twitter.com/grailed?ref_src%3Dtwsrc%255Egoogle%257Ctwcamp%255Eserp%257Ctwgr%255Eauthor%26utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw1zbysqo2zX9aOeiD-WrV_C">
<img style="display:block;font-size:12px;font-weight:bold;line-height:18px;color:#000000;border:0!important;outline:none!important"
src="https://ci5.googleusercontent.com/proxy/n78nlf0KYmvRAZFtdUjpUdJviWnYv5ob6PKBqIDCyvvs_np-DoSXPJi6D4RyzSkxsuDR-eGUOtcjblLrA3BdX_5285Qa6B2kH1U=s0-d-e1-ft#https://ds6dnbdlsnuyn.cloudfront.net/emails/twitter.jpg"
alt="Tw"
width="23"
height="18"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="width:14px;border-collapse:collapse"
width="14">&nbsp;
</td>
<td style="font-size:0px;line-height:0px;border-collapse:collapse"
align="left"
valign="top"
width="9">
<a href="https://www.facebook.com/grailed/?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none;border-collapse:collapse"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.facebook.com/grailed/?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw2ZgziJBPt8Bb87YKRvwOkn">
<img style="display:block;font-size:12px;font-weight:bold;line-height:18px;color:#000000;border:0!important;outline:none!important"
src="https://ci3.googleusercontent.com/proxy/Xtxupq_7XNGpOf9QXla0wQB1fmmkmKsa-e5v64ThqkRciAUpqPjwWy2b_pypzniyzEKmceyyD8M6yHEzzDoebQqvDA2f=s0-d-e1-ft#https://ds6dnbdlsnuyn.cloudfront.net/emails/fb.jpg"
alt="Fb"
width="9"
height="18"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="width:14px;border-collapse:collapse"
width="14">&nbsp;
</td>
<td style="font-size:0px;line-height:0px;border-collapse:collapse"
align="left"
valign="top"
width="18">
<a href="https://www.instagram.com/grailed/?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none;border-collapse:collapse"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.instagram.com/grailed/?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw0R1XBnfa23pFYMy149pxZ-">
<img style="display:block;font-size:12px;font-weight:bold;line-height:18px;color:#000000;border:0!important;outline:none!important"
src="https://ci6.googleusercontent.com/proxy/CuUX3l8uqC8J9vyBlFYcusmz029iqpYPW7y9XT9GaTUtRebnHnLa_izJLBIbM8qF3LKMKJYy5Qt01jr7UcPbI6RXcmAYEZsP=s0-d-e1-ft#https://ds6dnbdlsnuyn.cloudfront.net/emails/insta.jpg"
alt="Insta"
width="18"
height="18"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="height:22px;border-collapse:collapse"
height="22">&nbsp;</td>
</tr>
<tr>
<td style="border-collapse:collapse;font-size:13px;line-height:22px;color:#989898;text-decoration:none"
align="center" valign="top">To make
sure you don’t miss out on the
newest heat and latest price drops,
add
<br><a
href="mailto:no-reply@grailed.com"
target="_blank">no-reply@grailed.com</a>
to your address book.
<br>You can unsubscribe from
receiving these emails by
<a href="https://www.grailed.com/users/notifications?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="border-collapse:collapse;font-size:13px;line-height:22px;color:#989898;text-decoration:underline"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/users/notifications?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw33wvJPfPnok1KsSCOgqjKo">editing
your Grailed notification
settings</a>.
<br>
<br>All Grailed services are subject
to our
<span
style="text-decoration:underline;border-collapse:collapse">
<a href="https://www.grailed.com/about/privacy?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:underline;border-collapse:collapse;font-size:13px;line-height:22px;color:#989898"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/about/privacy?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw1lywywhNvw1tTRIXbTGjqW">Privacy
&amp; Cookies Policy</a>
</span> and
<span
style="text-decoration:underline;border-collapse:collapse">
<a href="https://www.grailed.com/about/terms?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:underline;border-collapse:collapse;font-size:13px;line-height:22px;color:#989898"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/about/terms?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw0DCndPsfuk9sWLUDlF3d7T">Terms
&amp; Conditions</a>
</span>.
<br>By using our services you agree
to these.
<br>
<br>These services are operated and
provided by Grailed Inc.
<br>
<br>131 Spring St, Suite 601, New
York, NY 10012
<br>
<br>
<a href="https://www.grailed.com/?utm_campaign=buyer_purchase_confirmation_auto_refund&amp;utm_medium=email&amp;utm_source=mailgun-grailed&amp;utm_term=system_email"
style="text-decoration:none;border-collapse:collapse;font-size:13px;line-height:22px;color:#989898"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.grailed.com/?utm_campaign%3Dbuyer_purchase_confirmation_auto_refund%26utm_medium%3Demail%26utm_source%3Dmailgun-grailed%26utm_term%3Dsystem_email&amp;source=gmail&amp;ust=1692885469290000&amp;usg=AOvVaw0B5wcQSHNgkF9pEHyLN3Pe">www.grailed.com</a>
</td>
</tr>
<tr>
<td style="height:28px;border-collapse:collapse"
height="28">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td style="border-collapse:collapse" width="10">&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

<div style="white-space:nowrap;font:20px courier;color:#ffffff">&nbsp;</div>
</td>
</tr>
</tbody>
</table>
<img src="https://ci6.googleusercontent.com/proxy/DTGsAkqG11gTAcPC0i2bTvxYOdFDSXMbpZs8Wz5B_6FE9AXe-w4Cr3qDLAygRONews9X0kYidEazFQ5dllNHM-M3_IyERujwXFUljFPCNrECgu-ujYNfqo9m8Gav7oaxK6xyoOVZY4w12rWNsHjm8LPKO8sVZi0K6Ryq5mIWBwoEnWd6ya7LCzGh4ThnKvK9KbYY3LYozjkmssFOMU4aCCwL7PJ3201ChYCSXynkHZGFAeyvHMRgX7CGhmCMWxyPQozo=s0-d-e1-ft#https://email.grailed.com/o/eJwVyzsOwyAMANDTlDGyjfl44DAGmxSpaaV06u2bvP15w1yQoxBLsCbZQcJqBERIKFAZuGxFevHUNdvoqLE_GPZT18ttG58jPNsA1aisKB1Fq0-qSSiNZDqj4QxnM_-u_T1O_937uPZ9_574JUg"
alt="" width="1px" height="1px" class="CToWUd" data-bit="iit">
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">


</div>
</div>
</div>
<div id=":on" class="ii gt" style="display:none">
<div id=":13h" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
