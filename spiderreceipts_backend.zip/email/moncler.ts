export const monclerEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":151" tabindex="-1"></div>
<div id=":145" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyOTgzNDcwODAyMzAxOSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyOTgzNDcwODAyMzAxOSIsbnVsbCxbXV0.">
<div id=":144" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div>
<div class="adM">
</div>
<div class="gmail_quote">
<div class="adM">
<br>
</div><u></u>
<div
style="background:#ffffff;color:#333333;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:11px;height:100%!important;margin:0px;padding:0px;width:100%!important">
<table style="border-collapse:collapse;border-spacing:0" border="0" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr style="height:0!important;opacity:0;display:none;padding:0;margin:0">
<td
style="padding:0px;vertical-align:top;max-width:300px;max-height:1px!important;opacity:0;white-space:nowrapper;margin:0px;font-size:1px;line-height:1px;color:#f6f6f6!important;background-color:#f6f6f6">
<span style="display:none!important">View all details</span>
</td>
</tr>
<tr style="height:0!important;opacity:0;display:none;padding:0;margin:0">
<td style="padding:0px;vertical-align:top;max-width:300px;max-height:1px!important;opacity:0;white-space:nowrapper;margin:0px;font-size:1px;line-height:1px;color:#f6f6f6!important;background-color:#f6f6f6"
align="center">
<span style="display:none!important">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp; ‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;</span>
</td>
</tr>
</tbody>
</table>
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0" width="100%" cellspacing="0" cellpadding="0" align="center"
bgcolor="#F8F9FA">
<tbody>
<tr>
<td align="center" valign="top">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%;max-width:750px"
border="0" width="750" cellspacing="0" cellpadding="0"
align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="width:750px" align="center" valign="top"
width="750">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="background-color:#ffffff;width:100%"
align="center" width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:600px"
border="0" width="600"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="background-color:#ffffff;width:100%"
align="center"
width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:10px 0 10px 0;font-size:14px;line-height:16px;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;color:#363636;text-decoration:none;text-align:center"
align="center">
If you
have
problems
viewing
this
email,
<a href="https://view.email.moncler.com/?qs=f13852c9fb1e699fbc91306d295679353216513b93b5aa6d37393fe4ebf59402058c3fc3bc052f01d36ac37deaa69c80d9d63b4279621426e4d33e697ea44dd554d0f284cf273fb1648ca83ffc220991824893d29b08b513"
rel="link noopener"
style="font-size:14px;line-height:16px;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;color:#363636;text-decoration:underline"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://view.email.moncler.com/?qs%3Df13852c9fb1e699fbc91306d295679353216513b93b5aa6d37393fe4ebf59402058c3fc3bc052f01d36ac37deaa69c80d9d63b4279621426e4d33e697ea44dd554d0f284cf273fb1648ca83ffc220991824893d29b08b513&amp;source=gmail&amp;ust=1692886769905000&amp;usg=AOvVaw24wBW6P0gH6JHA_yJgyqSU">click
here</a>
</td>
</tr>
</tbody>
</table>
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr
style="font-size:0;line-height:0;border-collapse:collapse">
<td style="padding-top:15px;width:100%"
align="center"
valign="bottom"
width="100%">
<table
style="margin:0 auto!important;width:108px"
border="0"
width="108"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr
style="font-size:0;line-height:0;border-collapse:collapse">
<td>
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f876fa524144e87f13d830669dad1ecd331c8d03efcd9e6ae698f45e5ca844d59b156243d3dd4ed09f506a0b0f2560b11b6558797f9a8c9fa0"
valign="bottom"
style="border:0 none;display:block;margin:0 auto;outline:0;text-decoration:none"
aria-label="Visit Moncler"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f876fa524144e87f13d830669dad1ecd331c8d03efcd9e6ae698f45e5ca844d59b156243d3dd4ed09f506a0b0f2560b11b6558797f9a8c9fa0&amp;source=gmail&amp;ust=1692886769905000&amp;usg=AOvVaw0ub7Z3GdAsZ8Dll4luxFht">
<img style="border:0 none;display:block;outline:0;text-decoration:none"
src="https://ci5.googleusercontent.com/proxy/d2fgVbR1EStsyM289mW9fpxFDiQS9srDiTjPTiV96O8xqGRzt1S2T99H8LgyncNosm6g0HSEChlEjaKvy_6F36Q6o-F1bs3kOxxemx-uHHoYgVOG_y6-TFFic266_V5VrXeCAIEfT2Xa2VTRMuHCADCP08Q_4G5pYT1xGTHTYw=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/TRN_HeaderLogo/fm8pkl/std/0x0/TRN_HeaderLogo.png"
alt="Moncler logo"
width="108"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="width:750px" align="center" valign="top"
width="750">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%;background-color:#ffffff"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="background-color:transparent;width:100%"
align="center" width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:600px"
border="0" width="600"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="background-color:transparent;width:100%;padding-left:20px;padding-right:20px"
align="center"
valign="top"
width="100%">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="40">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<h1
style="color:#000000;display:block;font-family:'Futuraefoplight4-regular',Helvetica,Arial,sans-serif;font-size:24px;font-weight:300;letter-spacing:.03em;line-height:28px;margin:0;text-align:center;text-transform:uppercase">
THANK
YOU
FOR
YOUR
ORDER
</h1>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="40">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:726px"
border="0" width="726" cellspacing="0"
cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="background-color:#ffffff;width:100%"
align="center" width="100%">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:600px"
width="600"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
align="center">
<p
style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;letter-spacing:.03em;line-height:20px;margin:0;text-align:center">
Dear
${form?.full_name},
<br>
<br>Thank
you
for
choosing
Moncler!
<br>Your
order
has
been
received.
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
<tr>
<td style="font-size:1px"
align="center"
height="24">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<p
style="color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:18px;font-weight:600;letter-spacing:.03em;line-height:24px;margin:0;text-align:center;text-transform:none;padding:0 10px">
Order
number
<br>${form?.order_number}
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
align="center"
height="8">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<p
style="color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;line-height:16px;margin:0;text-align:center;text-transform:none;padding:0 10px">
Order
date:
${form?.order_date}
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
align="center"
height="32">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:560px"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
align="center"
width="100%">
<table
style="margin:0 auto!important;width:80%;background-color:#000"
width="80%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="000000">
<tbody>
<tr>
<td
style="background-color:#000;color:#ffffff;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:400;letter-spacing:.03em;line-height:20px;margin:0;text-align:center;text-decoration:none;text-transform:uppercase;border:1px solid #000;width:100%;padding:15px 10px 15px 10px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8ceb9a9f2c7885bad100828c477a9238b7d76c8cd9845b2311ba14c118e0a0394d94d3e3e61738c4e33362f821ec9f010c0b9a052f8955511"
style="color:#ffffff;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:400;letter-spacing:.03em;line-height:20px;margin:0;text-align:center;text-decoration:none;text-transform:uppercase"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8ceb9a9f2c7885bad100828c477a9238b7d76c8cd9845b2311ba14c118e0a0394d94d3e3e61738c4e33362f821ec9f010c0b9a052f8955511&amp;source=gmail&amp;ust=1692886769905000&amp;usg=AOvVaw2cezP3cHfcrEVJ8oi7oVX4">MANAGE
ORDER</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="45">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="left"
valign="top"
width="100%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:20px;font-weight:300;line-height:24px;letter-spacing:.03em;text-align:left;margin-bottom:5px;text-transform:uppercase">
YOUR
ITEM(S)
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="20">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
<tr>
<td style="font-size:1px"
height="27">
&nbsp;
</td>
</tr>
<tr>
<td style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
align="center"
width="100%">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="left"
valign="top"
width="22%">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8ef92c0fb65166273a9c045dd94a68be947f0d44dea9dcbb7396b823f0ceabc58ed9dc10b4ac8c0da889571c29db33399befbafcdb5272791"
aria-label="View Agay Short Down Jacket"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8ef92c0fb65166273a9c045dd94a68be947f0d44dea9dcbb7396b823f0ceabc58ed9dc10b4ac8c0da889571c29db33399befbafcdb5272791&amp;source=gmail&amp;ust=1692886769905000&amp;usg=AOvVaw0F-LOGSAp5OjwFmALurU-D">
<img style="height:auto;width:100%;outline:0;text-decoration:none;background-color:#000000"
src=${form?.image_link}
alt="Agay Short Down Jacket"
width="100%"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</a>
</td>
<td align="left"
valign="top"
width="3%">
&nbsp;
</td>
<td align="left"
valign="top"
width="75%">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="left"
valign="top"
width="78%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:20px">
${form?.item}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:5px">
Size:
${form?.size}
<br>Colour:
${form?.color}
<br>Quantity:
1
</p>
</td>
<td align="left"
valign="top"
width="2%">
&nbsp;
</td>
<td style="color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:right;margin-bottom:20px"
align="left"
valign="top"
width="20%">
<p
style="padding:0;margin:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:right;text-transform:uppercase">
${form?.subtotal}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="5"
height="8">
&nbsp;
</td>
</tr>
<tr>
<td style="width:100%"
colspan="5"
align="center">
<table
style="margin:0 auto!important;width:auto"
cellspacing="0"
cellpadding="0"
align="left">
<tbody>
<tr>
<td
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:400;letter-spacing:.03em;line-height:20px;margin:0;text-align:center;text-decoration:none;width:100%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:12px;font-weight:600;line-height:14px;letter-spacing:.03em;text-align:left;margin-bottom:5px">
Estimated
delivery
${form?.eta}.
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="5"
height="20">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="12">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
<tr>
<td style="width:100%"
align="center">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="left"
valign="top"
width="58%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:12px">
Subtotal
</p>
</td>
<td align="left"
valign="top"
width="2%">
&nbsp;
</td>
<td align="right"
valign="top"
width="38%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:right;margin-bottom:12px">
${form?.subtotal}
</p>
</td>
</tr>
<tr>
<td align="left"
valign="top"
width="58%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:12px">
Delivery:
Express
</p>
</td>
<td align="left"
valign="top"
width="2%">
&nbsp;
</td>
<td align="right"
valign="top"
width="38%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:right;margin-bottom:12px">
${form?.shipping}
</p>
</td>
</tr>
<tr>
<td align="left"
valign="top"
width="58%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:12px">
Order
total
</p>
</td>
<td align="left"
valign="top"
width="2%">
&nbsp;
</td>
<td align="right"
valign="top"
width="38%">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:right;margin-bottom:12px">
${form?.total}
</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="20">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
<tr>
<td style="width:100%"
align="center">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:50%;vertical-align:top"
align="center"
valign="top">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:100%;padding-right:20px"
align="center">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:12px">
Shipping
Address
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.full_name}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.street}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.city}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.zip}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.country}
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:50%;vertical-align:top"
align="center"
valign="top">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:100%"
align="center">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:12px">
Billing
Address
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.full_name}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.street}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.city}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.zip}
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.country}
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
<tr>
<td style="width:100%"
align="center">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:50%;vertical-align:top"
align="center"
valign="top">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:100%;padding-right:20px"
align="center">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
Delivery
Method
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
Express
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:50%;vertical-align:top"
align="center"
valign="top">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:100%"
align="center">
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:600;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
Payment
Method
</p>
<p
style="margin:0;padding:0;color:#000000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;line-height:20px;letter-spacing:.03em;text-align:left;margin-bottom:4px">
${form?.payment_method}
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="30">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="padding-left:20px;padding-right:20px">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="45">
&nbsp;
</td>
</tr>
<tr>
<td style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;letter-spacing:.03em;line-height:20px;margin:0;text-align:center"
align="center">
<table
style="border:0;border-collapse:collapse!important;border-spacing:0!important;box-sizing:border-box;margin:0 auto!important;table-layout:auto;width:460px"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;letter-spacing:.03em;line-height:20px;margin:0;text-align:center"
align="center">
According
to
the
payment
method
chosen
at
checkout,
the
payment
may
already
have
been
deducted
or
pre-authorized.
<br>
<br>To
check
the
status
of
your
order
enter
your
order
number
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8a4b8f5023988ed52ef716bb6ecbe4b108359a76babd63692330c6dc1fc90de1309d8f60e7cfb754723f53185359db62febe0c329854d81a2"
aria-label="Order Status"
rel="link noopener"
style="border:0 none;color:#000000;outline:0;text-align:center"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8a4b8f5023988ed52ef716bb6ecbe4b108359a76babd63692330c6dc1fc90de1309d8f60e7cfb754723f53185359db62febe0c329854d81a2&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1kt-zHj6leRwaqJQxjAgpv">here</a>.
If
you
shopped
as
a
registered
user,
you
can
get
status
updates
directly
on
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8f266c07f7100daaf47a8994cebd823ca9f9b0aab301f297223835077947003da883e7b327201dd92ea81578893b4000de1de8afe18f395ce"
rel="link noopener"
style="border:0 none;color:#000000;outline:0;text-align:center"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8f266c07f7100daaf47a8994cebd823ca9f9b0aab301f297223835077947003da883e7b327201dd92ea81578893b4000de1de8afe18f395ce&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1XybLS9OT1UYFHzqbky3Wv">My
Moncler</a>.
</td>
</tr>
<tr>
<td style="font-size:1px"
height="20">
&nbsp;
</td>
</tr>
<tr>
<td style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;letter-spacing:.03em;line-height:20px;margin:0;text-align:center"
align="center">
Warmly,
<br>Moncler
Team
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="45">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" valign="top">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%;background-color:#ffffff"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="background-color:transparent;width:100%"
align="center" width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0" width="100%"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="background-color:transparent"
align="center"
valign="top">
<table
style="margin:0 auto!important;width:726px"
border="0"
width="726"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding-left:20px;padding-right:20px"
align="center"
valign="top">
<table
style="width:100%;margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
<tr>
<td style="font-size:1px"
height="45">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<h2
style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:20px;font-weight:300;letter-spacing:.03em;line-height:24px;margin:0;text-align:center;text-transform:uppercase">
BROWSE
OUR
NEW
ARRIVALS
</h2>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="34">
&nbsp;
</td>
</tr>
<tr>
<td style="padding-bottom:60px"
align="center">
<table
style="margin:0 auto!important"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:0 50px 0 50px"
align="center">
<table
style="margin:0 auto!important;display:table"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;padding:0 10px;text-align:center"
align="center">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f836392efc218576ac5992075cd6d60a1d6bd6605cc1c0d236475d9dd1e00cdb63dde885374cde03fdb622441f3990ca058e6539e2aa199449"
style="border:0 none;color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;outline:0;text-align:center;text-decoration:none"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f836392efc218576ac5992075cd6d60a1d6bd6605cc1c0d236475d9dd1e00cdb63dde885374cde03fdb622441f3990ca058e6539e2aa199449&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw3SvyKQ7z3eBuMk-dJdIxts">Men</a>
</td>
<td style="width:20px;font-size:1px"
width="20">
&nbsp;
</td>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;padding:0 10px;text-align:center"
align="center">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f834e3a9e0d183d4c5245da73d5441d61c2654ae6b7940e94368cd4b39ebac9a44cf50fe26fc3361b1cdf7c979b9b2bb0e608ed597233d3425"
style="border:0 none;color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;outline:0;text-align:center;text-decoration:none"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f834e3a9e0d183d4c5245da73d5441d61c2654ae6b7940e94368cd4b39ebac9a44cf50fe26fc3361b1cdf7c979b9b2bb0e608ed597233d3425&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw25_D9QVSUbIhv8bENvsiIE">Women</a>
</td>
<td style="width:20px;font-size:1px"
width="20">
&nbsp;
</td>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;padding:0 10px;text-align:center"
align="center">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f83ecad54475870142a3b3a85794de56d55c24683ccf10dc6a74d99154af752fa3a0100558062780f9d2f38b102c8cdf5d553b492645436cdf"
style="border:0 none;color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.1em;outline:0;text-align:center;text-decoration:none"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f83ecad54475870142a3b3a85794de56d55c24683ccf10dc6a74d99154af752fa3a0100558062780f9d2f38b102c8cdf5d553b492645436cdf&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw3ai2ZLa0AHPnbHpltmNSGl">Children</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" valign="top">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%;background-color:#ffffff"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="background-color:transparent;width:100%"
align="center" width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0" width="100%"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="background-color:transparent;padding-left:20px;padding-right:20px"
align="center"
valign="top">
<table
style="margin:0 auto!important;width:686px"
border="0"
width="686"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
<tr>
<td style="font-size:1px"
height="50">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="margin:0 auto!important;width:600px"
border="0"
width="600"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="width:20px"
align="center"
valign="top"
width="20">
&nbsp;
</td>
<td align="center"
valign="top">
<table
style="width:100%;margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#333;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.03em;text-align:center;text-transform:uppercase"
align="center"
width="25%">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f865e02411c2f58ab104894b808fe3cf2380fb5fc2521b39601f9e1ef2dd0513567fd288b6b6ecd500ffc7f2661e9729863fd76b0ecc65a950"
rel="link noopener"
style="border:0 none;color:#000000;outline:0;text-align:center;text-decoration:none"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f865e02411c2f58ab104894b808fe3cf2380fb5fc2521b39601f9e1ef2dd0513567fd288b6b6ecd500ffc7f2661e9729863fd76b0ecc65a950&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw0uS8oyPm5fib-2ZewUATbW">OUR
SPECIAL
SERVICES</a>
</td>
<td style="color:#333;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.03em;text-align:center;text-transform:uppercase"
align="center"
width="25%">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f81bc365c2b1d8009ddb7177119180732e53831073919edfae904ab84f82088ed07bf439ee9380f17f465929ce7e1aad76317f7e40cdeef8c8"
rel="link noopener"
style="border:0 none;color:#000000;outline:0;text-align:center;text-decoration:none"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f81bc365c2b1d8009ddb7177119180732e53831073919edfae904ab84f82088ed07bf439ee9380f17f465929ce7e1aad76317f7e40cdeef8c8&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1pGLVMKHrG26I4YFW35bXD">SHIPPING
INFORMATION</a>
</td>
<td style="color:#333;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;line-height:20px;font-weight:300;letter-spacing:.03em;text-align:center;text-transform:uppercase"
align="center"
width="25%">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8b68f8093bbe9d1af7aa1353ffb2d426b5b4f333eb599e852029eeba287c8dec8cb69449662bd2d96b7d46567bc254e3ac509367ced7c7f61"
rel="link noopener"
style="border:0 none;color:#000000;outline:0;text-align:center;text-decoration:none"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8b68f8093bbe9d1af7aa1353ffb2d426b5b4f333eb599e852029eeba287c8dec8cb69449662bd2d96b7d46567bc254e3ac509367ced7c7f61&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1-w5ELBhEz3del0PUPCpnS">EXCHANGES
AND
RETURNS</a>
</td>
</tr>
</tbody>
</table>
</td>
<td style="width:20px"
align="center"
valign="top"
width="20">
&nbsp;
</td>
</tr>
</tbody>
</table>
<table
style="margin:0 auto!important;width:686px"
border="0"
width="686"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
height="50">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" valign="top">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:100%"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="background-color:#ffffff;width:100%"
align="center" width="100%">
<table
style="border:0 none;border-collapse:collapse!important;float:none;margin:0 auto!important;width:750px"
border="0" width="750"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="background-color:#ffffff;padding-left:20px;padding-right:20px"
align="center"
valign="top">
<table
style="margin:0 auto!important;width:710px"
border="0"
width="710"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="top">
<table
style="width:100%;margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px"
height="48">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<h2
style="color:#000000;display:block;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:16px;font-weight:300;letter-spacing:.03em;line-height:20px;margin:0;text-align:center;text-transform:uppercase">
NEED
HELP?
</h2>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="16">
&nbsp;
</td>
</tr>
<tr>
<td
align="center">
<table
style="width:80%;margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center;line-height:16px;text-decoration:none">
Our
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f843255162b7b5e96cb92e97ad2438b930fa0422ec7b9d02e4a78fab3db71aeef9f360cfe4a0105bee7ebd8f9c8e1f3720586b1e61abb322dc"
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 0 0;text-align:center;line-height:16px;white-space:nowrap"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f843255162b7b5e96cb92e97ad2438b930fa0422ec7b9d02e4a78fab3db71aeef9f360cfe4a0105bee7ebd8f9c8e1f3720586b1e61abb322dc&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1202_KETeQEDaynlYBq6TQ">Client
Service</a>
is
at
your
disposal.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
<tr>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center"
align="center">
<table
style="width:80%;margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;line-height:16px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center"
align="center">
<table
style="margin:0 auto!important;display:table"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
<tr>
<td>
<img src="https://ci3.googleusercontent.com/proxy/7jasuqmgnUvzjALJvmrPurGIVA9qqQgNaVsgqqt17k8wnY6ueiBew1emph-sprkCCYHNlq81b1DkyDSTiWeDhaAfcl0-pCQkS0jzpraR-f8S6SqDml6BSwB2BcT-PqGsJbrHSuVr22lI0RWv_suIPW6CXUFe9N9-Zg=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/SocialPhone/fm8pkl/std/0X0/SocialPhone.png"
width="auto"
height="15"
class="CToWUd"
data-bit="iit">
</td>
<td>
<a href="tel:0080010204000"
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 0 0 10px;text-align:center;line-height:16px;text-decoration:none;text-transform:uppercase"
rel="noopener"
target="_blank">00
800
10204000</a>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center"
align="center">
<table
style="margin:0 auto!important;display:table"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
<tr>
<td>
<img src="https://ci5.googleusercontent.com/proxy/YJ4PJGrJfOphiRjqSGOLEhq8QUj0f-B9RGWeo8anREgvJfGAQZmFQNa3bWLjFRFU1DnQtSVMT8tM2t-ZD-GmYCR_8eiG5grkC6ARVRmDRhCv57-DUSD6Jg_i5o7GXFOvfZQazbjCdtpfeSD1BHNsHKdyTWrS3ba-KQ=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/SocialEmail/fm8pkl/std/0X0/SocialEmail.png"
width="auto"
height="15"
class="CToWUd"
data-bit="iit">
</td>
<td>
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8e38cd40d3683c9d11a385d692e0142fccc928a0fbe33b28d81f0563ce17942ab7736794e9c43b2608497c50b741ad10a772a81a4076a1c4b"
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 0 0 10px;text-align:center;line-height:16px;text-decoration:none;text-transform:uppercase"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8e38cd40d3683c9d11a385d692e0142fccc928a0fbe33b28d81f0563ce17942ab7736794e9c43b2608497c50b741ad10a772a81a4076a1c4b&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw2eFVxB0pSsNR0Iwe6qkZjN">EMAIL</a>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
<td style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center"
align="center">
<table
style="margin:0 auto!important;display:table"
border="0"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
<tr>
<td>
<img src="https://ci4.googleusercontent.com/proxy/tjGrlu9I676-OpK50I2kvwkC9hWkdjxFFyQkKANdF7IHeAj-8uty2OhiPAWBMntfT4JRkswx-PF-nz9fFg_0lUz5Ughb9G6DpuoaULkZEye5lRiCVftvJqWXiHpY__jdSzE7GLWeVs-at5RBLtHyONLTW8t69AmwcRTUP5Bc8w=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/SocialWhatsapp/fm8pkl/std/0X0/SocialWhatsapp.png"
width="auto"
height="15"
class="CToWUd"
data-bit="iit">
</td>
<td>
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f85ff04ee6ee073a91722a13e3ec4cb941abe4b4542454cd1751f3fdff61d462aacb8de3c3566d8bf23f0e46c9254508a25084bfc88e640f4b"
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;letter-spacing:.03em;padding:0 0 0 10px;text-align:center;line-height:16px;text-decoration:none;text-transform:uppercase"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f85ff04ee6ee073a91722a13e3ec4cb941abe4b4542454cd1751f3fdff61d462aacb8de3c3566d8bf23f0e46c9254508a25084bfc88e640f4b&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw08yG4CzNaeXML0v5XErUdo">WHATSAPP</a>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="15">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
height="10">
&nbsp;
</td>
</tr>
<tr>
<td
style="color:#000;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif;font-size:12px;font-weight:300;letter-spacing:.03em;padding:0 20px;text-align:center;line-height:14px;text-decoration:none">
Please
note
this
is
an
automatic
email,
do
not
reply
to
this
message
directly.
</td>
</tr>
<tr>
<td style="font-size:1px"
height="48">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
height="1">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="margin:0 auto!important;width:100%"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px"
colspan="2"
height="24">
&nbsp;
</td>
</tr>
<tr>
<td align="center"
width="20%">
<table
style="margin:0 auto!important"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr
align="center">
<td
style="padding-left:10px;padding-right:5px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8ec848072a6b316afd33265755af9cc0cf268e67eeef04662afbab78275a068b09df8ffa830d9f1a41ba2e66036a22f867d3eaf203e44a66e"
rel="link noopener"
aria-label="Visit Facebook"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8ec848072a6b316afd33265755af9cc0cf268e67eeef04662afbab78275a068b09df8ffa830d9f1a41ba2e66036a22f867d3eaf203e44a66e&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw3X_RkPEvsF0KLOVM4nKzkm">
<img style="border:0;display:block;outline:0;text-decoration:none"
src="https://ci3.googleusercontent.com/proxy/dPF0gmvhUHV0jAzRhSVNzfMdfjWCR7S3XLtBtvcwGvn9Fjf_Q8rGIKg3Cj-6J7Vww6f2rvxGOudPa99fpWTeFQu1p5h5JCC3nBPypcsftLRH_BcbN5VsM0rrJJ1Xfz14uR3bKRy9csfeumdQX9lDLbngC64z=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/FB-white/fm8pkl/std/20X32/FB-white.png"
alt="Facebook"
width="10"
height="16"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td
style="padding-left:5px;padding-right:5px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8e57e96a06d38048aeb7f4f6d5633c7b6a11e87750a817af2e2076dcacc859fd144ad00473c82913b1249a7edc04b0d0a82c5d4fcd5939309"
rel="link noopener"
aria-label="Visit Twitter"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8e57e96a06d38048aeb7f4f6d5633c7b6a11e87750a817af2e2076dcacc859fd144ad00473c82913b1249a7edc04b0d0a82c5d4fcd5939309&amp;source=gmail&amp;ust=1692886769906000&amp;usg=AOvVaw1_5-4ByVisRMe1A3kEwsng">
<img style="border:0;display:block;outline:0;text-decoration:none"
src="https://ci3.googleusercontent.com/proxy/OdWoIwqGBitIXTf704T-RvmuqIkixgGUoF9UonRIlbYf1HYhoq_c6PHSp5VSviKy9lGgTxYNdO_3t4aJc-06iNNMEfRagrQhloT_ljuMkLL01xuH0_mjxoNFNMycj3OA1iiEW1xPjUwrxvtM3U2KX0WI1Lg-=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/TW-white/fm8pkl/std/40X30/TW-white.png"
alt="Twitter"
width="20"
height="15"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td
style="padding-left:5px;padding-right:5px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f88672da48cb23fc1a461f9d42cf8df7b3974c09df2c634860654cb0a40852732a7c04d91f9d69aac268f025d1730e4911cd663c0ec7b91e1f"
rel="link noopener"
aria-label="Visit Instagram"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f88672da48cb23fc1a461f9d42cf8df7b3974c09df2c634860654cb0a40852732a7c04d91f9d69aac268f025d1730e4911cd663c0ec7b91e1f&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw3qdNx63v2Czf-PVgu2NOZn">
<img style="border:0;display:block;outline:0;text-decoration:none"
src="https://ci3.googleusercontent.com/proxy/jRDPnnWKA8ZBAqUD-CV30jqyC1ZsVHObJOTANb576D4yWc3Os6ZGbnDt6EO_w_Xwrsn9McCWK1kEs6sb4MArC-Nd3fK-pb5Q6DpTdBTr5jVz6wh7F7kwEOFpLIx_q9ctoNHUo99Mr82WW5lZfpSpmvLhJsn4fFTt5iugigY=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/instagrambigg/fm8pkl/std/0X0/instagrambigg.png"
alt="Instagram"
width="17"
height="17"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td
style="padding-left:5px;padding-right:10px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8b27b92fc5245568d8f7151e2aadd3d1301e7a3821141bb7d713ec0021bd6a15dc4886bde8687a4d81590f8c8771c1a935afbc1930f0b9a28"
rel="link noopener"
aria-label="Visit YouTube"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8b27b92fc5245568d8f7151e2aadd3d1301e7a3821141bb7d713ec0021bd6a15dc4886bde8687a4d81590f8c8771c1a935afbc1930f0b9a28&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw3slactF-0XDxOLSqrEvZRE">
<img style="border:0;display:block;outline:0;text-decoration:none"
src="https://ci4.googleusercontent.com/proxy/B-3Zp_8MMIMKSOR-3U7Jk0ulA_OC1g3LQT9OWOu1O9769viOk7oVrDJVlrE9ZcnixUAr6VpjTxiNvdYx2oJpanH9v86emeWnK9QtxvkY2rPAosX_8f_oi1gdyGXiClUZFUIycpDKAXcS1p4JKnyUusjOd1FJ=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/YT-white/fm8pkl/std/48X32/YT-white.png"
alt="YouTube"
width="24"
height="16"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td
style="padding-left:5px;padding-right:10px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8743b620112302e756a759048f2b79015fe164134ab9337f0580f60b6c5f767f3fc7eab4b0005b94f8361327155015ba0a7d90502e47d1643"
rel="link noopener"
aria-label="Enter Google Play"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8743b620112302e756a759048f2b79015fe164134ab9337f0580f60b6c5f767f3fc7eab4b0005b94f8361327155015ba0a7d90502e47d1643&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw2L0iyLEJJdPyZBkwTnKmsk">
<img style="border:0;display:block;outline:0;text-decoration:none;height:19px"
src="https://ci5.googleusercontent.com/proxy/wVQQSffO0EyinKjOgIhAIKDsriSy2OQenoVo0xWHEnHAklUcQXKNWh9M47EHQvL55NQb7wH72ubkOvdxI2nNqgrb-fs8zdSUEJlJCoUocT3s0dBo-4f32A8tmMB67ehEMCNISBy6bDHAOk3KbmgaHCRT1iDWlCFz21B3OmrJLBboUO3gpg=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/NL_GooglePlay_ENG/fm8pkl/std/0x0/NL_GooglePlay_ENG.png"
alt="Google Play"
height="19"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td
style="padding-left:5px;padding-right:10px">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f8904ffedb0f55cb003e40d83ab2802f522d5cf52cd1796013544ee376e486ec779fb496798468a8a9c341b4781d2b07212896b54987093427"
rel="link noopener"
aria-label="Enter Apple Store"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f8904ffedb0f55cb003e40d83ab2802f522d5cf52cd1796013544ee376e486ec779fb496798468a8a9c341b4781d2b07212896b54987093427&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw0w1QsOg7p-tCS6IVjsmXF4">
<img style="border:0;display:block;outline:0;text-decoration:none;height:19px"
src="https://ci3.googleusercontent.com/proxy/iVz3FtOugcvhUiZGKjmXy4EQbrt_h4irEZhH0qYAbcXMs8OgR6maE3jA4ohoWl6e-mg4TMbRRE0JCD4diueSIsnhi5zQxnvYJ-6tbafRsw52JeueSpoDqrM5DAcQ2at1V8dm-WHED_7aVjQ3YKnNd2Y1rfZLnyeKse7ZUWPShPmR=s0-d-e1-ft#https://moncler-cdn.thron.com/delivery/public/image/moncler/NL_Appstore_ENG/fm8pkl/std/0x0/NL_Appstore_ENG.png"
alt="Apple Store"
height="19"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="2"
height="24">
&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #e4e4e4;font-size:1px"
colspan="2"
height="1">
&nbsp;
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="2"
height="24">
&nbsp;
</td>
</tr>
<tr>
<td colspan="2"
align="center"
width="100%">
<p
style="border:0 none;color:#000000;font-size:10px;outline:0;text-decoration:none;text-align:center;line-height:20px;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif">
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f80d224cec76161b8d2bb8e722422bdac835157acdb174f40e754277918ab728a72a4704bfad3bfab9dd3e8f8f8a99d9860c9c06f90d973af1"
style="border:0 none;color:#000000;font-size:12px;line-height:14px;outline:0;text-decoration:none;white-space:nowrap;text-align:right;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f80d224cec76161b8d2bb8e722422bdac835157acdb174f40e754277918ab728a72a4704bfad3bfab9dd3e8f8f8a99d9860c9c06f90d973af1&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw2Bxx6luMgqPvqrjm1yXU61">Privacy
Policy</a>
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="https://click.email.moncler.com/?qs=6e5f6a5934d3b9f816955b78671430ceb65fb87aa0374f9eacb3e1c2c6d42d23df31b6b0992b743b8887c777a9d1837af041d104e6b2bfe37f2c096bf723cdad"
style="border:0 none;color:#000000;font-size:12px;line-height:14px;outline:0;text-decoration:none;white-space:nowrap;text-align:right;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif"
rel="link noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://click.email.moncler.com/?qs%3D6e5f6a5934d3b9f816955b78671430ceb65fb87aa0374f9eacb3e1c2c6d42d23df31b6b0992b743b8887c777a9d1837af041d104e6b2bfe37f2c096bf723cdad&amp;source=gmail&amp;ust=1692886769907000&amp;usg=AOvVaw1_FsfVeP2V4cJaHy8W_ryR">Terms
of
Sale</a>
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="2"
height="30">
&nbsp;
</td>
</tr>
<tr>
<td align="center"
width="100%">
<p
style="border:0 none;color:#000000;font-size:10px;outline:0;text-decoration:none;text-align:center;line-height:15px;font-family:'Futuraefoplight8-regular',Helvetica,Arial,sans-serif">
&nbsp;
</p>
</td>
</tr>
<tr>
<td style="font-size:1px"
colspan="2"
height="30">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<img src="https://ci5.googleusercontent.com/proxy/qdw-S4vFJR2-cNU55WMLfBHmsOEL1MpcKLfNsor3hwQHrP8Gzy6C7x0YBJDHaGX6j4p49yE-Kosg-Fl1mynQV-jddY5SqTeCGz25fXYOf7-n5wqXqKrlitdZRPOFB8x-rlRUCFiM4L1MZjvGtXSDaKXGnijcZIYHQ_OFNXzlblmVqI9vibtZscf4hCa3xqVBVCniIZVrPPxE0Lp978S9XG9l764jD0SLjFFAsE44xZAhkOC9M8cEnE1s3ZBY4SI6AKwvnLokpQ=s0-d-e1-ft#https://click.email.moncler.com/open.aspx?ffcb10-fe9916717461077b71-fe1d127570630d78711677-fe42157075640578701471-ff3016707d61-fe2d157975620479731074-fefd1577746d04&amp;d=100176&amp;bmt=0"
alt="" width="1" height="1" class="CToWUd"
data-bit="iit">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">

</div>
</div>
</div>
<div id=":155" class="ii gt" style="display:none">
<div id=":156" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
