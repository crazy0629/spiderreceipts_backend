export const louisEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":154" tabindex="-1"></div>
<div id=":13n" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyOTEwNzI0MDU3MzEwMiIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyOTEwNzI0MDU3MzEwMiIsbnVsbCxbXV0.">
<div id=":13m" class="a3s aiL ">
<div dir="ltr" class="adM">
<div>&nbsp;</div>
<div>
<div>
<div dir="ltr">&nbsp;</div>
</div>
</div>
</div>
<div class="adM">

</div>
<div style="margin:0;padding:0;background-color:#ffffff">
<div class="adM">
</div>
<center>
<div id="m_-4949196685865757372x_container">
<table style="border-collapse:collapse;table-layout:fixed" border="0" width="100%"
cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
<tbody>
<tr>
<td align="center">
<table style="border-collapse:collapse" border="0" width="640"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20" border="0" class="CToWUd"
data-bit="iit" jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse" border="0" width="642"
cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td>
<table style="border-collapse:collapse" border="0"
width="642" cellspacing="0" cellpadding="0"
align="center" bgcolor="#F1F0EC">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
bgcolor="#F1F0EC">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="1" border="0"
class="CToWUd" data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table style="border-collapse:collapse" border="0"
width="642" cellspacing="0" cellpadding="0"
align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
bgcolor="#F1F0EC" width="1">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="1" border="0"
class="CToWUd" data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td align="center" width="640">
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td align="center">
<a href="https://en.louisvuitton.com/eng-nl/homepage"
title="LOUIS VUITTON"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://en.louisvuitton.com/eng-nl/homepage&amp;source=gmail&amp;ust=1692886073913000&amp;usg=AOvVaw0phIAsxBG2sH9oeOHYosly">
<img style="display:block"
src="https://ci4.googleusercontent.com/proxy/KwF-VHOb4sb2m69M9maAonCBEySgMn5Pp-4j6cywt0vXxXWjp8Fwfywm4wPMKzekl-kt_fn9K-Ewy0zWj_iAmcmg=s0-d-e1-ft#https://www.louisvuitton.com/images/lv_logo.png"
alt="LOUIS VUITTON"
width="214"
height="24"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F1F0EC">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top">
Dear Sir/Madam,
<br>
<br>Thank you for choosing
Louis Vuitton.
<br>
<br>We are pleased to
confirm that your order
${form?.order_number} has been
received and will be
processed accordingly.
<br>
<br>To follow the status of
your order, you may also
visit your
<a href="https://secure.louisvuitton.com/eng-nl/mylv"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://secure.louisvuitton.com/eng-nl/mylv&amp;source=gmail&amp;ust=1692886073914000&amp;usg=AOvVaw1qMpi91HWQPopd2MxShq4z">MyLV</a>
account.
</td>
</tr>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-bottom:20px;padding-top:20px">
&nbsp;</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-bottom:5px;padding-top:5px">
<strong>DETAILS OF THE
ORDER</strong>
</td>
</tr>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1" height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F6F5F3">
<tbody>
<tr>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:center;vertical-align:middle;padding-top:10px;padding-bottom:10px"
width="100">
<strong>Product</strong>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-top:10px;padding-bottom:10px;padding-left:10px"
width="300">
<strong>Description</strong>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:center;vertical-align:middle;padding-top:10px;padding-bottom:10px"
width="100">
<strong>Quantity</strong>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:right;vertical-align:middle;padding-top:10px;padding-bottom:10px;padding-right:10px"
width="100">
<strong>Price</strong>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td width="400">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
align="left">
<table
style="border-collapse:collapse"
border="0"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td id="m_-4949196685865757372x_prodImg"
align="left"
valign="middle">
<img style="max-width:100px"
src=${form?.image_link}
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table
style="border-collapse:collapse"
border="0"
width="300"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top;padding-top:10px;padding-bottom:10px"
align="left">
<span
style="color:#19110b">
<a title="#Titre1#"
style="text-decoration:none;color:#19110b"
rel="noopener">${form?.item}</a>
<br>Reference
:
${form?.style_id}
<br>Colour
:
${form?.color}
<br>
</span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td style="padding-top:10px;padding-bottom:10px"
align="center" valign="top"
width="100">
<table
style="border-collapse:collapse"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:center;vertical-align:top">
1</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" width="100">
<table
style="border-collapse:collapse;width:100%"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:right;vertical-align:middle;padding-top:10px;padding-bottom:10px;width:90%">
${form?.subtotal}
</td>
<td style="font-size:1px;line-height:1px!important;width:10%"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F6F5F3">
<tbody>
<tr>
<td valign="top" width="500">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-top:10px;padding-bottom:10px">
Subtotal
</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" width="100">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:right;vertical-align:middle;padding-top:10px;padding-bottom:10px">
${form?.subtotal}
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td valign="top" width="500">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-top:10px;padding-bottom:10px">
DELIVERY :
EXPRESS HOME
DELIVERY
</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" width="100">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:right;vertical-align:middle;padding-top:10px;padding-bottom:10px">
${form?.shipping}
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci4.googleusercontent.com/proxy/8RTd8exjlAW1lWaG_6Kw3QhSJoAbLiAH7EM4xpTVmjrbOuj3WDbprj_4mvIm8JLP0lc4yuQCFWTV8g5M_KW-Rd003j9C-APz8WRIryMI9eAit-LdDLzGWFeXvxDs=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css//images/email/spacer.gif"
width="1" height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F6F5F3">
<tbody>
<tr>
<td valign="top" width="300">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
&nbsp;</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:normal;color:#19110b;text-align:left;vertical-align:middle;padding-top:10px;padding-bottom:10px">
<strong>Total</strong>
</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" width="300">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:normal;color:#19110b;text-align:right;vertical-align:middle;padding-top:10px;padding-bottom:10px">
<strong>${form?.total}</strong>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td valign="top"
bgcolor="#FFFFFF">
<table
style="border-collapse:collapse"
border="0" width="290"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top;padding-top:10px;padding-bottom:10px;padding-left:10px"
align="left"
valign="top"
bgcolor="#FFFFFF">
<strong>Delivery
address</strong>
</td>
</tr>
<tr>
<td style="font-size:1px;line-height:1px!important"
bgcolor="#E1DFD8">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top;padding-top:10px;padding-bottom:10px;padding-left:10px"
align="left"
valign="top"
bgcolor="#FFFFFF">
${form?.full_name}
<br>${form?.street}
<br>${form?.zip} ${form?.city}
<br>${form?.country}
</td>
</tr>
</tbody>
</table>
<table
style="border-collapse:collapse"
border="0" width="290"
cellspacing="0"
cellpadding="0"
align="right"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top;padding-top:10px;padding-bottom:10px;padding-left:10px"
align="left"
valign="top"
bgcolor="#FFFFFF">
<strong>Billing
address</strong>
</td>
</tr>
<tr>
<td style="font-size:1px;line-height:1px!important"
bgcolor="#E1DFD8">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:12px;line-height:normal;color:#19110b;text-align:left;vertical-align:top;padding-top:10px;padding-bottom:10px;padding-left:10px"
align="left"
valign="top"
bgcolor="#FFFFFF">
${form?.full_name}
<br>${form?.street}
<br>${form?.zip} ${form?.city}
<br>${form?.country}
<br>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1" height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci3.googleusercontent.com/proxy/RGkHaP8w3C-giNDL8cMHpCrryL1P8iikY4yzlF2BENOb7bbg0ctpmF5S72AnnlzUVW1zzjtJaxxIB0sjmu8QB-stJph_Vzg4fwkAUL6lpOuPCrlbvJ6n9B4AwvE=s0-d-e1-ft#https://en.louisvuitton.com/static/21.22.0-RC/css/images/email/spacer.gif"
width="1" height="10"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-family:Futura,Georgia,Arial,Helvetica;font-size:12px;line-height:normal;color:#2b130f;text-align:left;vertical-align:top">
Consult our
<a href="https://en.louisvuitton.com/eng-nl/legal-privacy"
title="Terms and conditions"
style="color:#19110b"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://en.louisvuitton.com/eng-nl/legal-privacy&amp;source=gmail&amp;ust=1692886073915000&amp;usg=AOvVaw2YMBS5fuq3vMe_P1tOg_KT">
<span
style="color:#c8a985">Terms
and
conditions</span>
</a>.
<br>
<br>Should you require
information or help during
your journey please contact
our Client Services.
<br>
<br>Sincerely,
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td
style="font-family:Futura,Georgia,Arial,Helvetica;font-size:12px;line-height:normal;color:#2b130f;text-align:left;vertical-align:top">
We look forward to
continuing our journey
together soon! Warm regards,
Louis Vuitton Client
Services
<br>Should you require
information or help, please
do not hesitate to contact
our Client Services at :
<br>Austria :
<a href="tel:+43%207%20203%20800%2086"
target="_blank">+43 7
203 800 86</a>
<br>Belgium (FR language):
<a href="tel:+32%202%20626%2046%2002"
target="_blank">+32 2
626 46 02</a>
<br>Belgium (NL language):
<a href="tel:+32%202%20626%2046%2003"
target="_blank">+32 2
626 46 03</a>
<br>Denmark :
<a href="tel:+45%2035%2015%2086%2034"
target="_blank">+45 35
15 86 34</a>
<br>Finland :
<a href="tel:+358%209%208171%200681"
target="_blank">+358 9
8171 0681</a>
<br>Ireland :
<a href="tel:+353%201%20533%2099%2048"
target="_blank">+353 1
533 99 48</a>
<br>Luxembourg :
<a href="tel:+35%2022%2073%2000%20025"
target="_blank">+35 22
73 00 025</a>
<br>Monaco :
<a href="tel:+377%2093%2025%2013%2044"
target="_blank">+377 93
25 13 44</a>
<br>Sweden :
<a href="tel:+46%208%20519%20928%2037"
target="_blank">+46 8
519 928 37</a>
<br>the Netherlands :
<a href="tel:+31%2020%20721%2094%2041"
target="_blank">+31 20
721 94 41</a>
<br>
</td>
</tr>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F1F0EC">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="480" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td>
<a href="https://en.louisvuitton.com/eng-nl/magazine/articles/womens-fall-winter-2021-campaign#"
title="Women's Fall-Winter 2021 Campaign"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://en.louisvuitton.com/eng-nl/magazine/articles/womens-fall-winter-2021-campaign%23&amp;source=gmail&amp;ust=1692886073915000&amp;usg=AOvVaw1Ge55sE1UfSIdGZXzcLu4q">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/ZeMohOsLBnNrZndJwBBE1hEJk6hwP-TuCX80mssR9YB4AOQA_G1PrjaVttaUiNZy5VtOjL2syJW59Tn5tyiodv-cOfVBBQ7Q5M-JD-XucYPl_nAHXriqQNvUH4ZhTJw=s0-d-e1-ft#https://www.louisvuitton.com/images/is/image/lv/W_Fa_FW21_campaign_email_DI1"
alt="Women's Fall-Winter 2021 Campaign"
width="480"
height="223"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
<table
style="border-collapse:collapse;display:none;font-size:0;max-height:0;line-height:0"
border="0" width="300" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td>
<a href="https://en.louisvuitton.com/eng-nl/magazine/articles/womens-fall-winter-2021-campaign#"
title="Women's Fall-Winter 2021 Campaign"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://en.louisvuitton.com/eng-nl/magazine/articles/womens-fall-winter-2021-campaign%23&amp;source=gmail&amp;ust=1692886073915000&amp;usg=AOvVaw1Ge55sE1UfSIdGZXzcLu4q">
<img style="display:none"
src="https://ci5.googleusercontent.com/proxy/ZeMohOsLBnNrZndJwBBE1hEJk6hwP-TuCX80mssR9YB4AOQA_G1PrjaVttaUiNZy5VtOjL2syJW59Tn5tyiodv-cOfVBBQ7Q5M-JD-XucYPl_nAHXriqQNvUH4ZhTJw=s0-d-e1-ft#https://www.louisvuitton.com/images/is/image/lv/W_Fa_FW21_campaign_email_DI1"
alt="Women's Fall-Winter 2021 Campaign"
width="0" height="0"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="600" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="15"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td align="right">
<table
style="border-collapse:collapse"
border="0"
cellspacing="0"
cellpadding="0"
align="right">
<tbody>
<tr>
<td
style="font-size:1px;line-height:1px!important">
&nbsp;</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="10"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td
style="font-family:Futura,Georgia,Arial,Helvetica;font-size:12px;line-height:normal;color:#2b130f;text-align:left;vertical-align:middle">
&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="font-size:1px;line-height:1px!important">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="15"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table style="border-collapse:collapse"
border="0" width="640" cellspacing="0"
cellpadding="0" align="center"
bgcolor="#F1F0EC">
<tbody>
<tr>
<td align="center">
<table
style="border-collapse:collapse"
border="0" width="368"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#F1F0EC">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="10"
height="30"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-family:Futura,Georgia,Arial,Helvetica;font-size:12px;line-height:normal!important;color:#2b130f;text-align:right;vertical-align:middle"
align="right"
valign="middle"
width="348">
&nbsp;</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="10"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
<table
style="border-collapse:collapse"
border="0" width="272"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="10"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="http://en.louisvuitton.com/eng-nl/apps"
title="LV Pass"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://en.louisvuitton.com/eng-nl/apps&amp;source=gmail&amp;ust=1692886073915000&amp;usg=AOvVaw3iG6eXqSEQf_8vTiccpyzd">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/UE8PTRuZW0g4eYyRirfDvVBCK6pd2oyGftkdvaGpFduzJdc2-WxBToteoWIt_s23xunz2GGdTnUqnYBqMtdTejeaFRQBQxyoAtvREpHqErMBOlsgE4xwx_2I4gpoC7hgBJw=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_lv.png"
alt="LV Pass"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="https://www.facebook.com/LouisVuitton/"
title="Facebook"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.facebook.com/LouisVuitton/&amp;source=gmail&amp;ust=1692886073915000&amp;usg=AOvVaw3FzXT_jMbasmglFle1kj0R">
<img style="display:block"
src="https://ci4.googleusercontent.com/proxy/bwOojqRSRqzhdWyaQHbe9ysCbEpM1s0DqJYX7SjRVl7ONtFKWkOMKMHeOXlgudoTmBCtjPzv1HUGW5IDPajr0g3VYtxmBdaMnV05NEipTcD85pPUtnO340s2IX4rbR8pz-yZMEiheUs=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_facebook.png"
alt="Facebook"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="https://twitter.com/louisvuitton_en"
title="twitter"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://twitter.com/louisvuitton_en&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw39079O0SsUh2z4HYGYh-t-">
<img style="display:block"
src="https://ci6.googleusercontent.com/proxy/--oagAukmPu_8ynaMhwc03BSVpSa3_rGR35Ly7fkVFY5ZuU4kvtdhC1shmf-kMQvIyEkd9qfxYyulzwjt1bLNNaDp78SOBI-v_qMC2fyTSG08sOHMi3zoGQBm8MA5jsOZFzk8Ea_ew=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_twitter.png"
alt="twitter"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="https://www.youtube.com/louisvuitton"
title="YouTube"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.youtube.com/louisvuitton&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw1wJHbo9PF_3IfuGsPWF3Uf">
<img style="display:none"
src="https://ci6.googleusercontent.com/proxy/fDmijaceSfoKwpeU5k7uyPn1Xff0YdxbrD0opMfM_bfk_hJ0nU_JnoeMlfsfoGDxyIXrQHkl6DTSV0Q7PMSLk8fD1dbVMjLhS_uDhv_Vi9AArayiMccQsVs_OVY2VXPzfotVPl2z0g=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_youtube.png"
alt="YouTube"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="http://en.louisvuitton.com/eng-nl/la-maison/louis-vuitton-on-snapchat"
title="Snapchat"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://en.louisvuitton.com/eng-nl/la-maison/louis-vuitton-on-snapchat&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw2ifzbnOGb7Y8kO7A9QT8lA">
<img style="display:block"
src="https://ci6.googleusercontent.com/proxy/4UKJIkZWNY3wjAx-GKk_qBtdKbNM2Z_SlKTr4HJamtoN62fUDNA2JlMLoTuH2ihBiEWTjEQRCGn8RQuriE1DvHLNJ119wexk2Hwu2RFqGl_V9tcyee1ot-Mve_eLkWPaVEZo070xREY=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_snapchat.png"
alt="Snapchat"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="https://www.instagram.com/louisvuitton/"
title="instagram"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.instagram.com/louisvuitton/&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw2V0ysT5guHOe1vUbD5LWqK">
<img style="display:block"
src="https://ci6.googleusercontent.com/proxy/yoV_XI-oUXhTZdCRg_TbaxwayaoA4tVOCsiSj0jbzKU8bzyVNkXPCFln4ycY5jDoUTaE0JzJ-Q_-LxOJD9F9xycnCenMQ9qTSnArmcc9raCIsd_pAU-Pe1V_x2WSHpyxZKPTikP0wKfP=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_instagram.png"
alt="instagram"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="font-size:1px;line-height:1px!important"
width="10">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="5"
height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<a href="https://www.pinterest.com/LouisVuitton/"
title="Pinterest"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.pinterest.com/LouisVuitton/&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw2iXn8BB5ws18NXxunSdz08">
<img style="display:block"
src="https://ci4.googleusercontent.com/proxy/vXNm1_E85xilIBjhIokRo1xVRbnWfigx05qT4a94NITkH-3Og2gMHcsefAHrbRHjN7H0-pkg_-fdmaEIzPQIK9oh73MAYe2wxlWuLR_mrJbIxhz4vjn6chnBD8wAP66EHBRygC3SMlpv=s0-d-e1-ft#http://eu.louisvuitton.com/images/is/image/lv/1/LV/louis-vuitton--tpl_rs_pinterest.png"
alt="Pinterest"
width="22"
height="22"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
<table
style="border-collapse:collapse;display:none;max-height:0px;font-size:0px;line-height:0px"
border="0" width="320"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#F1F0EC">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px!important"
valign="middle">
<img style="display:none"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
alt=""
width="0"
height="0"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:1px;line-height:1px!important"
bgcolor="#F1F0EC" width="1">
<img style="display:block"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="1"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table border="0" width="640" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px">
<img style="display:block;border:0"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20" class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td style="font-family:Futura,Georgia,Arial,Helvetica;color:#000000;font-size:10px;line-height:normal"
align="center">
<span style="color:#000000">
<a href="https://en.louisvuitton.com/eng-nl/legal-privacy"
title="Legal Notice"
style="text-decoration:underline;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://en.louisvuitton.com/eng-nl/legal-privacy&amp;source=gmail&amp;ust=1692886073916000&amp;usg=AOvVaw06dg7Uqb1N6boMqJ1opK1T">
<span style="color:#000000">Legal
Notice</span>
</a> © ​2023 Louis Vuitton
<br>
<br>You may access your personal
information and modify or delete it.
<br>If needed, please send an email at:
<a href="mailto:international@contact.louisvuitton.com"
style="text-decoration:underline;color:#000000"
target="_blank">
<span
style="color:#000000">international@contact.<wbr>louisvuitton.com</span>
</a>
</span>
<br>We look forward to continuing our
journey together soon! Warm regards, Louis
Vuitton Client Services
</td>
</tr>
<tr>
<td style="font-size:1px;line-height:1px">
<img style="display:block;border:0"
src="https://ci5.googleusercontent.com/proxy/Cu1NIgCPj4jINzoKEnPLWki_dz3KUWGAPyhhNykbgSMCDuIteIKjMCJDbB2rshXD40aZK8xtn5Kl_kxjRNM38WaAtZmiL7FhxmU71pOZjdcHbw=s0-d-e1-ft#https://www.louisvuitton.com/static/css/images/email/spacer.gif"
width="1" height="20" class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</center>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">


</div>
</div>
</div>
<div id=":150" class="ii gt" style="display:none">
<div id=":14z" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
