export const ssenseEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":18m" tabindex="-1"></div>
<div id=":15s" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyOTgzNDcwODAyMzAxOSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzMjk0NjE4NzUwNjU5MCIsbnVsbCxbXV0.">
<div id=":19g" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div>
<div class="adM">
</div>
<div class="gmail_quote">
<div class="adM">
<br>
</div><u></u>
<div
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;height:100%;margin:0px;padding:0px;width:100%!important">
<span
style="font-size:1px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;color:#ffffff">Thank
you for shopping at SSENSE. Please allow us up to two business days to process your
order. You’ll find a copy of your receipt and order information.</span>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;border-bottom-style:solid;border-bottom-width:1px;margin:0px auto 60px;padding:30px 0px 25px;display:block!important;max-width:600px!important;clear:both!important;border-bottom-color:#f0efee"
bgcolor="#FFFFFF">
<div
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:600px;display:block;margin:0px auto;padding:0px">
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:33%;margin:0px;padding:0px">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCs9ecyoBKXfihHUQLAdRkY8Ctg3dHAqf6udNOqHDSdeDvKz5-2B04Kiup82-2BfhRyedxWpUcT0b4qFyHe8syiWD6tZXPW8l8LX01F8f7c2bF6ngp1cxiHgE-2BgpPZmoT9eq8e6dxymC6qrUlV4s-2BW1Roz27IUCK_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2BxlSgOvoe0OkYim-2Bc-2BjxI0iWyQVJG92UmZo1yO9jsIT939CgvVgGm0vDmYYajQVxTQVUd93OmBP2lKr1jezVCRiR02sUSBdMWpFMZTMvJhutlkvsn7tUEE1gJ3yOxe3nsZjgEgAFyEZA334Wc7T-2BlA-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-transform:uppercase;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCs9ecyoBKXfihHUQLAdRkY8Ctg3dHAqf6udNOqHDSdeDvKz5-2B04Kiup82-2BfhRyedxWpUcT0b4qFyHe8syiWD6tZXPW8l8LX01F8f7c2bF6ngp1cxiHgE-2BgpPZmoT9eq8e6dxymC6qrUlV4s-2BW1Roz27IUCK_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2BxlSgOvoe0OkYim-2Bc-2BjxI0iWyQVJG92UmZo1yO9jsIT939CgvVgGm0vDmYYajQVxTQVUd93OmBP2lKr1jezVCRiR02sUSBdMWpFMZTMvJhutlkvsn7tUEE1gJ3yOxe3nsZjgEgAFyEZA334Wc7T-2BlA-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw0LAuAkMwX76WKwSEM438b5">MY
ACCOUNT</a>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:33%;margin:0px;padding:0px"
align="center">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNdrLYzsQoju7wuRri2LyLjS4HnmRmxtv14UQ-2FrjztBqHaWvo-2BfyJBTEAQye8FzVe1VTimGV-2FRaAHAplBc5QIOGT5EPvCvJyIlzsINbePE0Z8YJS0gsTBsf-2BSAQbQhYtKwY886DD3btn8PpQkVSesZPX0-3DSPlQ_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs0a-2F3m8RC2-2FQcqGfRtJ1V97HKnLFffSJB9vPFnWn-2FPzUxhD9BM6WfDJyr45AAtsadAKNNDoR2uBeqSUah7Lu7rBPHRfKASx6yDSeJZbcsA1qm52p-2B-2FAVhiDih09uXx379gs-2B7hcnu-2F-2F4i2AvV-2FqUWXo-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-transform:uppercase;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNdrLYzsQoju7wuRri2LyLjS4HnmRmxtv14UQ-2FrjztBqHaWvo-2BfyJBTEAQye8FzVe1VTimGV-2FRaAHAplBc5QIOGT5EPvCvJyIlzsINbePE0Z8YJS0gsTBsf-2BSAQbQhYtKwY886DD3btn8PpQkVSesZPX0-3DSPlQ_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs0a-2F3m8RC2-2FQcqGfRtJ1V97HKnLFffSJB9vPFnWn-2FPzUxhD9BM6WfDJyr45AAtsadAKNNDoR2uBeqSUah7Lu7rBPHRfKASx6yDSeJZbcsA1qm52p-2B-2FAVhiDih09uXx379gs-2B7hcnu-2F-2F4i2AvV-2FqUWXo-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw20ST2Ak-TubibisKeoz26f">
<img style="height:21px;width:104px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;margin:0px;padding:0px"
src="https://ci5.googleusercontent.com/proxy/50t0CVgJpryYfPPUjG7_VGy7KAFlfeyu4CDgrcyIAgBjPCAmEBGITHmQ3fuZ_TyeKNbGBPAtI3N-e7Mi9GSatmPN_2QhASJQ6auI8FIDOY7Yo64IbRMO6ZfnWypwt88wGpXKYAIByA=s0-d-e1-ft#https://res.cloudinary.com/ssenseweb/image/upload/v1471963917/web/ssense_logo_v2.png"
class="CToWUd" data-bit="iit">
</a>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:33%;margin:0px;padding:0px"
align="right">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3D9nCg_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsxENozD8a1iqVQg3eZ8HlqXicGuhPWKlweVxrYPDgJFBK7h7gW3rSzMq4vrxiYGS-2BjUFQkdC4-2F0sElnDniL0Zu-2BIhuGBYQ5FaCnP1V-2B4RrtVjRLUG4BSj1J84Q4nUtwYRNs-2FLCMCJ4JC5ZnzTgG-2BQBw-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;text-decoration:none;text-transform:uppercase;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3D9nCg_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsxENozD8a1iqVQg3eZ8HlqXicGuhPWKlweVxrYPDgJFBK7h7gW3rSzMq4vrxiYGS-2BjUFQkdC4-2F0sElnDniL0Zu-2BIhuGBYQ5FaCnP1V-2B4RrtVjRLUG4BSj1J84Q4nUtwYRNs-2FLCMCJ4JC5ZnzTgG-2BQBw-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw3lIoxUMNtP7Q6-zcMdaIUg">CUSTOMER
SUPPORT</a>
</td>
</tr>
</tbody>
</table>
</div>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px auto;padding:0px;display:block!important;max-width:600px!important;clear:both!important"
bgcolor="#FFFFFF">
<div
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:600px;display:block;margin:0px auto;padding:0px">
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<h3 style="font-family:'Helvetica Neue',Helvetica,Arial,'Lucida Grande',sans-serif;line-height:1.1;font-size:24px;text-align:center;margin:0px 0px 40px;padding:0px;color:#000000"
align="center">Order Confirmation</h3>
<p
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:normal;font-size:13px;line-height:25px;margin:0px 0px 10px;padding:0px">
Dear
<strong
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">${form?.full_name}</strong>,
</p>
<p
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:normal;font-size:13px;line-height:25px;margin:0px 0px 10px;padding:0px">
Thank you for shopping at SSENSE. Please allow
us up to two business days to process your
order. Once it’s been processed, you’ll receive
a shipment confirmation email with your order’s
tracking number.</p>
<br
style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;margin:0;padding:0">
<p
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:normal;font-size:13px;line-height:25px;margin:0px 0px 10px;padding:0px">
Below, you’ll find a copy of your receipt and
order information. Please keep it for your
records.</p>
<br
style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;margin:0;padding:0">
<p
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:normal;font-size:13px;line-height:25px;margin:0px 0px 10px;padding:0px">
If you have any questions regarding your order,
please visit our
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0Kutqzb-2FJaMNDVDIUTyFI-2BnZGvZk5tEs-2Bd964ou4aUtjvWsGZeOkfM8AKmzCaZ3D4uriFccFhkN2XzpGpwfGhYQVq586ltYNp6w9cYt5oGNYIxKOsN8gFXRfL1RdlxAue-2BxRch_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs21JHXRYnrTtF6DdNSw4HfOLbanv9E8obkhCIAcdTkT3hPlB49LQj5VRlub-2BNopH-2FjhLDA6V50yAXF-2BiaqjmZv2Bk68eN7uXONNxDLfxAfzKh8K3FFiqfhsqqvtjFtVf2NZcUEIoTKS-2FKUxVcoNWtbI-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0Kutqzb-2FJaMNDVDIUTyFI-2BnZGvZk5tEs-2Bd964ou4aUtjvWsGZeOkfM8AKmzCaZ3D4uriFccFhkN2XzpGpwfGhYQVq586ltYNp6w9cYt5oGNYIxKOsN8gFXRfL1RdlxAue-2BxRch_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs21JHXRYnrTtF6DdNSw4HfOLbanv9E8obkhCIAcdTkT3hPlB49LQj5VRlub-2BNopH-2FjhLDA6V50yAXF-2BiaqjmZv2Bk68eN7uXONNxDLfxAfzKh8K3FFiqfhsqqvtjFtVf2NZcUEIoTKS-2FKUxVcoNWtbI-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw0z4FG9oN_FeYJIQG_2a2cl">help
page</a>, or
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3Dqvwj_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsx2HcpI6K8OcgZAqmAHro1dTKXcwOA4fxzso-2BB9FQIymYAbCBMxhaQGkDZO3g00LL4nUJyg62qi-2FNAdXvYTO2sFDvhbtku0pznKcKWuAzkxduzug2sW-2B6SuK-2B76bFcLwaCZ-2FoiKtKzg3PGrn3130AYA-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3Dqvwj_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsx2HcpI6K8OcgZAqmAHro1dTKXcwOA4fxzso-2BB9FQIymYAbCBMxhaQGkDZO3g00LL4nUJyg62qi-2FNAdXvYTO2sFDvhbtku0pznKcKWuAzkxduzug2sW-2B6SuK-2B76bFcLwaCZ-2FoiKtKzg3PGrn3130AYA-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw17XevKmCbC_xHumNCMX2En">contact
us</a> at
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0Kutqzb-2FJaMNDVDIUTyFI-2BnZGvZk5tEs-2Bd964ou4aUtjvWsGZeOkfM8AKmzCaZ3D4uriFccFhkN2XzpGpwfGhYQVq586ltYNp6w9cYt5oGNYIxKOsN8gFXRfL1RdlxAue-2BqcZu_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2Fhtq-2FVGYrbGEMPFwVCaIq4-2BZ-2FPkTYLF9XWd9uXi2T7nXpSKAjpp74sVvMh7J59FsyB-2BTLlV0sXlwRUk4-2B-2F8O6kq35Sguy2L-2FLhCQEEcxo0Q8J4ycZgjNOqz5TOzqxaNdd4b55hn3m-2FeQGcfkYRQHO0-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;margin:0px;padding:0px;color:#000000"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0Kutqzb-2FJaMNDVDIUTyFI-2BnZGvZk5tEs-2Bd964ou4aUtjvWsGZeOkfM8AKmzCaZ3D4uriFccFhkN2XzpGpwfGhYQVq586ltYNp6w9cYt5oGNYIxKOsN8gFXRfL1RdlxAue-2BqcZu_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2Fhtq-2FVGYrbGEMPFwVCaIq4-2BZ-2FPkTYLF9XWd9uXi2T7nXpSKAjpp74sVvMh7J59FsyB-2BTLlV0sXlwRUk4-2B-2F8O6kq35Sguy2L-2FLhCQEEcxo0Q8J4ycZgjNOqz5TOzqxaNdd4b55hn3m-2FeQGcfkYRQHO0-3D&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw2P5BX0dzRP-W86ZUoD47wo">ssense.com/customer-service</a>.
We are open 24 hours a day, 7 days a week.
<br
style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;margin:0;padding:0">Toll-free
number (US and Canada): +1 877 637 6002
</p>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-align:left;font-weight:normal;margin:40px 0px;padding:0px;width:auto!important">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:600;font-size:14px;margin:0px;padding:0px 10px 15px 0px;color:#000000">
Order Number</th>
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:600;font-size:14px;margin:0px;padding:0px 10px 15px 0px;color:#000000">
${form?.order_number}</th>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
Date Placed:</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;margin:0px;padding:0px 10px 5px 0px">
${form?.order_date}</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
Order Total:</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;margin:0px;padding:0px 10px 5px 0px">
${form?.total}</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-align:left;font-weight:normal;margin:40px 0px;padding:0px;width:100%!important">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;text-transform:uppercase;font-weight:400;letter-spacing:0.4px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
PAYMENT METHOD</th>
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;text-transform:uppercase;font-weight:400;letter-spacing:0.4px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
SHIPPING METHOD</th>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.payment_method}</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
express</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-align:left;font-weight:normal;margin:40px 0px;padding:0px;width:100%!important">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;text-transform:uppercase;font-weight:400;letter-spacing:0.4px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
BILLING ADDRESS</th>
<th
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;text-transform:uppercase;font-weight:400;letter-spacing:0.4px;margin:0px;padding:0px 10px 5px 0px;color:#444444">
SHIPPING ADDRESS</th>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
<a href="https://www.google.com/maps/search/654B+Fort+Evans+Road+NE++APT+207+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++Leesburg+,+Virginia+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++United+States,+20176?entry=gmail&amp;source=g"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/654B%2BFort%2BEvans%2BRoad%2BNE%2B%2BAPT%2B207%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BLeesburg%2B,%2BVirginia%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BUnited%2BStates,%2B20176?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692889736469000&amp;usg=AOvVaw2QKxsPHF7XqCKfO38Z6s-2"></a>
<a href="https://www.google.com/maps/search/654B+Fort+Evans+Road+NE++APT+207+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++Leesburg+,+Virginia+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++United+States,+20176?entry=gmail&amp;source=g"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/654B%2BFort%2BEvans%2BRoad%2BNE%2B%2BAPT%2B207%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BLeesburg%2B,%2BVirginia%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BUnited%2BStates,%2B20176?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw0Atb3MgLTt1tnBSuQwkFND"></a>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.full_name}
</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.street}</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.city},
${form?.zip}
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.country}
</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
<br>
</td>
</tr>
</tbody>
</table>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
<a href="https://www.google.com/maps/search/654B+Fort+Evans+Road+NE++APT+207+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++Leesburg+,+Virginia+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++United+States,+20176?entry=gmail&amp;source=g"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/654B%2BFort%2BEvans%2BRoad%2BNE%2B%2BAPT%2B207%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BLeesburg%2B,%2BVirginia%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BUnited%2BStates,%2B20176?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw0Atb3MgLTt1tnBSuQwkFND"></a>
<a href="https://www.google.com/maps/search/654B+Fort+Evans+Road+NE++APT+207+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++Leesburg+,+Virginia+%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++%0D%0A+++++++++++++++++++++++++++++++++++++++++++++++++United+States,+20176?entry=gmail&amp;source=g"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/654B%2BFort%2BEvans%2BRoad%2BNE%2B%2BAPT%2B207%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BLeesburg%2B,%2BVirginia%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%250D%250A%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2B%2BUnited%2BStates,%2B20176?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw0Atb3MgLTt1tnBSuQwkFND"></a>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.full_name}
</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.street}</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.city},
${form?.zip}
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
&nbsp;</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
${form?.country}
</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;width:50%;margin:0px;padding:0px 10px 5px 0px;color:#000000">
&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;text-align:left;font-weight:normal;border-collapse:collapse;margin:40px 0px 15px;padding:0px;width:100%!important">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;border-bottom-width:1px;border-bottom-style:solid;margin:0px;padding:0px;border-bottom-color:#dddddd">
<th style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:0.4px;width:20%;margin:0px;padding:0px 0px 5px;color:#000000"
valign="top">ITEMS</th>
<th style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:0.4px;width:50%;margin:0px;padding:0px 0px 5px;color:#000000"
valign="top">DESCRIPTION</th>
<th style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:0.4px;width:15%;margin:0px;padding:0px 0px 5px;color:#000000"
valign="top">SIZE</th>
<th style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:0.4px;width:15%;text-align:right;margin:0px;padding:0px 0px 5px;color:#000000"
align="right" valign="top">PRICE
</th>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;border-bottom-width:1px;border-bottom-style:solid;margin:0px;padding:0px;border-bottom-color:#dddddd">
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;width:20%;margin:0px;padding:15px 0px;color:#000000"
valign="top">
<img style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;width:70%;margin:0px 0px 0px 15%;padding:0px"
src=${form?.image_link}
alt="" class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;width:50%;margin:0px;padding:15px 0px;color:#000000"
valign="top">${form?.item}
<br
style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;margin:0;padding:0">
<em>${form?.style_id}</em>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;width:15%;margin:0px;padding:15px 0px;color:#000000"
valign="top">${form?.size}
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;vertical-align:top;font-size:11px;width:15%;text-align:right;margin:0px;padding:15px 0px;color:#000000"
align="right" valign="top">
<span
style="white-space:nowrap">${form?.subtotal}</span>
</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;font-size:11px;border-collapse:collapse;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
Shopping Bag Total</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
1 Item</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;text-align:right;margin:0px;padding:0px 0px 15px"
align="right">${form?.subtotal}
</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
Shipping Total</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
&nbsp;</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;text-align:right;margin:0px;padding:0px 0px 15px"
align="right">${form?.shipping}</td>
</tr>
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
Taxes</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;margin:0px;padding:0px 0px 15px">
<br>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:auto;text-align:right;font-weight:bold;margin:0px;padding:0px 0px 15px"
align="right">${form?.taxes}</td>
</tr>
</tbody>
</table>
<table
style="margin:0px;padding:0px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:11px;border-collapse:collapse;width:100%">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="margin:0px;padding:0px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<td
style="margin:0px;padding:20px 0px 15px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:60%;font-weight:bold">
Order total:</td>
<td
style="margin:0px;padding:20px 0px 15px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:40%;text-align:right;font-weight:bold">
${form?.total}</td>
</tr>
</tbody>
</table>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:40px 0px 0px;padding:0px">
<tbody style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;border-bottom-style:solid;border-bottom-width:1px;border-top-width:1px;border-top-style:solid;text-align:center;text-transform:uppercase;margin:0px auto;padding:30px 0px 25px;display:block!important;max-width:600px!important;clear:both!important;border-top-color:#f0efee;border-bottom-color:#f0efee"
align="center" bgcolor="#FFFFFF">
<div
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:600px;display:block;margin:0px auto;padding:0px">
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:30%;margin:0px;padding:0px">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCtf6mU3R0q636w8LR76N96GSRdCXay6xCh-2FSEWX0MZQ9sFSwllGZvbWImC7otu73xcEgvDSrD8s7OaVGykDDuwENfk-2FlslA5B98ubCphjVFd46D5rAAJu-2F7Gw7ZrhdQExpPr2aQ67k-2F4Bw0q-2FYkJMdGmqyv_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs5lVeYtL4d0NyNP88gIQ46950ekVoQsxgF6gUcCXZ3AaaCoYFQsw3jKlnJQrGBD-2Fw-2BOxFFAgBObutZDLa5ctpCauON3iKkgRrpLmA0Q0gpTsqGHC-2BSa1ySHRyGDtK3s9AHA8UvCfl6phPtbr6Axkdi0-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCtf6mU3R0q636w8LR76N96GSRdCXay6xCh-2FSEWX0MZQ9sFSwllGZvbWImC7otu73xcEgvDSrD8s7OaVGykDDuwENfk-2FlslA5B98ubCphjVFd46D5rAAJu-2F7Gw7ZrhdQExpPr2aQ67k-2F4Bw0q-2FYkJMdGmqyv_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs5lVeYtL4d0NyNP88gIQ46950ekVoQsxgF6gUcCXZ3AaaCoYFQsw3jKlnJQrGBD-2Fw-2BOxFFAgBObutZDLa5ctpCauON3iKkgRrpLmA0Q0gpTsqGHC-2BSa1ySHRyGDtK3s9AHA8UvCfl6phPtbr6Axkdi0-3D&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw1LmKcusjzVapX0nRMbuFev">SHOP
MEN</a>
</td>
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px"
align="center">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNdkOs-2FYbWuoVwak1SfsuvibNSNAWgA0FvXEpqpA-2B5oGGdhXbq_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsxypQjkoNIGlv5wCUYIDzU-2BrZhyKdbGaa3fT-2Bsu-2Bo8REqMeaSVYBUgSNwUxAe757LwypLKXu0jyMgIQM0OdLTUILPAWQrVn6-2F-2FbYhLfy4K7qfKJY3VhhYmCkc92aWKPhYBz9mx0-2B7SpIPFuFnHsmlHI-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNdkOs-2FYbWuoVwak1SfsuvibNSNAWgA0FvXEpqpA-2B5oGGdhXbq_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWsxypQjkoNIGlv5wCUYIDzU-2BrZhyKdbGaa3fT-2Bsu-2Bo8REqMeaSVYBUgSNwUxAe757LwypLKXu0jyMgIQM0OdLTUILPAWQrVn6-2F-2FbYhLfy4K7qfKJY3VhhYmCkc92aWKPhYBz9mx0-2B7SpIPFuFnHsmlHI-3D&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw3apfRP_zPijYRibDpIs1UE">
<img style="height:20px;width:20px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;margin:0px;padding:0px"
src="https://ci5.googleusercontent.com/proxy/SB5u7nXfrmBb00wXvH2GBZLK9deFL0eAkCZUmj_P3QB7OH0mRfkYMkAcnZ_qdxhUniyCIMyo-JB6MOyPEtqfJd2PpkiuHYmSCSYcjYNqoYFpB_-yhuqCLWOqDg=s0-d-e1-ft#https://img.ssensemedia.com/image/upload/v1564155482/social/facebook.png"
class="CToWUd" data-bit="iit">
</a>
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNdmm4dUmi7RxQIJiU49xw8fvWH0IEcGvS8xHWp1yan8-2Bhov3k_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2FXAv6zYcQWGPB0N3S1oUEXI6uaLE-2BXSG0VAWQIYbtYeeztLa8IgguB8ByjpBX87vwBmJIET1nc9xZqprgHmvOiRT00keTGs2IxDDKKo85UzD1Ru2v5Z1oi3bCn2AHWzOIMNW4zs1CJAkwPYuoosANc-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px 0px 0px 5px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNdmm4dUmi7RxQIJiU49xw8fvWH0IEcGvS8xHWp1yan8-2Bhov3k_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs-2FXAv6zYcQWGPB0N3S1oUEXI6uaLE-2BXSG0VAWQIYbtYeeztLa8IgguB8ByjpBX87vwBmJIET1nc9xZqprgHmvOiRT00keTGs2IxDDKKo85UzD1Ru2v5Z1oi3bCn2AHWzOIMNW4zs1CJAkwPYuoosANc-3D&amp;source=gmail&amp;ust=1692889736470000&amp;usg=AOvVaw2q-sznoe2aXnf8hjhYFzpv">
<img style="height:20px;width:20px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;margin:0px;padding:0px"
src="https://ci4.googleusercontent.com/proxy/0a77Rx8hTInkRmZ2jXTf1XZd7kbvPOea93Ua0-nxbTELxe2PpgSnu6ID7a66qUe7UhnzXm4OQaAo0w1VMKjUo8ax9M2KNWYa82_lkp5LMaWhI2nJ7li04GRU=s0-d-e1-ft#https://img.ssensemedia.com/image/upload/v1564155685/social/twitter.png"
class="CToWUd" data-bit="iit">
</a>
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=8TQM2hAFvPUNfTfL5PkSUMXMUoAag-2FjbbNOX2XtxoE00w3zk-2BF3US5iKdaJ95wfB02IA_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWswQmKOVfEWqbk76Z7YigluKHEaNE4WRiLD9aC28xaiCNA1j5-2Bz-2BF7mDumW-2FPVX7wRpu0MZ1RmnPFkvVN4Z9mzyEwJpllpEyw661zV2REMr0EtWwGU5WPD9kFDbNgGLeQuZusWQ3rf9Do5EppTNoepJ4-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px 0px 0px 5px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3D8TQM2hAFvPUNfTfL5PkSUMXMUoAag-2FjbbNOX2XtxoE00w3zk-2BF3US5iKdaJ95wfB02IA_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWswQmKOVfEWqbk76Z7YigluKHEaNE4WRiLD9aC28xaiCNA1j5-2Bz-2BF7mDumW-2FPVX7wRpu0MZ1RmnPFkvVN4Z9mzyEwJpllpEyw661zV2REMr0EtWwGU5WPD9kFDbNgGLeQuZusWQ3rf9Do5EppTNoepJ4-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw2o7iNhygKvXTomxLenscyY">
<img style="height:20px;width:20px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;margin:0px;padding:0px"
src="https://ci6.googleusercontent.com/proxy/_pwf5YQWXsi6FVTkNU2_lZaDdlgbQgl1cDfeI0TkqDzIgX-XxUIsAectEXH6L_cUeIkwg_bqSc198bYLG2cFncNOh4Gc8kSQobnp_MWnv0PQoH6aAabUGeylRks=s0-d-e1-ft#https://img.ssensemedia.com/image/upload/v1564156575/social/pinterest.png"
class="CToWUd" data-bit="iit">
</a>
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=MtRKrwAgOYEj4fNHP-2BX93byzBVWXkME5dCzVxH9L1yVHVRd-2FRUNbAcNyEPn82i5daJnA_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs0MsYBK7CHh1UEuJUS4hGA6mrQgdKqzZu6jYfXlhGy-2FQzDCVGpjsI3TNtPzdG3tS-2Bvucl1f5sqcpFMwai6ypw1c2ZavhsPST4gn0TYTsSztprc1OYc875CFxQJI7Phzi11s3qOBZy-2FkMWXX7zcvZtpc-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px 0px 0px 5px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DMtRKrwAgOYEj4fNHP-2BX93byzBVWXkME5dCzVxH9L1yVHVRd-2FRUNbAcNyEPn82i5daJnA_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs0MsYBK7CHh1UEuJUS4hGA6mrQgdKqzZu6jYfXlhGy-2FQzDCVGpjsI3TNtPzdG3tS-2Bvucl1f5sqcpFMwai6ypw1c2ZavhsPST4gn0TYTsSztprc1OYc875CFxQJI7Phzi11s3qOBZy-2FkMWXX7zcvZtpc-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw0vyHS7cOR1PqlKUdvixcLQ">
<img style="height:20px;width:20px;font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:100%;margin:0px;padding:0px"
src="https://ci6.googleusercontent.com/proxy/85IQORlTuoRmiMN6XL52aqCjQTFjVtwMmdxJGCPBTc9khS4qEXzBnkzJSBVWffhev9X4aJwXo_QeNR_-fm_CABn1y25NlRmF8NYnmQ7gkc9qyS3sWrkZ6f_ZyJI=s0-d-e1-ft#https://img.ssensemedia.com/image/upload/v1564155572/social/instagram.png"
class="CToWUd" data-bit="iit">
</a>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:30%;margin:0px;padding:0px">
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCsBIVQHWAp92mcFSOFsUg0exuiBXT2QauwnMcC-2Fn4w2LrYyZOP4i5SRgvv23DlNGqcOHiOZy2qLSsWdfE5cXcvufd0-2BOKL8RRgXLPYbJ1STLUK9W1TJ32-2BgV9woAeu68f-2BqQq2xJ-2BH0vbMY1tMpftPb4gB3_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWswQWrzlYte0Kk5fS3e-2Br1x-2B04JWkQykthY3SCXWcur49gahv-2B3L8lKSaOFfZGNXkxUPmUxVtZkQByWUzsHF2LUhhqJs2F44TBbQa7GJr-2FLoB3qmBRdRN12ly-2FTZLvxt9CqvrwsMaQSsRksB7bq3wFeY-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-weight:400;font-size:12px;text-decoration:none;margin:0px;padding:0px;color:#777777"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCsBIVQHWAp92mcFSOFsUg0exuiBXT2QauwnMcC-2Fn4w2LrYyZOP4i5SRgvv23DlNGqcOHiOZy2qLSsWdfE5cXcvufd0-2BOKL8RRgXLPYbJ1STLUK9W1TJ32-2BgV9woAeu68f-2BqQq2xJ-2BH0vbMY1tMpftPb4gB3_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWswQWrzlYte0Kk5fS3e-2Br1x-2B04JWkQykthY3SCXWcur49gahv-2B3L8lKSaOFfZGNXkxUPmUxVtZkQByWUzsHF2LUhhqJs2F44TBbQa7GJr-2FLoB3qmBRdRN12ly-2FTZLvxt9CqvrwsMaQSsRksB7bq3wFeY-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw3w4rYM4Z_95YYM0YdeJVt7">SHOP
WOMEN</a>
</td>
</tr>
</tbody>
</table>
</div>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
</tr>
</tbody>
</table>
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;text-align:left;margin:60px 0px 30px;padding:0px;clear:both!important">
<tbody style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px auto;padding:0px;display:block!important;max-width:600px!important;clear:both!important">
<div
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;max-width:600px;display:block;margin:0px auto;padding:0px">
<table
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;width:100%;margin:0px;padding:0px">
<tbody
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif">
<tr
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
<td style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px"
align="center">
<p style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;line-height:1.3;text-align:center;font-weight:normal;margin:0px 0px 10px;padding:0px;color:#969697"
align="center">
<span
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">Copyright
© 2023 All rights
reserved</span>&nbsp;&nbsp;
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCsSduFf4M6OGlxGX7x3gPk1CHj0PwxcsAE-2BaFFRPI-2BgTtsYv9A-2BH-2F97Hmhie4SOL-2B3SJktSPtEGgUZX5raIMzxPsSj-2BJ5QlFU9cBVA5cZLUiZ6qQ-2F02BhTiEFpePHnmh3J8gKTLjuA0GMwyj-2B-2FCR9ykQ-Zf_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs8s5eh3DuEUVhpYIPJjNm2UmYBOIIKkGWdzZZfO0jdryQboGNGxSYMy4yP2R8iLgYMhsnI-2FB0iqkXmb0eXY5ZvHoOHwO0AqPjXBRAlHKVPgBWgjt-2BYcL3Hnjb-2Fy6ItCvc2mTJ0J3daxD-2Bun8H1XHZzU-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px;color:#969697"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCsSduFf4M6OGlxGX7x3gPk1CHj0PwxcsAE-2BaFFRPI-2BgTtsYv9A-2BH-2F97Hmhie4SOL-2B3SJktSPtEGgUZX5raIMzxPsSj-2BJ5QlFU9cBVA5cZLUiZ6qQ-2F02BhTiEFpePHnmh3J8gKTLjuA0GMwyj-2B-2FCR9ykQ-Zf_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs8s5eh3DuEUVhpYIPJjNm2UmYBOIIKkGWdzZZfO0jdryQboGNGxSYMy4yP2R8iLgYMhsnI-2FB0iqkXmb0eXY5ZvHoOHwO0AqPjXBRAlHKVPgBWgjt-2BYcL3Hnjb-2Fy6ItCvc2mTJ0J3daxD-2Bun8H1XHZzU-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw0esFUK7qK_mj_Tr8aS3FrH">Privacy
Policy</a>&nbsp;&nbsp;
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCvnARFP0owB3Auqdy9JXgEm3mdB2HyOfj0FGG5djbPLV3JTrioIgZzQg936rIiIbBcty0A-2Fwo3f7Tltod8o9-2B6hKlq301YRontxqYbOfRGQw11UbVDgXroMdRD-2FBS6JdTd5F0USNtktQDJr3JrDvY08Sfxx_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs8gYYllRRpWNjm7HSaub4pzDG0gfi8dUh452eSY5-2Bnp6tfAmcu2nZ4inldJ31-2FOwQUVXygtI-2Bo6D-2BFDU4pkZdHi4gZLii35FMl2dmKoQirVEdzG9G1fRPMImmpVbXm1jg9EMTatEI7PMJiMm-2BpWrfUE-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px;color:#969697"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCvnARFP0owB3Auqdy9JXgEm3mdB2HyOfj0FGG5djbPLV3JTrioIgZzQg936rIiIbBcty0A-2Fwo3f7Tltod8o9-2B6hKlq301YRontxqYbOfRGQw11UbVDgXroMdRD-2FBS6JdTd5F0USNtktQDJr3JrDvY08Sfxx_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs8gYYllRRpWNjm7HSaub4pzDG0gfi8dUh452eSY5-2Bnp6tfAmcu2nZ4inldJ31-2FOwQUVXygtI-2Bo6D-2BFDU4pkZdHi4gZLii35FMl2dmKoQirVEdzG9G1fRPMImmpVbXm1jg9EMTatEI7PMJiMm-2BpWrfUE-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw12e_1xrPUJ68WsfqTIW_tF">Terms
&amp; Conditions</a>
</p>
<p style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;line-height:1.3;text-align:center;font-weight:normal;margin:0px 0px 10px;padding:0px;color:#969697"
align="center">SSENSE,
<a href="https://www.google.com/maps/search/100+Crosby+Street,+Suite+306,+New+York,+NY,+10012,+USA?entry=gmail&amp;source=g"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.google.com/maps/search/100%2BCrosby%2BStreet,%2BSuite%2B306,%2BNew%2BYork,%2BNY,%2B10012,%2BUSA?entry%3Dgmail%26source%3Dg&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw1LNaX70SH_3mk-ZX45sFKV">100
Crosby Street, Suite 306, New York, NY,
10012, USA</a>
</p>
<p style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;font-size:12px;line-height:1.3;text-align:center;font-weight:normal;margin:0px 0px 10px;padding:0px;color:#969697"
align="center">Having trouble viewing this
e-mail?
<a href="https://u1333494.ct.sendgrid.net/ls/click?upn=JQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3DtsMT_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs6-2FhUnzSrYPPz5dDcmrswn1rphY9X5AvhwWI35UlDhNFJgquWRUGN1vTxOBK43DzZXpxnyKvcos6na37tGq9-2BPUdl6rgMZHBFT7uBg67VMByHzjoygQiBQ7sMn4wUDlYMj5BtPY2WkMmJuyIZEvlrO0-3D"
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px;color:#969697"
rel="noopener" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://u1333494.ct.sendgrid.net/ls/click?upn%3DJQvzd8L7h9Rt6-2BhZr0gNduUKnK3JF0-2Bqgrl-2FXvMxzCswQXwkPBCCQJnSZ3sIYh0K6A7CU41xazacdOdACpbP0S4h-2BmOCToHEXbpTO7Czy8KSNoO7M15LyBO-2F-2FNbL5MUphwcUwbGfyzU7mGWKi6GPPr5UwkeTZEVx-2B-2FwF49DggcS7cQ23fz-2Fwxx9gN-2BNZKIwe06wydSe1T6GxeBpbbTq0Ag-3D-3DtsMT_GptQX16N64WwKT5la58D1utT268Ff8ocRkKwFrHHzcZJP8IAB3EJwFBQg0Vze4mnjVrV2nqvlw0faJl-2BUqNWs6-2FhUnzSrYPPz5dDcmrswn1rphY9X5AvhwWI35UlDhNFJgquWRUGN1vTxOBK43DzZXpxnyKvcos6na37tGq9-2BPUdl6rgMZHBFT7uBg67VMByHzjoygQiBQ7sMn4wUDlYMj5BtPY2WkMmJuyIZEvlrO0-3D&amp;source=gmail&amp;ust=1692889736471000&amp;usg=AOvVaw0O33Wqg6s3-hLxRik1mX5Y">Click
Here</a>
</p>
</td>
</tr>
</tbody>
</table>
</div>
</td>
<td
style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;margin:0px;padding:0px">
&nbsp;</td>
</tr>
</tbody>
</table>
<img style="font-family:'Helvetica Neue',Helvetica,Helvetica,Arial,sans-serif;height:1px!important;width:1px!important;border-width:0px!important;margin:0px!important;padding:0px!important"
src="https://ci6.googleusercontent.com/proxy/ScP9TnCfEz_z15hRoZ6HQNS2iUXYV9_8Et6fMxHkO21uvYa_c9oLfxkUfBCwAYEvo1H7VEKiefO5BvFFODh3KKv-ZXo6XiGRhvY94InbCiWWgKMi1FsRHnewUfartmkEuZpJ1CIB8HhQnxI7gcNIgF3HgsvTC2eCAkGSe4Vy2jzdLOCBs6jsuDrVM9oRUpvD74nAu0yz1DrznsFdwEE8cp7dKH_RQZo6hqCBpLUB3aQWR9LaPiBZmy47E_j3QP2p85Q1LAmtJEGSJ516Dv-JMkBSAjIxAGqnzpBb4a3wIpyZ2JaZpG0j1luk1Lbs59TBtMaPEBepmXtGxY5f0wmSBdxn2FB7msBYZjFqdMsitT5CtO8i61NoaR8rzIfVeyE59uOg8-3rk-RNp5as1dledEY_Tzrn3MJy-aYCfxCXn1E_hlA=s0-d-e1-ft#https://u1333494.ct.sendgrid.net/wf/open?upn=O7ROD4svS-2BWtZVG4Rcp0QimkdhIBg6TlEvtWI20C5dUznI8qTKjItKVnM3mM-2BlyBR6XzF-2FUk46wF3xX0fNt3RbUsMH-2BNo6Y92KlQHNtFkcgHZyqHB0ZiYtK-2B-2BzsN3TzyaqqFWIisyz73XuYYFkbd5Lgzd6nfpFmCIG6dYZJt1qIJYURZZZa60SV8t4fr9G6JpTfytox2ClESQoO7v6i-2BDijIPD9vW-2F4ujI-2F99-2FhFUFQ-3D"
alt="" width="1" height="1" border="0" class="CToWUd" data-bit="iit">
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">


</div>
</div>
</div>
<div id=":18q" class="ii gt" style="display:none">
<div id=":18r" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
