export const goatEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":mo" tabindex="-1"></div>
<div id=":ox" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAyNzU3MDE3MjAxNzE0MyIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAyNzU3MDE3MjAxNzE0MyIsbnVsbCxbXV0.">
<div id=":oy" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div class="gmail_quote">
<div class="adM">
<br>
</div><u></u>
<div style="margin:0;padding:0;background-color:white;width:100%!important">
<u></u>
<img src="https://ci6.googleusercontent.com/proxy/MwZ0R4DiXkMme6Z6iSVKvkVcIwt4nYg2F9VJX8pWRH8s5c-sfWqwiIsldb5_3yvNz_NYrRa8B304fvJ3wS9jUgj37Q9BCEDJ7KWJUztfFsqiN86qQHGFm6O56zMC72YR56TIH0R-7CE=s0-d-e1-ft#https://mandrillapp.com/track/open.php?u=30012989&amp;id=46b0ce9a08c1438f8b512d09be0a5e22"
alt="" width="1" height="1" class="CToWUd" data-bit="iit">
</div>
<div style="height:auto;padding:0;margin:0">
<table style="font-size:0.0em" border="0" width="100%" cellspacing="0" cellpadding="0"
align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td align="center" valign="top" bgcolor="#ffffff" width="100%">
<div
style="display:none;font-size:0px;color:#000000;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden">
You ordered the ${form?.item_name}
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
</div>
<table style="max-width:600px;border:1px solid #000000" border="0"
width="100%" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td align="center" width="100%">
<table border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#ffffff">
<tbody>
<tr>
<td style="padding:10px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0" width="100%"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding-left:40px;font-family:Helvetica,Arial,sans-serif,normal;letter-spacing:3px;font-size:50px"
align="left" width="50%">
<a href="https://goat.app.link/?$deeplink_path=&amp;urlString=airgoat://&amp;$desktop_url=http://goat.com/?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.app.link/?$deeplink_path%3D%26urlString%3Dairgoat://%26$desktop_url%3Dhttp://goat.com/?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608044000&amp;usg=AOvVaw0wTL_WCdcBNitrxgD7Y5c7">
<img style="max-width:40px;color:#000000;display:block"
src="https://ci5.googleusercontent.com/proxy/sJ5eZQcML6N2Vr9R9o5yaC-cdmYNzdUeM3abJsdEEZG5j0savmQVE7kztqhAAEWbVg2_o9J5NVSE1FSu8z22N-s1oKWCkYMtSnOtVaCJUxExDf2OG_tZpzpwKEPcafy1CwDR=s0-d-e1-ft#https://email-assets.goat.com/GOAT/2022/Transactional/Evergreen/GOATLogo2022.png"
alt="GOAT"
width="40"
height="9"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
<td style="padding-right:40px"
align="right" width="50%">
<a href="https://goat.app.link/?$deeplink_path=&amp;urlString=airgoat://&amp;$desktop_url=http://goat.com/?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;letter-spacing:2.3px;font-size:10px;line-height:24px;font-weight:500;text-transform:uppercase;text-decoration:underline;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.app.link/?$deeplink_path%3D%26urlString%3Dairgoat://%26$desktop_url%3Dhttp://goat.com/?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608044000&amp;usg=AOvVaw0wTL_WCdcBNitrxgD7Y5c7">shop</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="border-top:1px solid #000000"
width="100%" height="1">&nbsp;</td>
</tr>
<tr>
<td style="padding:27.5px 0px" width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="font-family:Georgia,Helvetica,Arial,sans-serif,normal;font-size:22px;color:#000000;font-weight:100;letter-spacing:0.3px;line-height:25px;padding:0px 10%"
align="center" valign="middle" width="100%">
Thank you for your order</td>
</tr>
<tr>
<td style="padding:10px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="font-family:Helvetica,Arial,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:.4px;line-height:18px;padding:0px 10%"
align="center" valign="middle" width="100%">
Your order is being sent to GOAT for
authentication by our specialists. Once your
item has been authenticated, we'll send you
a confirmation email with a link to track
your package.</td>
</tr>
<tr>
<td style="padding:17.5px 0px" width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 40px" align="center"
width="100%">
<table style="border:1px solid #000000"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:20px 0px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;text-decoration:underline;color:#000000;font-weight:500;letter-spacing:2px;line-height:24px;text-transform:uppercase"
align="center" width="100%">
<a href="https://goat.app.link/?$desktop_deepview=&amp;$deeplink_path=&amp;orders/417525298/&amp;urlString=airgoat://orders/417525298&amp;$fallback_url=https://www.goat.com/account/orders/417525298?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="text-decoration:underline;color:#000000;font-weight:500;letter-spacing:2px;line-height:24px"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.app.link/?$desktop_deepview%3D%26$deeplink_path%3D%26orders/417525298/%26urlString%3Dairgoat://orders/417525298%26$fallback_url%3Dhttps://www.goat.com/account/orders/417525298?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608044000&amp;usg=AOvVaw3tLbJCrMSrF0hn_vsWHl4-">Order
#<wbr>${form?.order_number}</a>
</td>
</tr>
<tr>
<td style="border-top:1px solid #000000"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 60px"
align="center" width="100%">
<img style="display:block;width:100%;max-width:383px"
src=${form?.image_link}
width="383"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px"
align="left"
width="25%">
<a style="color:#000000;text-decoration:none"
rel="noreferrer">${form?.style_id}</a>
</td>
<td style="padding:0px 10px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:500;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="75%">
${form?.item_name}
– Size
${form?.size}
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0;overflow:hidden;display:none"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px"
align="left"
width="100%">
<a
rel="noreferrer">HQ2153</a>
</td>
</tr>
<tr>
<td style="padding:2.5px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:500;letter-spacing:2px;line-height:18px"
align="left"
width="100%">
Bad Bunny x
Forum Buckle
Low 'Last
Forum' –
Size US 11 M
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:15px 0px"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="padding:0px 40px 15px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:500;letter-spacing:2.3px;line-height:24px;text-transform:uppercase"
align="left" width="100%">item summary</td>
</tr>
<tr>
<td style="padding:0px 40px" align="center"
width="100%">
<table style="border:1px solid #000000"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="35%">
brand name
</td>
<td style="padding:0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
${form?.brand}
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0;overflow:hidden;display:none"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
box size
</td>
</tr>
<tr>
<td style="padding:2.5px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
US 11 M</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="35%">
shoe
condition
</td>
<td style="padding:0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
${form?.shoe_condition}
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0;overflow:hidden;display:none"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
shoe
condition
</td>
</tr>
<tr>
<td style="padding:2.5px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
New</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="35%">
box
condition
</td>
<td style="padding:0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
${form?.box_condition}
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0;overflow:hidden;display:none"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
box
condition
</td>
</tr>
<tr>
<td style="padding:2.5px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
${form?.box_condition}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="35%">
return
policy</td>
<td align="left"
width="65%">
<a href="https://www.goat.com/returns?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="padding:0px 10px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase;text-decoration:underline"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.goat.com/returns?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw0SQh3nEndQ651kdHRDzlrD">returnable
for site
credit</a>
</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0;overflow:hidden;display:none"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
return
policy</td>
</tr>
<tr>
<td style="padding:2.5px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="100%">
<a href="https://www.goat.com/returns?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:1.8px;line-height:18px;text-transform:uppercase;text-decoration:underline"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.goat.com/returns?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw0SQh3nEndQ651kdHRDzlrD">returnable
for site
credit</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="padding:0px 40px 15px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:500;letter-spacing:2.3px;line-height:24px;text-transform:uppercase"
align="left" width="100%">order summary</td>
</tr>
<tr>
<td style="padding:0px 40px" align="center"
width="100%">
<table style="border:1px solid #000000"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
subtotal
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
${form?.subtotal}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
shipping
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
${form?.shipping}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:7.5px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
verification
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
free</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
tax</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
${form?.tax}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%" height="0">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#b6b6b6;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
goat credit
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
-USD
${form?.goat_credit}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #000000"
width="100%" height="0">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:500;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left"
width="65%">
total paid
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:500;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="right"
width="35%">
${form?.total}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:5px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
Affirm</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="padding:0px 45px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:300;letter-spacing:.8px;line-height:16px;text-align:center"
align="left" width="100%">No additional tax
should be charged upon arrival.</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td style="padding:0px 40px 15px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:500;letter-spacing:2.3px;line-height:24px;text-transform:uppercase"
align="left" width="100%">shipping address
</td>
</tr>
<tr>
<td style="padding:0px 40px;text-decoration:none;color:#000000"
align="center" width="100%">
<table style="border:1px solid #000000"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:500;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
${form?.full_name}</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
<a style="color:#000000;text-decoration:none"
rel="noreferrer">${form?.street}</a>
</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
<a style="color:#000000;text-decoration:none"
rel="noreferrer">${form?.city}</a>
</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
<a style="color:#000000;text-decoration:none"
rel="noreferrer">${form?.zip}</a>
</td>
</tr>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="left" width="100%">
<a style="color:#000000;text-decoration:none"
rel="noreferrer">${form?.country}</a>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td align="center" width="100%">
<table border="0" width="100%"
cellspacing="0" cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 25px"
align="center"
width="100%">
<div
align="center">
<a href="https://goat.app.link/?$desktop_deepview=&amp;$deeplink_path=&amp;orders/417525298/&amp;urlString=airgoat://orders/417525298&amp;$fallback_url=https://www.goat.com/account/orders/417525298?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="background-color:#ffffff;border:1px solid #000000;border-radius:2px;color:#000000;display:block;font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;font-size:12px;letter-spacing:2.3px;font-weight:500;line-height:60px;text-align:center;text-decoration:none;width:320px;text-transform:uppercase"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.app.link/?$desktop_deepview%3D%26$deeplink_path%3D%26orders/417525298/%26urlString%3Dairgoat://orders/417525298%26$fallback_url%3Dhttps://www.goat.com/account/orders/417525298?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw3umHW1zD4MZH7c1CMqRASj">view
order
status</a>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px" width="100%">&nbsp;
</td>
</tr>
<tr>
<td align="center" width="100%">
<table style="background-color:#efefef"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:20px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 40px 15px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:500;letter-spacing:2px;line-height:24px;text-transform:uppercase"
align="left" width="100%">
Top Questions</td>
</tr>
<tr>
<td style="padding:0px 40px"
align="center" width="100%">
<table
style="border:1px solid #000000;background-color:#ffffff"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td align="center"
width="100%">
<table
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:400;letter-spacing:1px;line-height:20px"
align="left"
width="85%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004608267-When-will-I-receive-my-order-"
style="text-decoration:none;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004608267-When-will-I-receive-my-order-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw0F4FgqC4jOc993kUPahjD4">When
will
I
receive
my
order?</a>
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:bold;letter-spacing:1px;line-height:20px;text-transform:uppercase"
align="right"
width="15%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004608267-When-will-I-receive-my-order-"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004608267-When-will-I-receive-my-order-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw0F4FgqC4jOc993kUPahjD4">
<img src="https://ci5.googleusercontent.com/proxy/WsYivB3myBAvJ-SVqxvYA4MzQcNOp1dCG74wyd21VGjEBo_AwS-HP-9q96fRkogqeKmIa6TgJTICAB8WlDdAg4biIha4dW9VIr4m2jTKavsKBu7G1sXJeAgWbP9ezKg1k7UQLDWHlg=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/arrow.png"
width="5"
height="10"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%"
height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td align="center"
width="100%">
<table
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:400;letter-spacing:1px;line-height:20px"
align="left"
width="85%">
<a href="https://goat.zendesk.com/hc/en-us/articles/360021670172-Does-GOAT-Charge-Sales-Tax-"
style="text-decoration:none;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/360021670172-Does-GOAT-Charge-Sales-Tax-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw194KRGg5PIlqYhqx50sBBv">Why
was
I
charged
sales
tax?</a>
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:bold;letter-spacing:1px;line-height:20px;text-transform:uppercase"
align="right"
width="15%">
<a href="https://goat.zendesk.com/hc/en-us/articles/360021670172-Does-GOAT-Charge-Sales-Tax-"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/360021670172-Does-GOAT-Charge-Sales-Tax-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw194KRGg5PIlqYhqx50sBBv">
<img src="https://ci5.googleusercontent.com/proxy/WsYivB3myBAvJ-SVqxvYA4MzQcNOp1dCG74wyd21VGjEBo_AwS-HP-9q96fRkogqeKmIa6TgJTICAB8WlDdAg4biIha4dW9VIr4m2jTKavsKBu7G1sXJeAgWbP9ezKg1k7UQLDWHlg=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/arrow.png"
width="5"
height="10"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%"
height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td align="center"
width="100%">
<table
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:400;letter-spacing:1px;line-height:20px"
align="left"
width="85%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004608087-Can-I-cancel-my-order-"
style="text-decoration:none;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004608087-Can-I-cancel-my-order-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw2Pnx0FjRvlAJAZMiBjXnfs">Can
I
cancel
my
order?</a>
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:bold;letter-spacing:1px;line-height:20px;text-transform:uppercase"
align="right"
width="15%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004608087-Can-I-cancel-my-order-"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004608087-Can-I-cancel-my-order-&amp;source=gmail&amp;ust=1692884608045000&amp;usg=AOvVaw2Pnx0FjRvlAJAZMiBjXnfs">
<img src="https://ci5.googleusercontent.com/proxy/WsYivB3myBAvJ-SVqxvYA4MzQcNOp1dCG74wyd21VGjEBo_AwS-HP-9q96fRkogqeKmIa6TgJTICAB8WlDdAg4biIha4dW9VIr4m2jTKavsKBu7G1sXJeAgWbP9ezKg1k7UQLDWHlg=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/arrow.png"
width="5"
height="10"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%"
height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td align="center"
width="100%">
<table
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:400;letter-spacing:1px;line-height:20px"
align="left"
width="85%">
<a href="https://goat.zendesk.com/hc/en-us/articles/360001395651-How-do-I-update-my-shipping-address-"
style="text-decoration:none;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/360001395651-How-do-I-update-my-shipping-address-&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw346Q-Ldujkgi8fj08QOl4J">How
do
I
update
my
shipping
address?</a>
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:bold;letter-spacing:1px;line-height:20px;text-transform:uppercase"
align="right"
width="15%">
<a href="https://goat.zendesk.com/hc/en-us/articles/360001395651-How-do-I-update-my-shipping-address-"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/360001395651-How-do-I-update-my-shipping-address-&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw346Q-Ldujkgi8fj08QOl4J">
<img src="https://ci5.googleusercontent.com/proxy/WsYivB3myBAvJ-SVqxvYA4MzQcNOp1dCG74wyd21VGjEBo_AwS-HP-9q96fRkogqeKmIa6TgJTICAB8WlDdAg4biIha4dW9VIr4m2jTKavsKBu7G1sXJeAgWbP9ezKg1k7UQLDWHlg=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/arrow.png"
width="5"
height="10"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td style="border-top:1px solid #b6b6b6"
width="100%"
height="1">
&nbsp;</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
<tr>
<td align="center"
width="100%">
<table
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:0px 5px 0px 20px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:400;letter-spacing:1px;line-height:20px"
align="left"
width="85%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004770408-Do-you-accept-returns-"
style="text-decoration:none;color:#000000"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004770408-Do-you-accept-returns-&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw1ARRNAseEz8iwbr3CUWesI">Will
I
be
able
to
return
this
item?</a>
</td>
<td style="padding:0px 15px 0px 5px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:14px;color:#000000;font-weight:bold;letter-spacing:1px;line-height:20px;text-transform:uppercase"
align="right"
width="15%">
<a href="https://goat.zendesk.com/hc/en-us/articles/115004770408-Do-you-accept-returns-"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/articles/115004770408-Do-you-accept-returns-&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw1ARRNAseEz8iwbr3CUWesI">
<img src="https://ci5.googleusercontent.com/proxy/WsYivB3myBAvJ-SVqxvYA4MzQcNOp1dCG74wyd21VGjEBo_AwS-HP-9q96fRkogqeKmIa6TgJTICAB8WlDdAg4biIha4dW9VIr4m2jTKavsKBu7G1sXJeAgWbP9ezKg1k7UQLDWHlg=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/arrow.png"
width="5"
height="10"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:10px 0px"
width="100%">
&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:0px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:22px;text-transform:uppercase"
align="center" width="100%">
Have more questions?</td>
</tr>
<tr>
<td style="padding:0px 40px;font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:18px;text-transform:uppercase"
align="center" width="100%">
<a href="https://www.goat.com/faq?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:22px;text-transform:uppercase;text-decoration:underline"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.goat.com/faq?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw0sv-XQMXa2liSb9zhAoCpZ">Visit
our FAQ</a> or
<a href="https://goat.zendesk.com/hc/en-us/requests/new"
style="font-family:Helvetica Neue,Helvetica,sans-serif,normal;font-size:12px;color:#000000;font-weight:400;letter-spacing:2px;line-height:22px;text-transform:uppercase;text-decoration:underline"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/requests/new&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw1VEX5xU6eoHiZl4ZZLeZae">submit
a request</a>
</td>
</tr>
<tr>
<td style="padding:20px 0px"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="background-color:#000000"
align="center" width="100%">
<table style="max-width:600px" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:20px 0px"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="background-color:#000000"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
width="100%">
<a href="https://goat.zendesk.com/hc/en-us/requests/new"
style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;letter-spacing:1px;font-size:10px;line-height:15px;color:#ffffff;font-weight:400;text-decoration:underline;text-transform:uppercase"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.zendesk.com/hc/en-us/requests/new&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw1VEX5xU6eoHiZl4ZZLeZae">Contact
Support</a>
<span
style="text-decoration:none;color:#ffffff;font-size:11px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;font-weight:500;line-height:0px">&nbsp;&nbsp;|&nbsp;&nbsp;</span>
<a href="https://goat.app.link/?$deeplink_path=home/&amp;urlString=airgoat://home&amp;$desktop_url=https://www.goat.com/app?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_content=&amp;utm_term=9104156"
style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;letter-spacing:1px;font-size:10px;line-height:15px;color:#ffffff;font-weight:400;text-decoration:underline;text-transform:uppercase"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://goat.app.link/?$deeplink_path%3Dhome/%26urlString%3Dairgoat://home%26$desktop_url%3Dhttps://www.goat.com/app?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_content%3D%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw2hA_ziO_nxd8kahu1BpBZs">download
goat
app</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:12.5px 0px;background-color:#000000"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="background-color:#000000"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
width="100%">
<a href="https://www.instagram.com/goat"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.instagram.com/goat&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw3afVWka2m2nDHSR6A71mKW">
<img style="display:inline-block;width:100%;max-width:30px"
src="https://ci6.googleusercontent.com/proxy/EvQ6f_aF7fJPdYLcmTYhnj5GiR_ZSnXzuGQOaSZXFEron_P47DugfBorJSnpaAgxZkTmRpgyvmJk_SLwEjMJbgSbXdG-qyskqeg0sUJxCJAN6HttMgh5qwYZUuX2I78r103Lo9nLp22NDjIXim4qcmY=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/INSTAGRAM_White.png"
width="30"
height="30"
class="CToWUd"
data-bit="iit">
</a>
<a href="https://www.facebook.com/goatapp"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.facebook.com/goatapp&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw14pE0Sp2mHVhtY9hZ15sVR">
<img style="display:inline-block;width:100%;max-width:30px;padding:0px 10px"
src="https://ci6.googleusercontent.com/proxy/n6SoB65tGIn27q_7L928pnVq1nFI7GEH7XwMqAxmq7pebwOCO2eS0A3b_h4aZWqi9JLdIS2pRPAm5tKtAia9qHXabise3vNn8VvJhLKoxx9so8MGS1uT-JWckpsCrMJQX-TWeiFekffbXBZOZAsjhA=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/FACEBOOK_White.png"
width="30"
height="30"
class="CToWUd"
data-bit="iit">
</a>
<a href="https://www.twitter.com/goatapp"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.twitter.com/goatapp&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw2wqCfZtiZnfe9wXXi2Hnpe">
<img style="display:inline-block;width:100%;max-width:30px"
src="https://ci4.googleusercontent.com/proxy/Ghmv_ETR3-m9sU0PaFO-knY2MHRwUReaZ4Wf5DApMwwGQt0mWoTsUHfjcgfcKQVB3u1g85c27pQAQgd_istV49XcbkXJ24Ch3imDIHeMpI-bmQg9UYZzsR0Mhd7lGJNV2nMvcEPMiz-LwinolBbp=s0-d-e1-ft#https://sneakers-email-assets.s3.amazonaws.com/Transactional/Core%20Assets/TWITTER_White.png"
width="30"
height="30"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:12.5px 0px;background-color:#000000"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="background-color:#000000"
align="center" width="100%">
<table border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;letter-spacing:.5px;font-size:10px;line-height:18px;color:#ffffff;font-weight:300"
align="center"
valign="top"
width="100%">
© 2023 1661,
Inc. All
Rights
Reserved
<span
style="color:#ffffff;letter-spacing:.5px;font-size:10px;font-weight:300;text-decoration:none">&nbsp;&nbsp;|&nbsp;&nbsp;</span>
<a href="https://www.goat.com/terms?channel=Email&amp;campaign=buyer-order-confirmation&amp;utm_source=Email&amp;utm_medium=Transactional&amp;utm_campaign=buyer-order-confirmation&amp;utm_term=9104156"
style="color:#ffffff;text-decoration:underline"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=https://www.goat.com/terms?channel%3DEmail%26campaign%3Dbuyer-order-confirmation%26utm_source%3DEmail%26utm_medium%3DTransactional%26utm_campaign%3Dbuyer-order-confirmation%26utm_term%3D9104156&amp;source=gmail&amp;ust=1692884608046000&amp;usg=AOvVaw1PMDA5T5RxT6yJbhqJifn-">Terms</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="background-color:#000000"
align="center" width="100%">
<span
style="font-family:Helvetica Neue,Helvetica,Arial,sans-serif,normal;font-size:10px;font-weight:300;color:#ffffff;letter-spacing:.5px;padding:0px 3%;line-height:18px;text-decoration:none;background-color:#000000">P.O.
Box 91258, Los Angeles,
CA 90009-1258</span>
</td>
</tr>
<tr>
<td style="padding:2.5px 0px;background-color:#000000"
width="100%">&nbsp;</td>
</tr>
<tr>
<td style="padding:2.5px 0px;background-color:#000000"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 0px;background-color:#000000"
width="100%">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<img src="https://ci6.googleusercontent.com/proxy/MwZ0R4DiXkMme6Z6iSVKvkVcIwt4nYg2F9VJX8pWRH8s5c-sfWqwiIsldb5_3yvNz_NYrRa8B304fvJ3wS9jUgj37Q9BCEDJ7KWJUztfFsqiN86qQHGFm6O56zMC72YR56TIH0R-7CE=s0-d-e1-ft#https://mandrillapp.com/track/open.php?u=30012989&amp;id=46b0ce9a08c1438f8b512d09be0a5e22"
alt="" width="1" height="1" class="CToWUd" data-bit="iit">
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">

</div>
</div>
</div>
<div id=":m7" class="ii gt" style="display:none">
<div id=":pm" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
