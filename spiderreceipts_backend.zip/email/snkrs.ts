export const snkrsEmail = (form: any) => {
  return `<div class="">
<div class="aHl"></div>
<div id=":151" tabindex="-1"></div>
<div id=":18a" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzMjIyMTEyNDUyNjE0NiIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzMjIyMTEyNDUyNjE0NiIsbnVsbCxbXV0.">
<div id=":189" class="a3s aiL ">
<div>
<div class="adM">
</div>
<div dir="auto" class="adM">&nbsp;</div>
<div class="adM">
</div>
<div class="gmail_quote">
<div class="adM">
</div>
<div>
<div class="adM">
</div>
<table style="padding:10px" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="border-bottom:solid 1px #dddddd;border-collapse:collapse"
border="0" width="548" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:10px 0" align="left" valign="top">
<table style="border-collapse:collapse" border="0" width="548"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="text-decoration:none;color:#999999;font-family:Helvetica,Arial,sans-serif;font-size:10px;line-height:14px"
align="left" valign="top">Your Payment Overview
is attached.
<br>
</td>
<td align="right" valign="middle">
<a href="http://view.official.nike.com/?qs=0e0322884a1b3d74d6338a24805bf01fcf29e89e2580524f18edc76cfae1bc115b998a546f4d77a4f483acd5aa27ae66f73995dcfe06decf07108ca44cce6917053bebda80ab1ea425cf3c3bb36ea51538b1cf6eecbc3fc2"
style="text-decoration:underline;color:#999999;font-family:Helvetica,Arial,sans-serif;font-size:10px"
rel="noopener noreferrer" target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://view.official.nike.com/?qs%3D0e0322884a1b3d74d6338a24805bf01fcf29e89e2580524f18edc76cfae1bc115b998a546f4d77a4f483acd5aa27ae66f73995dcfe06decf07108ca44cce6917053bebda80ab1ea425cf3c3bb36ea51538b1cf6eecbc3fc2&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw1zYVzNFGs3hN-B_Y459BtL">Web
Version</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td
style="border-right:solid 1px #dddddd;border-left:solid 1px #dddddd">
<table style="border-collapse:collapse" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="border-top:solid 1px #dddddd;border-bottom:solid 1px #dddddd"
align="center" valign="top">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:25px 0"
align="center" valign="middle">
<a href="http://click.official.nike.com/?qs=196cc23a768895bad79135041f4c6c39aaa6b71671845f63c3fbc26ef5af2c39eca85aa6d92522db4e7f52ccaca3437ae20291b8ff718c21924abfddbc7ac28a"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D196cc23a768895bad79135041f4c6c39aaa6b71671845f63c3fbc26ef5af2c39eca85aa6d92522db4e7f52ccaca3437ae20291b8ff718c21924abfddbc7ac28a&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw1XVu5eosZ9_fegtih6vqwF">
<img style="display:block;outline:none;text-decoration:none;border:none;color:#333333;font-weight:bold;font-family:Helvetica,Arial,sans-serif;font-size:10px"
src="https://ci6.googleusercontent.com/proxy/djl413lwFv6ej3YNtROBcboE9qWaUqWjlwin0SVN5b1pjvooJovozyY_QDpqGn5F-bM=s0-d-e1-ft#https://i.imgur.com/3LT3PPD.png"
alt="" width="58"
height="20" border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-bottom:solid 1px #dddddd"
valign="top">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:15px 0px"
align="center">
<table
style="border-collapse:collapse"
border="0" cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=566a1c88b696571c77e115b05a19fd23c824ce9be1eb6cff203b6bfa768ede93e9c07487012935ee2054902a837a9c14e44cdf46516ba280867529fe6e51ddb7"
style="text-decoration:none;color:#000001;font-weight:Bold;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D566a1c88b696571c77e115b05a19fd23c824ce9be1eb6cff203b6bfa768ede93e9c07487012935ee2054902a837a9c14e44cdf46516ba280867529fe6e51ddb7&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw1trIwy4COjX5Mcxv4E1ny5">MEN</a>
</td>
<td style="padding:0 0 0 48px"
align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=883d0c64db4a714d02f6f09f7ee2e1a4115480cabf1b536f2cbca6fa7e70a8968bb830a1b988874515d9be60d0bea7002881e52c28673657347628bab7945682"
style="text-decoration:none;color:#000001;font-weight:Bold;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D883d0c64db4a714d02f6f09f7ee2e1a4115480cabf1b536f2cbca6fa7e70a8968bb830a1b988874515d9be60d0bea7002881e52c28673657347628bab7945682&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw357PBth3hsbAKelSfZXtbZ">WOMEN</a>
</td>
<td style="padding:0 0 0 48px"
align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=51ad48194e216ebe7a83bbef47943cbf1051895d94757b413f8b8acc60c5a96749800c11c771f5f5ea4449bb641230ca35616b6ec852ccd71b451ca9871e82c1"
style="text-decoration:none;color:#000001;font-weight:Bold;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D51ad48194e216ebe7a83bbef47943cbf1051895d94757b413f8b8acc60c5a96749800c11c771f5f5ea4449bb641230ca35616b6ec852ccd71b451ca9871e82c1&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw1js1dAHv7r80tYgjbawmDq">KIDS</a>
</td>
<td style="padding:0 0 0 48px"
align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=61869bbb5e9cb7a18dd237a9c0f96a04484429c1da650681203e800128fe3a2ef219283b8dedde3edceed1b1dc89cd794130739e25115b103bb6241454f7ae95"
style="text-decoration:none;color:#000001;font-weight:Bold;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D61869bbb5e9cb7a18dd237a9c0f96a04484429c1da650681203e800128fe3a2ef219283b8dedde3edceed1b1dc89cd794130739e25115b103bb6241454f7ae95&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw0-qfPQiHpuYB3FMU79CRl8">CUSTOMIZE</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="left" valign="top">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td align="center">
<table
style="border-collapse:collapse"
border="0" width="85%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#333;font-size:12px;line-height:16px;font-family:Helvetica,Arial,sans-serif;padding:10px 0px"
align="left"
valign="top">Hi
${form?.full_name},
<br>
<br>Thank you
for shopping
with us, your
payment overview
is below. If we
send more than
one package, you
might see more
than one payment
overview notice.
<br>
<br>We'll get
your shipment to
you as soon as
possible. In the
meantime, feel
free to
<a href="http://click.official.nike.com/?qs=9f38b245b8615369e3c90a7067b23802b9396ee50d8770d59cacd7f1732782b509c45a9cb11566dbddaf0d87625757dbe20f5e1718a365bec25e248f61ccd3da"
style="color:#fa5400;font:Helvetica,Arial,sans-serif;font-size:12px"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D9f38b245b8615369e3c90a7067b23802b9396ee50d8770d59cacd7f1732782b509c45a9cb11566dbddaf0d87625757dbe20f5e1718a365bec25e248f61ccd3da&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw18Q16k7mzGC3P7Kj_aCo32">contact
us</a> with
any questions.
<br>
<br>
<a href="http://click.official.nike.com/?qs=402361d93348023529d1f7edbbeccac7702c9cff0023a2109a52c1c844a8fac5a9b5657f4d64ed06b0fe20a2fa5ade833d3fbe50a4121ccb"
style="text-decoration:none;color:#333333;font:Helvetica,Arial,sans-serif;font-size:12px"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D402361d93348023529d1f7edbbeccac7702c9cff0023a2109a52c1c844a8fac5a9b5657f4d64ed06b0fe20a2fa5ade833d3fbe50a4121ccb&amp;source=gmail&amp;ust=1692889044143000&amp;usg=AOvVaw3KAXakKTb0FKZTaYLcbgxd">Nike.com</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:0px 0px 40px 0px" align="center"
valign="top">
<table style="border-collapse:collapse"
border="0" width="468" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td align="center" valign="top">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="border:none"
align="center">
<table
style="border:none;border-collapse:collapse"
border="0"
cellspacing="0"
cellpadding="0"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="padding-top:10px;page-break-inside:avoid"
valign="top">
<table
style="border:none;border-collapse:collapse;page-break-inside:avoid"
border="0"
width="210"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#eeeeee">
<tbody>
<tr>
<td
style="page-break-inside:avoid;padding:13px 20px 20px 20px">
<table
style="border:none;border-collapse:collapse;page-break-inside:avoid"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#eeeeee">
<tbody>
<tr>
<td style="font-size:16px;color:#333333;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
SHIP
TO
</td>
</tr>
<tr>
<td
style="font-size:1px;padding-top:5px;padding-bottom:5px">
<hr style="padding:0px 0px 0px 0px"
noshade=""
size="1"
width="100%">
</td>
</tr>
<tr>
<td style="font-size:12px;color:#333333;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:normal;page-break-inside:avoid"
align="left">
${form?.full_name}
<br>${form?.street}
<br>${form?.city}
<br>${form?.zip}
</td>
</tr>
<tr>
<td
style="font-size:1px;padding-top:5px;padding-bottom:5px">
<hr style="padding:0px 0px 0px 0px"
noshade=""
size="1"
width="100%">
</td>
</tr>
<tr>
<td style="font-size:12px;color:#333333;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
ORDER
NUMBER:
</td>
</tr>
<tr>
<td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
${form?.order_number}
</td>
</tr>
<tr>
<td
style="font-size:1px;padding-top:5px;padding-bottom:5px">
<hr style="padding:0px 0px 0px 0px"
noshade=""
size="1"
width="100%">
</td>
</tr>
<tr>
<td style="font-size:12px;color:#333333;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
ORDER
DATE:
</td>
</tr>
<tr>
<td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
${form?.order_date}
</td>
</tr>
<tr>
<td style="padding-top:20px;page-break-inside:avoid"
align="left">
<table
style="border-radius:3px;page-break-inside:avoid;border:2px outset #505050"
cellspacing="0"
cellpadding="0"
bgcolor="#3F3F3F">
<tbody>
<tr>
<td
style="padding:3px 5px 3px 5px">
<table
style="display:inline-block;border:none;border-collapse:collapse;page-break-inside:avoid"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#3F3F3F">
<tbody>
    <tr>
        <td style="page-break-inside:avoid"
            width="1px">
            <img style="border:none;display:block;padding:0px 0px 0px 0px"
                src="https://ci6.googleusercontent.com/proxy/T2e5otehZbkim0ISPcJRlczJM0QShgBNIBmtehZ_DZC4EL0dWztZNiaKOtJHD68wyxTpQnxmaLqifPFouc1z9toFO0vc6dddQ1T0tHG5Ynys-v1n9A=s0-d-e1-ft#http://store.nike.com/templates/emea/img/one-nike-email/spacer.png"
                alt=""
                width="1"
                height="26"
                border="0"
                class="CToWUd"
                data-bit="iit">
        </td>
        <td style="font-size:11px;line-height:1;color:#ffffff;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
            align="center"
            valign="middle"
            nowrap=""
            width="110">
            <div
                style="line-height:0px;padding:0px;width:0px;height:0px;display:none!important">
                &nbsp;
            </div>
            <a href="http://click.official.nike.com/?qs=0fc8ae92f8e9abc1ee2b62e5d305cd6115a6b0c4aa9819b60e19435f0e9bf9bf72803e1766bf59ad8604275fa7983d6e1ac10ae423800e2de6ee7799c87e57e6"
                style="display:inline-block;border-left:5px solid #3f3f3f;border-right:5px solid #3f3f3f;border-top:1px solid #3f3f3f;border-bottom:1px solid #3f3f3f;padding:0px;font-size:11px;color:#ffffff;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;line-height:100%"
                rel="noopener noreferrer"
                target="_blank"
                data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D0fc8ae92f8e9abc1ee2b62e5d305cd6115a6b0c4aa9819b60e19435f0e9bf9bf72803e1766bf59ad8604275fa7983d6e1ac10ae423800e2de6ee7799c87e57e6&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw20HQrtq30z1VSuxLIYDATu">ORDER
                STATUS</a>
        </td>
        <td style="font-size:11px;color:#ffffff;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
            align="center"
            valign="middle">
            <img style="border:none;display:block;padding:0px 5px 0px 0px"
                src="https://ci3.googleusercontent.com/proxy/JBhlVl2YVtpI86tQmrmoSjr-_PoMZ9HYN7Q1L4a7TAfrY3E2uQNAusDLmWrTF3hKNQLCu5HCbi98_MbOQA0nNUKKTCUzqFW5VpRlOPPOBeWNgBczRGKfw-wg=s0-d-e1-ft#http://store.nike.com/templates/emea/img/one-nike-email/WhiteCarret.png"
                alt="›"
                width="6"
                height="8"
                border="0"
                class="CToWUd"
                data-bit="iit">
        </td>
    </tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td
width="20">
&nbsp;
</td>
<td style="padding-top:10px;page-break-inside:avoid;page-break-after:always"
valign="top">
<table
style="border:none;border-collapse:collapse"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="padding-top:13px;padding-bottom:0px"
align="left">
<table
style="border:none;border-collapse:collapse"
border="0"
width="230"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="page-break-inside:avoid"
valign="top"
width="100%">
<table
style="border:none;border-collapse:collapse;page-break-inside:avoid"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="padding-bottom:10px;font-size:1px;page-break-inside:avoid"
valign="bottom">
&nbsp;
</td>
</tr>
<tr>
<td style="padding-bottom:20px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="center">
<img style="border:none;border-collapse:collapse;display:block;padding:0px 0px 0px 0px"
src=${form?.image_link}
alt=""
width="100"
height="auto"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
<tr>
<td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
${form?.item_name}
</td>
</tr>
<tr>
<td style="padding-top:10px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold">Style#:</span>
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:normal">${form?.style_id}</span>
</td>
</tr>
<tr>
<td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold">Size:</span>
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:normal">${form?.size}</span>
</td>
</tr>
<tr>
<td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold;page-break-inside:avoid"
align="left">
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold">Qty:</span>
<span
style="border:none;border-collapse:collapse;padding:0px 0px 0px 0px;font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:normal">1</span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding-top:20px;padding-bottom:0px"
align="left">
<table
style="border:none;border-collapse:collapse"
border="0"
width="230"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#ffffff">
<tbody>
<tr>
<td>
<table
style="border:none;border-collapse:collapse"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#ffffff">
<tbody>
<tr>
<td style="padding-bottom:10px"
valign="bottom">
<hr style="padding:0px 0px 0px 0px"
noshade=""
size="1"
width="100%">
</td>
</tr>
<tr>
<td>
<table
style="border:none;border-collapse:collapse"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
bgcolor="#ffffff">
<tbody>
    <tr>
        <td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="left">
            Subtotal:
        </td>
        <td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="right"
            width="75">
            ${form?.subtotal}
        </td>
    </tr>
    <tr>
        <td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="left">
            Shipping
            &amp;
            Handling:
        </td>
        <td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="right"
            width="75">
            ${form?.shipping}
        </td>
    </tr>
    <tr>
        <td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="left">
            Tax:
        </td>
        <td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="right"
            width="75">
            ${form?.tax}
        </td>
    </tr>
    <tr>
        <td style="font-size:12px;color:#666666;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="left">
            TOTAL:
        </td>
        <td style="font-size:12px;color:#fa5400;font-family:Helvetica,Arial,sans-serif;text-decoration:none;font-weight:bold"
            align="right"
            width="75">
            ${form?.total}
        </td>
    </tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:0 0 40px 0" align="center"
valign="top">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td align="center" valign="top">
<a href="http://click.official.nike.com/?qs=c7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw0q7t1lW3pak0uLCNj8dDcp">
<img style="display:block;outline:none;text-decoration:none;border:none;font-weight:bold;font-size:12px;font-family:Helvetica,Arial,Sans-serif;color:#333333"
src="https://ci5.googleusercontent.com/proxy/Y2Q2mCXuxVWM00tsevIiWf_mGZTBE5Fq_R6wMKo9LDkLZ33w0lGeshQ19Fz99Kam2vY=s0-d-e1-ft#https://i.imgur.com/dr6alAu.jpg"
alt="CAN WE HELP? | CONTACT US"
border="0"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>
<tr>
<td style="font-size:1px;line-height:1px;padding:0;text-decoration:none"
align="center" valign="middle">
<div
style="display:none;width:0px;max-height:0px;overflow:hidden">
<table
style="border-collapse:collapse;border:1px solid #dddddd"
border="0" width="280"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:30px 0 0 0;font-size:24px;font-family:'TradeGothicProCyrBoldCd20',Helvetica,Arial,sans-serif;color:#333333;line-height:24px"
align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=c7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79"
style="font-size:24px;font-family:'TradeGothicProCyrBoldCd20',Helvetica,Arial,sans-serif;color:#333333;text-decoration:none"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw0q7t1lW3pak0uLCNj8dDcp">CAN
WE
HELP?</a>
</td>
</tr>
<tr>
<td style="padding:0 0 30px 0;font-size:10px;font-weight:bold;font-family:Helvetica,Arial,sans-serif;color:#333333;line-height:10px"
align="center"
valign="middle">
<a href="http://click.official.nike.com/?qs=c7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79"
style="font-weight:bold;font-size:10px;font-family:Helvetica,Arial,sans-serif;color:#333333;text-decoration:none"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw0q7t1lW3pak0uLCNj8dDcp">CONTACT
US</a>
<a href="http://click.official.nike.com/?qs=c7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79"
style="text-decoration:none;font-size:15px;color:#fa5400;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc7398339ad2308e16ba361672f8d128af249998437380f2de687261d4621a9a67ec45438c56ccb7a44f7bd3b3dbde35be8790dc25c71357e7ff7a63c535faa79&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw0q7t1lW3pak0uLCNj8dDcp">›</a>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="font-size:1px;line-height:1px;padding:0"
align="center" valign="top">
<div
style="display:none;width:0px;max-height:0px;overflow:hidden">
<table
style="border-collapse:collapse"
border="0" width="318"
cellspacing="0"
cellpadding="0"
bgcolor="#f2f1f1">
<tbody>
<tr>
<td style="padding:18px 0 15px 0;text-decoration:none;color:#686868;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold;border-bottom:solid 1px #dddddd"
align="center"
valign="middle">
SHOP FOR:
</td>
</tr>
<tr>
<td style="border-bottom:solid 1px #dddddd"
align="center"
valign="middle">
<table
style="border-collapse:collapse"
border="0"
width="318"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:0 0 0 30px;text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
align="left"
valign="middle">
<a href="http://click.official.nike.com/?qs=c8ce86f34bbf2a92861faa113106a9bd48a93bbd6927bcb5e2ce74ea0dc3ce80cfc10b9e251695b2516ac176d314df23d79ccbe05e8f57d9a8b4fb5480a110e6"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc8ce86f34bbf2a92861faa113106a9bd48a93bbd6927bcb5e2ce74ea0dc3ce80cfc10b9e251695b2516ac176d314df23d79ccbe05e8f57d9a8b4fb5480a110e6&amp;source=gmail&amp;ust=1692889044144000&amp;usg=AOvVaw2U_yVVM0CqN7eHxvVrjqwi">MEN</a>
</td>
<td style="padding:0 15px 0 0"
align="right"
valign="middle">
<a href="http://click.official.nike.com/?qs=c8ce86f34bbf2a92861faa113106a9bd48a93bbd6927bcb5e2ce74ea0dc3ce80cfc10b9e251695b2516ac176d314df23d79ccbe05e8f57d9a8b4fb5480a110e6"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dc8ce86f34bbf2a92861faa113106a9bd48a93bbd6927bcb5e2ce74ea0dc3ce80cfc10b9e251695b2516ac176d314df23d79ccbe05e8f57d9a8b4fb5480a110e6&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw3SUEafrC5B2d7wGYqVqJqU">➤</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-bottom:solid 1px #dddddd"
align="center"
valign="middle">
<table
style="border-collapse:collapse"
border="0"
width="318"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:0 0 0 30px;text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
align="left"
valign="middle">
<a href="http://click.official.nike.com/?qs=416919f0e5955a0c2661820a69536111b0f89b89754195d07375fe39f9a6a94a60b6bc34f8129c966eee01e90c0e063204bfe83ef6e4ac56de10476f9bd4b4e4"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D416919f0e5955a0c2661820a69536111b0f89b89754195d07375fe39f9a6a94a60b6bc34f8129c966eee01e90c0e063204bfe83ef6e4ac56de10476f9bd4b4e4&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw1UQpklqCZlVsfiSfPUUJQo">WOMEN</a>
</td>
<td style="padding:0 15px 0 0"
align="right"
valign="middle">
<a href="http://click.official.nike.com/?qs=416919f0e5955a0c2661820a69536111b0f89b89754195d07375fe39f9a6a94a60b6bc34f8129c966eee01e90c0e063204bfe83ef6e4ac56de10476f9bd4b4e4"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D416919f0e5955a0c2661820a69536111b0f89b89754195d07375fe39f9a6a94a60b6bc34f8129c966eee01e90c0e063204bfe83ef6e4ac56de10476f9bd4b4e4&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw1UQpklqCZlVsfiSfPUUJQo">➤</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-bottom:solid 1px #dddddd"
align="center"
valign="middle">
<table
style="border-collapse:collapse"
border="0"
width="318"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:0 0 0 30px;text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
align="left"
valign="middle">
<a href="http://click.official.nike.com/?qs=1e0e346f6a034dead1c578dbc5d33c0f9eb9a7761ccc49e396c700a568f1abfd0c3cdc8021b66a39b6456baa505fd23b041ee8b886ffe9827752ad610b40166b"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D1e0e346f6a034dead1c578dbc5d33c0f9eb9a7761ccc49e396c700a568f1abfd0c3cdc8021b66a39b6456baa505fd23b041ee8b886ffe9827752ad610b40166b&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw2l2eOw0AtdZDG6pJ0B7Wmb">KIDS</a>
</td>
<td style="padding:0 15px 0 0"
align="right"
valign="middle">
<a href="http://click.official.nike.com/?qs=1e0e346f6a034dead1c578dbc5d33c0f9eb9a7761ccc49e396c700a568f1abfd0c3cdc8021b66a39b6456baa505fd23b041ee8b886ffe9827752ad610b40166b"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D1e0e346f6a034dead1c578dbc5d33c0f9eb9a7761ccc49e396c700a568f1abfd0c3cdc8021b66a39b6456baa505fd23b041ee8b886ffe9827752ad610b40166b&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw2l2eOw0AtdZDG6pJ0B7Wmb">➤</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-bottom:solid 1px #dddddd"
align="center"
valign="middle">
<table
style="border-collapse:collapse"
border="0"
width="318"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:0 0 0 30px;text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
align="left"
valign="middle">
<a href="http://click.official.nike.com/?qs=2878747985826ccfde9376ab4f3492f8434d91f2342b1652cf7e72e8f9538168d0da0c2cd820b06148e70a691e30db91eccc2349cc333b6df2a0f90b6738ef4b"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D2878747985826ccfde9376ab4f3492f8434d91f2342b1652cf7e72e8f9538168d0da0c2cd820b06148e70a691e30db91eccc2349cc333b6df2a0f90b6738ef4b&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw0fbdirWTXKii8t-wTqR1QE">CUSTOMIZE</a>
</td>
<td style="padding:0 15px 0 0"
align="right"
valign="middle">
<a href="http://click.official.nike.com/?qs=2878747985826ccfde9376ab4f3492f8434d91f2342b1652cf7e72e8f9538168d0da0c2cd820b06148e70a691e30db91eccc2349cc333b6df2a0f90b6738ef4b"
style="text-decoration:none;color:#838383;font-family:Helvetica,Arial,sans-serif;font-size:10px;font-weight:bold"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D2878747985826ccfde9376ab4f3492f8434d91f2342b1652cf7e72e8f9538168d0da0c2cd820b06148e70a691e30db91eccc2349cc333b6df2a0f90b6738ef4b&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw0fbdirWTXKii8t-wTqR1QE">➤</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" valign="top">
<table style="border-collapse:collapse"
border="0" width="100%" cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="padding:15px 30px"
align="left" valign="top"
bgcolor="#444444">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td align="left">
<a href="http://click.official.nike.com/?qs=ea1d7f93458a17c53c93ed81fd72fe3d6c0ff869d8d1d06adbc2953f146c43a79684e0c9ee85e02d9d333c43a7bee57cce352d9d63105a68ece27582d0b730be"
style="text-decoration:none;color:#ffffff;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Dea1d7f93458a17c53c93ed81fd72fe3d6c0ff869d8d1d06adbc2953f146c43a79684e0c9ee85e02d9d333c43a7bee57cce352d9d63105a68ece27582d0b730be&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw0WWbZK5uT8dWEIU_LSNauB">Privacy
Policy</a>&nbsp;&nbsp;&nbsp;
<a href="http://click.official.nike.com/?qs=b2872b50d631e313bb3879ed5cef8fe0fb4a8335dbdffac6e39c4abd4044b997533cb37da58e314930b0bd9da85bc14880b028d410f522b2b6187fd4bc4ed1cb"
style="text-decoration:none;color:#ffffff;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Db2872b50d631e313bb3879ed5cef8fe0fb4a8335dbdffac6e39c4abd4044b997533cb37da58e314930b0bd9da85bc14880b028d410f522b2b6187fd4bc4ed1cb&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw2KdEersgA8swEMq0Z83YL0">Get
Help</a>&nbsp;&nbsp;&nbsp;
</td>
<td style="text-decoration:none;color:#ffffff;font-size:10px;font-family:Helvetica,Arial,sans-serif"
align="right">©
2023 NIKE, Inc.
All Rights
Reserved.</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:20px 30px"
align="left" valign="top">
<table
style="border-collapse:collapse"
border="0" width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td align="left"
valign="top">
<table
style="border-collapse:collapse"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:10px"
align="left"
valign="top">
NIKE,
INC.
One
Bowerman
Drive,
Beaverton,
OR
97005,
USA.
<br>
<br>Please
do
not
reply
to
this
email.
If
you
need
to
contact
Nike
<br>with
questions
or
concerns,
please
<a href="http://click.official.nike.com/?qs=f4f28feacb44ff2787d56ff7b5a89556c53e152136c85c29d10803b4c8aa047e63baca508c270d4d260b2339e3062682c8c0248c436bd70883708dbc83ea810f"
style="text-decoration:underline;color:#666666;font-size:10px;font-family:Helvetica,Arial,sans-serif"
rel="noopener noreferrer"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3Df4f28feacb44ff2787d56ff7b5a89556c53e152136c85c29d10803b4c8aa047e63baca508c270d4d260b2339e3062682c8c0248c436bd70883708dbc83ea810f&amp;source=gmail&amp;ust=1692889044145000&amp;usg=AOvVaw34JUBo_3AwBumeSQaFoQHP">click
here</a>.
</td>
<td style="color:#333333;font-family:Helvetica,Arial,sans-serif;font-size:10px;padding:20px 40px"
align="right"
valign="top">
&nbsp;
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</div>
<div class="adL">


</div>
</div>
</div>
<div id=":155" class="ii gt" style="display:none">
<div id=":156" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>`;
};
