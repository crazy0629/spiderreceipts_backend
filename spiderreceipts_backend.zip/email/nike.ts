export const nikeEmail = (form: any) => {
  return `<!DOCTYPE html>
<html lang="en">

<head>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="">
<div class="aHl"></div>
<div id=":154" tabindex="-1"></div>
<div id=":16f" class="ii gt"
jslog="20277; u014N:xr6bB; 1:WyIjdGhyZWFkLWY6MTc3NTAzMTI5MTk0MjUxNDA5NSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsW11d; 4:WyIjbXNnLWY6MTc3NTAzMTI5MTk0MjUxNDA5NSIsbnVsbCxbXV0.">
<div id=":16e" class="a3s aiL ">
<div class="adM">
</div>
<div class="adM">

</div>
<div>
<div class="adM">
</div>
<blockquote>
<div class="adM">
</div>
<div dir="ltr">
<div class="adM">
</div>
<center>
<div style="text-align:center;display:none;font-size:1px;color:#333333;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden"
align="center">Get your order summary, estimated delivery date and
more.&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌
&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌ &nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌<wbr>&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌
</div>
<div style="text-align:center;font-size:0px" align="center">
<img src="https://ci6.googleusercontent.com/proxy/nMq1zqwR7FUnZWStndTc_r2xgGO8M1sRahjsoaHTz3plfkiHP_MY3ADZuWT8xHJKVhHn8d1_wId7445gVkgmBtq8p9yAsppu8YtNpSbnQ_SSFazaZ6hRWzZFBfZFtdSr2gIPOkwT-ZiAYpfm4X6dN2J0h_JvmKgOtdUPPFF4-rxuMpDhRv00-98aPIHeFgmnkrTgtRpsimhtCkygkl1KmqehfeZN-M6kvpXntbOaoWB-mGO7jrm9nwrjJFBEmEvlga2S=s0-d-e1-ft#http://click.official.nike.com/open.aspx?ffcb10-fe8e15797d60067c7d-fe3b1d727565057c761572-fe9815737560077476-ff2a17777163-fe141c797c6c057b771379-febc15797c650c7a&amp;d=40127&amp;bmt=0"
alt="" width="1" height="1" class="CToWUd" data-bit="iit">
<table style="padding:0px;font-size:0px" role="presentation" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="font-size:0px;line-height:1px;overflow:hidden!important">
&nbsp;</td>
<td style="width:642px;max-width:642px!important;min-width:320px!important;border:1px solid #e5e5e5"
align="center" valign="top" width="642">
<table
style="border:none;width:100%;min-width:320px!important;max-width:640px!important;padding:0px;border-collapse:collapse"
role="presentation" border="0" width="100%" cellspacing="0"
cellpadding="0" align="center" bgcolor="#FFFFFF">
<tbody>
<tr>
<td align="center">
<table style="width:100%" border="0" width="100%"
cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="border-bottom:1px solid #e5e5e5"
align="center">
<table style="border-spacing:0px"
role="presentation"
width="100%">
<tbody>
<tr>
<td style="padding:0px"
align="center"
bgcolor="#F7F7F7">
<table
style="margin:0px auto;max-width:100%;min-width:320px;border:none;border-collapse:collapse"
role="presentation"
border="0"
width="94%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:20px 20px 20px 20px;font-size:0px"
align="left"
valign="middle">
<table
role="presentation"
width="100%">
<tbody>
<tr>
<td style="color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:26px;padding:0px"
align="left"
valign="top">
Delivering
to:
${form?.full_name}
</td>
</tr>
<tr>
<td style="color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:26px"
align="left"
valign="top">
<p
style="color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:26px;margin:0px">
<span>${form?.street}
<br>${form?.city}&nbsp;<wbr>${form?.zip}
</span>
</p>
</td>
</tr>

</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:1px solid #e5e5e5;padding:0px"
align="center"
bgcolor="#ffffff">
<div
style="line-height:0px;padding:0px;width:0px;height:0px;display:none!important">
&nbsp;</div>
<table
role="presentation"
width="100%">
<tbody>
<tr>
<td style="text-align:center;font-size:14px;padding:50px 0px 20px 0px"
align="center">
<table
style="border-spacing:0px;min-width:275px;width:65%;margin:0px auto"
role="presentation">
<tbody>
<tr>
<td style="padding:0px 0px 30px 0px;text-align:center"
align="left">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707f1ed5dcac6566422a28a06834dbd1987051af8a63cb88571fe3f47c9a273a95eefae53b355eebb74324e6e80c9414ea0b95d5134d75928a9"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707f1ed5dcac6566422a28a06834dbd1987051af8a63cb88571fe3f47c9a273a95eefae53b355eebb74324e6e80c9414ea0b95d5134d75928a9&amp;source=gmail&amp;ust=1692888159199000&amp;usg=AOvVaw0PxDEani4moOZz1ZI2iDmv">
<img style="border:none;border-width:0px"
src="https://ci6.googleusercontent.com/proxy/XNdrtYLiUnC_fLGVBlZHrXiwq_vQ5jB0i0zIu8RwIuk0xWiyMLaXdnVnefedhnDXpsn0KMDznG9ylk7mRZL5rTjlE65MpATsEYSQaX-cRcHxpfBZIDdK5mo=s0-d-e1-ft#http://image.official.nike.com/lib/fe9815737560077476/m/3/Swoosh2x.png"
alt="logo"
width="57"
class="CToWUd"
data-bit="iit">
</a>
</td>
</tr>

<tr>
<td style="padding:0px 0px 15px 0px;text-align:center"
align="left">
<h1
style="color:#111111;font-size:28px;line-height:34px;font-family:Helvetica,Arial,sans-serif;margin:0px">
<span
style="color:#111111;font-size:28px;line-height:34px;font-family:'Nike TG',Helvetica,Arial,sans-serif!important">Thanks,
${form?.full_name}!
We're&nbsp;On&nbsp;It.</span>
</h1>
</td>
</tr>

<tr>
<td style="padding:0px 0px 20px 0px;text-align:center;color:#6d6d6d;line-height:26px;font-family:Helvetica,Arial,sans-serif"
align="left">
Your
order’s
in.
We’re
working
to
get
it
packed
up
and
out
the
door—expect
a
shipping
confirmation
email
soon.
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:0px"
align="center"
bgcolor="#ffffff">
<table
style="padding:0px"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="border-top:1px solid #e5e5e5;padding:0px"
align="center"
bgcolor="#ffffff">
<table
style="margin:0px auto;max-width:100%;min-width:320px;border:none;border-collapse:collapse"
role="presentation"
border="0"
width="94%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td
style="padding:20px 20px;text-align:center;font-size:14px">
<table
role="presentation"
width="100%">
<tbody>
<tr>
<td style="padding:0px 0px;text-align:left;margin:0px"
align="left">
<span
style="font-size:14px;font-family:Helvetica,Arial,sans-serif;color:#017f07;line-height:24px">Estimated
Delivery
Date
${form?.delivery_date}</span>
</td>
</tr>
</tbody>
</table>

</td>
</tr>
</tbody>
</table>
</td>
</tr>

<tr>
<td style="padding:0px 0px 40px 0px"
align="center"
bgcolor="">
<div
style="width:300px;border:none;display:inline-table;padding:0px!important;font-size:0px;vertical-align:top">
<table
style="font-size:16px;color:white;margin:0px;padding:0px;line-height:1.5;border-collapse:collapse;text-align:center"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td>
<table
style="margin-bottom:10px!important">
<tbody>
<tr>
<td style="background-color:#f6f4f8;padding:0px 10px;text-align:center"
align="center"
valign="top">
<img style="width:280px;height:auto;border:none;border-collapse:collapse;display:block;padding:0px 0px 0px 0px;background-color:#f6f4f8"
src=${form?.image_link}
alt=""
width="280"
height="auto"
border="0"
class="CToWUd"
data-bit="iit"
jslog="138226; u014N:xr6bB; 53:WzAsMl0.">
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="width:280px;border:none;display:inline-table;padding:0px!important;font-size:0px;vertical-align:top">
<table
style="font-size:16px;margin:0px;padding:0px;line-height:1.5"
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
align="left"
bgcolor="#FFFFFF">
<tbody>
<tr>
<td
style="padding:0px 10px">
<table
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="left"
valign="top">
${form?.item_name}
</td>
<td
valign="top">
<table
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="white-space:nowrap;word-break:break-all;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px;text-align:right;border:none"
align="right"
valign="top"
width="75">
${form?.subtotal}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding:0px 10px;width:200px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:22px"
align="left"
valign="top">
${form?.size}
</td>
</tr>
</tbody>
</table>
</div>

</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:1px solid #e5e5e5;padding:0px"
align="center"
bgcolor="#ffffff">
<table
style="margin:0px auto;min-width:320px"
role="presentation"
width="94%">
<tbody>
<tr>
<td style="padding:20px 0px 20px 0px"
align="left">
<div
style="max-width:213px!important;border:none;display:inline-table;padding:0px!important;font-size:0px;vertical-align:top">
<table
style="max-width:213px!important;min-width:213px!important;font-size:14px;color:white;margin:0px;padding:0px;line-height:17px;border-collapse:collapse"
role="presentation"
border="0"
width="233"
cellspacing="0"
cellpadding="0"
align="left">
<tbody>
<tr>
<td style="padding:20px 0px 0px 20px;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:26px"
align="left"
valign="top">
Order
Number
</td>
</tr>
<tr>
<td style="padding:0px 0px 0px 20px;color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:26px"
align="left"
valign="top">
${form?.order_number}
</td>
</tr>
</tbody>
</table>
</div>

<div
style="width:100%;max-width:363px!important;border:none;display:inline-table;padding:0px!important;font-size:0px;vertical-align:top">
<table
style="max-width:363px;min-width:320px!important;font-size:14px;color:white;margin:0px;padding:0px;line-height:17px;border-collapse:collapse"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="left">
<tbody>
<tr>
<td style="width:150px;padding:20px 0px 0px 20px;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:26px"
align="left"
valign="top"
width="150">
Order
Date
</td>
<td
style="font-size:0px;max-width:40px">
&nbsp;
</td>
<td style="width:150px;padding:20px 0px 0px 20px;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:26px"
align="left"
valign="top"
width="150">
Delivery
Method
</td>
</tr>
<tr>
<td style="padding:0px 0px 20px 20px;color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:26px"
align="left"
valign="top"
width="150">
${form?.order_date}
</td>
<td
style="font-size:0px;max-width:40px">
&nbsp;
</td>
<td style="padding:0px 0px 20px 20px;color:#666666;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:26px"
align="left"
valign="top"
width="150">
Standard
</td>
</tr>
</tbody>
</table>
</div>

<div
style="width:100%;max-width:100%!important;border:none;display:inline-table;padding:0px!important;font-size:0px;vertical-align:top">
<table
style="max-width:100%;min-width:320px!important;font-size:14px;color:white;margin:0px;padding:0px;line-height:17px;border-collapse:collapse"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:20px 0px"
align="center">
<div
style="line-height:0px;padding:0px;width:0px;height:0px;display:none!important">
&nbsp;
</div>
<table
style="margin:0px auto;height:40px;width:225px;border:1px solid #8d8d8d;border-radius:2px;display:inline-table"
role="presentation"
width="225"
align="center">
<tbody>
<tr>
<td style="text-align:center;height:40px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:20px"
align="center"
height="40">
‌
<a href="http://click.official.nike.com/?qs=701f93b8c7482707451ce83fbb97e46eb46d73f92017f433fdf98adb9d73ab1ff4e0c4b22bf4ed537969fd2c4265196e0d0748f57124403f8e9dda56582f1dd9"
style="min-width:140px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:15px;text-align:center;text-decoration:none;border:1px hidden #ffffff;display:inline-block"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707451ce83fbb97e46eb46d73f92017f433fdf98adb9d73ab1ff4e0c4b22bf4ed537969fd2c4265196e0d0748f57124403f8e9dda56582f1dd9&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw0dSU_umQC-MxEplfziJnCW">
<span
style="font-family:'Nike TG',Helvetica,Arial,sans-serif!important;font-size:14px;line-height:15px;color:#000000">
Order
Status
</span>
</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:1px solid #e5e5e5;padding:0px"
align="center"
bgcolor="#ffffff">
<table
style="margin:0px auto;max-width:100%;min-width:320px;border:none;border-collapse:collapse"
role="presentation"
border="0"
width="94%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:00px 20px 00px 20px;font-size:0px"
align="left"
valign="middle">
<table
role="presentation"
width="100%">
<tbody>
<tr>
<td style="color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px;padding:40px 0px 40px 0px"
align="center">
<table
style="padding:0px;margin:0px;border-collapse:collapse"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="left"
width="60%">
Payment
</td>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="right"
width="40%">
****
****
****
${form?.last_4_credit_card}
</td>
</tr>
<tr>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="left"
width="60%">
Subtotal
</td>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="right"
width="40%">
${form?.subtotal}
</td>
</tr>
<tr>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="left"
width="60%">
Shipping
&amp;
Handling
</td>
<td style="padding:10px 0px;color:#6d6d6d;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:24px"
align="right"
width="40%">
${form?.shipping}
</td>
</tr>
<tr>
<td style="padding:10px 0px 0px 0px;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:18px;line-height:30px"
align="left"
width="60%">
Total
</td>
<td style="padding:10px 0px 0px 0px;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:18px;line-height:30px"
align="right"
width="40%">
${form?.total}
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center">&nbsp;</td>
</tr>
<tr>
<td align="center">&nbsp;</td>
</tr>
<tr>
<td align="center">
<table
style="margin:0px;border-collapse:collapse;padding:0px;background-color:#f7f7f7"
role="presentation" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td
style="font-size:0px">
<table
style="margin:0px auto;min-width:320px;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="94%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="padding:40px 0px 0px 20px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:bold;line-height:28px"
align="left">
Get
Help
</td>
</tr>
<tr>
<td style="font-size:0px;padding:0px 0px 40px 0px;vertical-align:top"
align="left"
valign="top">
<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:120px;padding:25px 20px 0px 20px;font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707dac09820a40a86acbf11f75ff96a3607eb55024401bcef89340d6fcfeca9c783eafdabbb052f8b6e6133f0e639ed8776ae1aae7f155b45a4"
style="font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707dac09820a40a86acbf11f75ff96a3607eb55024401bcef89340d6fcfeca9c783eafdabbb052f8b6e6133f0e639ed8776ae1aae7f155b45a4&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw03XQUytAJFvgE0KPKWtpC5">Cancel
Order</a>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:120px;padding:25px 20px 0px 20px;font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707267a77ba045d0ba5dcb3228416c51e360ce8d9b73feefaf496ca078435b6fff62e79391385242cd5d1f3ed5c896e16d61327491fabea33f7"
style="font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707267a77ba045d0ba5dcb3228416c51e360ce8d9b73feefaf496ca078435b6fff62e79391385242cd5d1f3ed5c896e16d61327491fabea33f7&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw313zHo--ejIdcEeFoeHKb0">Returns
Policy</a>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:120px;padding:25px 20px 0px 20px;font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707cd0670b937fb659dc4de24db318968fa0032e05d90375dbf5c439c1094945e14c9c745de988392af16d9342f036e293c1560c196cf9c3371"
style="font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707cd0670b937fb659dc4de24db318968fa0032e05d90375dbf5c439c1094945e14c9c745de988392af16d9342f036e293c1560c196cf9c3371&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw3gJPG_wFBQuZ9EjPmwnVwN">Contact
Options</a>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:120px;padding:25px 20px 0px 20px;font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px">
<a href="http://click.official.nike.com/?qs=701f93b8c748270793f37b1a85afaf2203c6e16360d8e19c698b80aa481f3c8ce100b8be3dbea0856bec973e8eed610f5477083f60a1c79b0900f999ab157aae"
style="font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c748270793f37b1a85afaf2203c6e16360d8e19c698b80aa481f3c8ce100b8be3dbea0856bec973e8eed610f5477083f60a1c79b0900f999ab157aae&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2tPBFMWCYi6pkgF5SgQUhv">Gift
Card
Balance</a>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:160px;font-size:0px;line-height:1px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-block;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td
style="width:100%;min-width:120px;padding:25px 20px 0px 20px;font-family:Helvetica,Arial,sans-serif;color:#111111;font-size:12px;line-height:20px">
&nbsp;
</td>
</tr>
</tbody>
</table>
</div>

</td>
</tr>
<tr>
<td style="padding:40px 0px 25px 0px;border-top:1px solid #e5e5e5;font-size:0px"
align="left"
valign="top">
<div
style="display:inline-table;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="min-width:20px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:22px;padding:0px 0px 0px 20px"
align="left"
valign="top"
width="20"
height="23">
<img src="https://ci5.googleusercontent.com/proxy/RSi1i1qWsyZ_JH0HCHF3E3fL4-gaVmLx2uteg79PonNHudWF__6Zn6wOxoz9HDX2zXjq1GQLvBCXkT0tQtpJoJBphaKtb-xcZJXPWlmWCPNlaA-pOfcoSLQ3kQTq=s0-d-e1-ft#http://image.official.nike.com/lib/fe9815737560077476/m/3/phone-icon2x.png"
width="14"
height="23"
class="CToWUd"
data-bit="iit">
</td>
<td style="min-width:140px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:22px;padding:0px 20px 0px 0px"
align="left"
valign="top"
width="140"
height="23">
<a href="http://click.official.nike.com/?qs=701f93b8c748270713e78d97840c1bb2211fec25a89e48aa5ee1113b0daa2be9c1fcaffedfc3f630cf7846440e437c23fc36ddfd76cd550dae199c310292c339"
style="text-decoration:none;color:#000000;white-space:nowrap"
nowrap=""
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c748270713e78d97840c1bb2211fec25a89e48aa5ee1113b0daa2be9c1fcaffedfc3f630cf7846440e437c23fc36ddfd76cd550dae199c310292c339&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2WjdUgh3gGtNXmmDilNonD">+44
(0)
2076604453</a>
</td>
</tr>
</tbody>
</table>
</div>

<div
style="display:inline-table;max-width:33.33333%;min-width:160px;width:100%;vertical-align:top">
<table
style="min-width:160px;margin:0px;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="100%"
cellspacing="0"
cellpadding="0">
<tbody>
<tr>
<td style="color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:22px;padding:0px 20px;text-decoration:none"
valign="top">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707bdce0781321e54fc87d5f1e4d75558cd38db3920b3f25595479a352de1c60a83bb5a491abe9f62635546f1e97afac6c4e6062204510935a8"
style="text-decoration:underline;color:#000000;white-space:nowrap;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:22px"
nowrap=""
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707bdce0781321e54fc87d5f1e4d75558cd38db3920b3f25595479a352de1c60a83bb5a491abe9f62635546f1e97afac6c4e6062204510935a8&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2TOZqe98Twl2MXcG404J_f">Hours
of
Operation</a>
</td>
</tr>
</tbody>
</table>
</div>

</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

</td>
</tr>
<tr>
<td align="center">
<table
style="margin:0px;border-collapse:collapse;padding:0px"
role="presentation" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="padding:45px 0px 28px 0px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:24px;line-height:28px;text-align:center;border-top:1px solid #e5e5e5"
align="center">
<h1
style="margin:0px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:24px;line-height:28px">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707adfd8b37b5bba5c4ab978e892623fb2308f2a7a036a7583a26e2f608f974eb48e733536a82389784bdbdf6080c77120b748d29a3d6f5608b"
style="margin:0px;color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:24px;line-height:28px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707adfd8b37b5bba5c4ab978e892623fb2308f2a7a036a7583a26e2f608f974eb48e733536a82389784bdbdf6080c77120b748d29a3d6f5608b&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw3uxW1xyOKTaKN5jghJA1EU">
<span
style="color:#000000;font-family:'Nike TG',Helvetica,Arial,sans-serif!important;font-size:24px;line-height:28px">Nike.com</span>
</a>
</h1>
</td>
</tr>
<tr>
<td style="font-size:0px;padding:0px 0px 35px 0px;border-bottom:1px solid #e5e5e5"
align="center">
<table
style="min-width:300px;margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
width="65%"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="min-width:70px;max-width:25%;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;padding:0px 0px 17px 0px"
align="center">
<a href="http://click.official.nike.com/?qs=701f93b8c748270736d2e9cc5ce5e07f0328ab1346c9ef16ffe14635942338255b6a22642762e2e7258a556860f8326d0e6d4409ac129edacca7198b4d5cb812"
style="color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c748270736d2e9cc5ce5e07f0328ab1346c9ef16ffe14635942338255b6a22642762e2e7258a556860f8326d0e6d4409ac129edacca7198b4d5cb812&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2yL3VGw4i1duDrhY5qzjGv">Men</a>
</td>
<td
style="width:61px;font-size:0px">
&nbsp;
</td>
<td style="min-width:70px;max-width:25%;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;padding:0px 0px 17px 0px"
align="center">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707f1119c92c5566d993ed79a5854dedb1ecd3a14ef2d83b5a4b55d8582a90b3ef0f45ca8e6177d18765806e1faf8a6e980f29db304ddfa284f"
style="color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707f1119c92c5566d993ed79a5854dedb1ecd3a14ef2d83b5a4b55d8582a90b3ef0f45ca8e6177d18765806e1faf8a6e980f29db304ddfa284f&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw104ZKvi8oAm2qHUZSZtF6G">Women</a>
</td>
<td
style="width:61px;font-size:0px">
&nbsp;
</td>
<td style="min-width:70px;max-width:25%;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;padding:0px 0px 17px 0px"
align="center">
<a href="http://click.official.nike.com/?qs=701f93b8c74827076bd3087922f47aee4d0e8f5731ebdbbbb1ea8ad31fd9bd701f66d6fd5c45fc25d9523a46186f110a2097300b239ff236ab1ee115621451f8"
style="color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c74827076bd3087922f47aee4d0e8f5731ebdbbbb1ea8ad31fd9bd701f66d6fd5c45fc25d9523a46186f110a2097300b239ff236ab1ee115621451f8&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw0XYAtUGFA4kKCTWEdc4yKf">Kids</a>
</td>
<td
style="width:61px;font-size:0px">
&nbsp;
</td>
<td style="min-width:70px;max-width:25%;color:#111111;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;padding:0px 0px 17px 0px"
align="center">
<a href="http://click.official.nike.com/?qs=701f93b8c74827073954c0f57f16efbe9f9e65178e6642ce5cf0d6c4c6fdf70efe1d6e9a32147968f65448a89f3b185edc00c0f496994a66da8b23fef681d6ee"
style="color:#000000;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:16px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c74827073954c0f57f16efbe9f9e65178e6642ce5cf0d6c4c6fdf70efe1d6e9a32147968f65448a89f3b185edc00c0f496994a66da8b23fef681d6ee&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw0YahDdi1XbI1aTM0QvD7hQ">Customise</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>

</td>
</tr>
<tr>
<td align="center">
<table
style="margin:0px;border-collapse:collapse;padding:0px"
role="presentation" border="0"
width="100%" cellspacing="0"
cellpadding="0" align="center">
<tbody>
<tr>
<td style="font-size:0px;padding:20px 0px 40px 0px"
align="center">
<table
style="margin:0px auto;border-collapse:collapse;padding:0px"
role="presentation"
border="0"
cellspacing="0"
cellpadding="0"
align="center">
<tbody>
<tr>
<td style="min-width:70px;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px;padding:0px"
align="center">
<a href="http://view.official.nike.com/?qs=f7c36191765435621de8b264dacfdf06f141cd8face29b29d1ff23f4bab3acc97b6cf8ecce995531deba2c66864f75d3ebcd44fe2fad9ccd4a63eff670064e940a7ce9f57b6831a03edc6f73864cda6f092367a4313baefc"
style="white-space:nowrap;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://view.official.nike.com/?qs%3Df7c36191765435621de8b264dacfdf06f141cd8face29b29d1ff23f4bab3acc97b6cf8ecce995531deba2c66864f75d3ebcd44fe2fad9ccd4a63eff670064e940a7ce9f57b6831a03edc6f73864cda6f092367a4313baefc&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw3xg2nfXmORktn9PjCzmbRP">Web
Version</a>
</td>
<td
style="width:17px;min-width:17px;font-size:0px">
&nbsp;
</td>
<td style="min-width:70px;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px;padding:0px"
align="center">
<a href="http://click.official.nike.com/?qs=701f93b8c7482707c6c05f5739be12f22fbb53a7f5171e2c26d9f74c0e03bb266bc6da0f0654523e198667f67f3fe140ff4f0602fa42bb76843dbcc48f379001"
style="white-space:nowrap;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px;text-decoration:none"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c7482707c6c05f5739be12f22fbb53a7f5171e2c26d9f74c0e03bb266bc6da0f0654523e198667f67f3fe140ff4f0602fa42bb76843dbcc48f379001&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2OMfWjVGCQl3LdGVzbZ2OV">Privacy
Policy</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="font-size:0px;padding:0px 30px"
align="center">
<p
style="margin:0px auto;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px;padding:0px">
Please
<a href="http://click.official.nike.com/?qs=701f93b8c748270718d80edb708cebd339ef44196d95ef3000e693f97adad30622ab14efa529be83200c9dee9a09b29b232de3859c391195231594e4c8a85429"
style="white-space:nowrap;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:26px"
rel="noopener"
target="_blank"
data-saferedirecturl="https://www.google.com/url?q=http://click.official.nike.com/?qs%3D701f93b8c748270718d80edb708cebd339ef44196d95ef3000e693f97adad30622ab14efa529be83200c9dee9a09b29b232de3859c391195231594e4c8a85429&amp;source=gmail&amp;ust=1692888159200000&amp;usg=AOvVaw2D3IeOihEJrbeBM869_wv4">contact
us</a> if
you have any
questions. (If
you reply to
this email, we
won't be able to
see it.)
</p>
</td>
</tr>
<tr>
<td style="font-size:0px;padding:43px 20px 0px 20px"
align="center">
<p
style="margin:0px auto;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:11px;line-height:22px;padding:0px">
© 2023 Nike,
Inc. All Rights
Reserved.</p>
</td>
</tr>
<tr>
<td style="font-size:0px;padding:0px 20px 20px 20px"
align="center">
<p
style="margin:0px auto;color:#aaaaaa;font-family:Helvetica,Arial,sans-serif;font-size:11px;line-height:22px;padding:0px">
<span
style="text-decoration:none">NIKE,
INC. NIKE
Retail B.V.,
Colosseum 1,
1213 NL,
Hilversum,
The
Netherlands</span>
</p>
</td>
</tr>
</tbody>
</table>

</td>
</tr>
</tbody>
</table>

</td>
</tr>
</tbody>
</table>
</td>
<td style="font-size:0px;line-height:1px;overflow:hidden!important">
&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</center>
<div class="yj6qo"></div>
<div class="adL">
</div>
</div>
<div class="adL">
</div>
</blockquote>
<div class="adL">
</div>
</div>
<div class="adL">

</div>
</div>
</div>
<div id=":150" class="ii gt" style="display:none">
<div id=":14z" class="a3s aiL "></div>
</div>
<div class="hi"></div>
</div>
</body>

</html>`;
};
